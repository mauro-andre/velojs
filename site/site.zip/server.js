import { jsx, jsxs, Fragment } from "preact/jsx-runtime";
import { useParams as useParams$1, useLocation, useRouter, Link as Link$1, Router } from "wouter-preact";
import { signal, useSignal } from "@preact/signals";
import { useRef, useEffect, useState } from "preact/hooks";
import { createHighlighter } from "shiki";
import { Hono } from "hono";
import "hono/logger";
import { trimTrailingSlash } from "hono/trailing-slash";
import { render } from "preact-render-to-string";
import { AsyncLocalStorage } from "node:async_hooks";
const __veloUpdatePending = signal(false);
function useLoader(moduleIdOrDeps, deps) {
  let moduleId;
  let resolvedDeps;
  if (Array.isArray(moduleIdOrDeps)) {
    resolvedDeps = moduleIdOrDeps;
  } else {
    moduleId = moduleIdOrDeps;
    resolvedDeps = deps;
  }
  let initialData = null;
  if (typeof window === "undefined" && moduleId) {
    const storage = globalThis.__veloServerData;
    const serverData = storage?.getStore?.();
    if (serverData?.[moduleId]) {
      initialData = serverData[moduleId];
    }
  }
  if (typeof window !== "undefined" && moduleId) {
    const pageData = window.__PAGE_DATA__;
    if (pageData?.[moduleId]) {
      initialData = pageData[moduleId];
      delete pageData[moduleId];
    }
  }
  const data = useSignal(initialData);
  const loading = useSignal(false);
  const fetchData = () => {
    if (typeof window === "undefined" || !moduleId) return;
    const currentPath = window.location.pathname;
    loading.value = true;
    const dataUrl = `${currentPath === "/" ? "" : currentPath}/index.json`;
    fetch(dataUrl, { cache: "no-cache" }).then((res) => res.json()).then((json) => {
      if (json.__buildHash && json.__buildHash !== "mqphb2yt") {
        __veloUpdatePending.value = true;
      }
      data.value = json[moduleId];
      loading.value = false;
    }).catch(() => {
      loading.value = false;
    });
  };
  const isHydrated = useRef(initialData !== null);
  useEffect(() => {
    if (isHydrated.current) {
      isHydrated.current = false;
      return;
    }
    fetchData();
  }, resolvedDeps ?? []);
  return { data, loading, refetch: fetchData };
}
function useParams() {
  if (typeof window === "undefined") {
    const storage = globalThis.__veloServerData;
    const serverData = storage?.getStore?.();
    return serverData?.__params ?? {};
  }
  return useParams$1();
}
function usePathname() {
  if (typeof window === "undefined") {
    const storage = globalThis.__veloServerData;
    const serverData = storage?.getStore?.();
    return serverData?.__pathname ?? "/";
  }
  useLocation();
  return window.location.pathname;
}
function Scripts({ basePath, favicon = "/favicon.ico" } = {}) {
  basePath = basePath || "/client";
  const faviconType = favicon === false ? void 0 : favicon.endsWith(".svg") ? "image/svg+xml" : favicon.endsWith(".png") ? "image/png" : "image/x-icon";
  const faviconTag = favicon !== false && /* @__PURE__ */ jsx("link", { rel: "icon", href: `${basePath}${favicon}`, type: faviconType });
  const jsFile = globalThis.__veloClientJs || "client.BWXN6_Ie.js";
  const cssFile = globalThis.__veloClientCss || "client.mGLnjzc4.css";
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    faviconTag,
    /* @__PURE__ */ jsx("link", { rel: "stylesheet", href: `${basePath}/${cssFile}` }),
    /* @__PURE__ */ jsx("script", { type: "module", src: `${basePath}/${jsFile}` })
  ] });
}
function substituteParams(path, params) {
  let result = path;
  for (const [key, value] of Object.entries(params)) {
    result = result.replace(`:${key}`, value);
  }
  return result;
}
function Link({ to, params, search, absolute, ...rest }) {
  const isModule = typeof to !== "string";
  const router = useRouter();
  const basePath = isModule ? to.metadata?.fullPath ?? "/" : to;
  const finalPath = params ? substituteParams(basePath, params) : basePath;
  const queryString = search ? `?${new URLSearchParams(search).toString()}` : "";
  const href = `${finalPath}${queryString}`;
  if (typeof window !== "undefined" && __veloUpdatePending.value) {
    let fullHref;
    if (isModule) {
      const absPath = to.metadata?.fullPath ?? basePath;
      fullHref = `${params ? substituteParams(absPath, params) : absPath}${queryString}`;
    } else {
      const path = finalPath.replace(/^~/, "");
      const needsBase = !finalPath.startsWith("~") && router.base;
      fullHref = `${needsBase ? router.base : ""}${path}${queryString}`;
    }
    const { onClick, ...anchorRest } = rest;
    return /* @__PURE__ */ jsx(
      "a",
      {
        href: fullHref,
        onClick: (e) => {
          if (onClick) onClick(e);
          if (!e.defaultPrevented) {
            e.preventDefault();
            window.location.href = fullHref;
          }
        },
        ...anchorRest
      }
    );
  }
  return /* @__PURE__ */ jsx(Link$1, { to: href, ...rest });
}
function emptyContext() {
  return {
    pendingRoutes: [],
    pendingStreamRoutes: [],
    serverCallbacks: [],
    disposers: /* @__PURE__ */ new Set()
  };
}
const defaultContext = emptyContext();
let currentContext = defaultContext;
function getAppContext() {
  return currentContext;
}
const DEFAULT_HEARTBEAT_MS = 2e4;
const BROADCAST_CHANNEL = "";
function flushPendingStreamRoutes(app) {
  const ctx = getAppContext();
  const pending = ctx.pendingStreamRoutes.splice(0);
  for (const fn of pending) fn(app);
}
function defaultChannelFn(c) {
  return c.req.query("channel") ?? BROADCAST_CHANNEL;
}
function registerStreamHandler(app, path, stream, middlewares = []) {
  const handler = async (c) => {
    const { streamSSE } = await import("hono/streaming");
    let channelKey;
    if (stream.__config.broadcast) {
      channelKey = BROADCAST_CHANNEL;
    } else {
      const resolver = stream.__config.channel ?? defaultChannelFn;
      let resolved;
      try {
        resolved = await resolver(c);
      } catch (err) {
        console.error("[velojs] channel resolver threw:", err);
        return c.json({ error: "internal" }, 500);
      }
      if (resolved == null) {
        return c.json({ error: "forbidden" }, 403);
      }
      channelKey = resolved;
    }
    const heartbeatMs = stream.__config.heartbeatMs;
    const heartbeatInterval = heartbeatMs === false ? 0 : heartbeatMs ?? DEFAULT_HEARTBEAT_MS;
    return streamSSE(c, async (sse) => {
      const bufferedEvents = stream.__buffers.get(channelKey);
      if (bufferedEvents && bufferedEvents.length > 0) {
        await sse.writeSSE({
          event: "snapshot",
          data: JSON.stringify(bufferedEvents)
        });
      }
      if (stream.__config.snapshot) {
        const snapshot = await stream.__config.snapshot(
          channelKey === BROADCAST_CHANNEL ? void 0 : channelKey
        );
        if (snapshot !== void 0) {
          await sse.writeSSE({
            event: "snapshot",
            data: JSON.stringify(snapshot)
          });
        }
      }
      let resolveDone;
      const done = new Promise((resolve) => {
        resolveDone = resolve;
      });
      let disposed = false;
      let heartbeat = null;
      let writeChain = Promise.resolve();
      const enqueueWrite = (payload) => {
        writeChain = writeChain.then(() => sse.writeSSE(payload)).catch(() => {
        });
        return writeChain;
      };
      const cleanup = () => {
        if (disposed) return;
        disposed = true;
        if (heartbeat) clearInterval(heartbeat);
        stream.__onDisconnect(channelKey, listener);
        resolveDone();
      };
      const listener = ((event) => {
        if (disposed) return;
        enqueueWrite({ data: JSON.stringify(event) });
        if (stream.__config.closeOn?.(event)) {
          writeChain.then(() => {
            sse.close();
            cleanup();
          });
        }
      });
      listener.close = () => {
        if (disposed) return;
        enqueueWrite({ event: "close", data: "" });
        writeChain.then(() => {
          sse.close();
          cleanup();
        });
      };
      stream.__onConnect(channelKey, listener, {
        c,
        params: c.req.param(),
        query: c.req.query()
      });
      heartbeat = heartbeatInterval > 0 ? setInterval(() => {
        if (disposed) return;
        enqueueWrite({ event: "heartbeat", data: "" });
      }, heartbeatInterval) : null;
      sse.onAbort(cleanup);
      await done;
    });
  };
  if (middlewares.length > 0) {
    app.on(["GET"], [path], ...middlewares, handler);
  } else {
    app.on(["GET"], [path], handler);
  }
}
const metadata$3 = { moduleId: "client-root", fullPath: "", path: "" };
const Component$3 = ({ children }) => {
  return /* @__PURE__ */ jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxs("head", { children: [
      /* @__PURE__ */ jsx("meta", { charSet: "utf-8" }),
      /* @__PURE__ */ jsx("meta", { name: "viewport", content: "width=device-width, initial-scale=1.0" }),
      /* @__PURE__ */ jsx("title", { children: "VeloJS — Fullstack Web Framework" }),
      /* @__PURE__ */ jsx("meta", { name: "description", content: "Fullstack web framework built on Hono + Preact with Vite-powered AST transforms. SSR, hydration, RPC actions, file-based routing — zero config." }),
      /* @__PURE__ */ jsx("link", { rel: "preconnect", href: "https://fonts.googleapis.com" }),
      /* @__PURE__ */ jsx("link", { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" }),
      /* @__PURE__ */ jsx("link", { href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap", rel: "stylesheet" }),
      /* @__PURE__ */ jsx("style", { dangerouslySetInnerHTML: { __html: `@property --angle { syntax: "<angle>"; initial-value: 0deg; inherits: false; }` } }),
      /* @__PURE__ */ jsx(Scripts, {})
    ] }),
    /* @__PURE__ */ jsx("body", { children })
  ] });
};
const Root = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Component: Component$3,
  metadata: metadata$3
}, Symbol.toStringTag, { value: "Module" }));
var page = "emptfk0";
var nav = "emptfk1";
var navInner = "emptfk2";
var logo = "emptfk3";
var navLinks = "emptfk4";
var navLink = "emptfk5";
var navCta = "emptfk6";
var hero = "emptfk9";
var heroStep1 = "emptfka";
var heroStep2 = "emptfkb";
var heroStep3 = "emptfkc";
var heroStep4 = "emptfkd";
var heroStep5 = "emptfke";
var heroEyebrow = "emptfkf";
var heroTitle = "emptfkg";
var heroTitleLine = "emptfkh";
var heroSubtitle = "emptfki";
var heroActions = "emptfkj";
var btnPrimary$1 = "emptfkk";
var btnSecondary$1 = "emptfkl";
var heroPills = "emptfkm";
var heroPill = "emptfkn";
var footer = "emptfko";
var footerInner = "emptfkp";
var footerLinks = "emptfkq";
var footerLink = "emptfkr";
var footerCopyright = "emptfks";
const Beaker = (props) => /* @__PURE__ */ jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0.400 1.400 23.200 21.200", width: props.size ?? 32, height: props.size ?? 32, fill: "none", ...props, children: [
  /* @__PURE__ */ jsx("path", { d: "M15.0486 4H8.95137C8.46527 4 8.31058 4.65529 8.74536 4.87268C8.90142 4.95071 9 5.11022 9 5.2847V10.1716C9 10.702 8.78929 11.2107 8.41421 11.5858L3.58579 16.4142C3.21071 16.7893 3 17.298 3 17.8284V18C3 19.1046 3.89543 20 5 20H19C20.1046 20 21 19.1046 21 18V17.8284C21 17.298 20.7893 16.7893 20.4142 16.4142L15.5858 11.5858C15.2107 11.2107 15 10.702 15 10.1716V5.2847C15 5.11022 15.0986 4.95071 15.2546 4.87268C15.6894 4.65529 15.5347 4 15.0486 4Z", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M5 15H19", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" })
] });
const Cog = (props) => /* @__PURE__ */ jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0.429 0.429 23.143 23.143", width: props.size ?? 32, height: props.size ?? 32, fill: "none", ...props, children: [
  /* @__PURE__ */ jsx("path", { d: "M10.255 4.18806C9.84269 5.17755 8.68655 5.62456 7.71327 5.17535C6.10289 4.4321 4.4321 6.10289 5.17535 7.71327C5.62456 8.68655 5.17755 9.84269 4.18806 10.255C2.63693 10.9013 2.63693 13.0987 4.18806 13.745C5.17755 14.1573 5.62456 15.3135 5.17535 16.2867C4.4321 17.8971 6.10289 19.5679 7.71327 18.8246C8.68655 18.3754 9.84269 18.8224 10.255 19.8119C10.9013 21.3631 13.0987 21.3631 13.745 19.8119C14.1573 18.8224 15.3135 18.3754 16.2867 18.8246C17.8971 19.5679 19.5679 17.8971 18.8246 16.2867C18.3754 15.3135 18.8224 14.1573 19.8119 13.745C21.3631 13.0987 21.3631 10.9013 19.8119 10.255C18.8224 9.84269 18.3754 8.68655 18.8246 7.71327C19.5679 6.10289 17.8971 4.4321 16.2867 5.17535C15.3135 5.62456 14.1573 5.17755 13.745 4.18806C13.0987 2.63693 10.9013 2.63693 10.255 4.18806Z", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M15 12C15 13.6569 13.6569 15 12 15C10.3431 15 9 13.6569 9 12C9 10.3431 10.3431 9 12 9C13.6569 9 15 10.3431 15 12Z", stroke: "currentColor", strokeWidth: "2" })
] });
const CubeTransparent = (props) => /* @__PURE__ */ jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "1.401 0.414 21.198 23.185", width: props.size ?? 32, height: props.size ?? 32, fill: "none", ...props, children: [
  /* @__PURE__ */ jsx("path", { d: "M10 4L11.9505 3.02477C11.9816 3.00918 12.0184 3.00918 12.0495 3.02477V3.02477L14 4", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M10 11L11.1056 11.5528C11.6686 11.8343 12.3314 11.8343 12.8944 11.5528L14 11", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M12 12V14", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M18.5 6.5L19.9441 7.46274V7.46274C19.979 7.48602 20 7.52521 20 7.56717V9.5", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M19.5 7.5L18 8.5", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M5.5 6.5L4.05048 7.46635V7.46635C4.01894 7.48737 4 7.52277 4 7.56067V9.5", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M4 7.5L5.5 8.5", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M4 14.5V16.4469C4 16.4801 4.01658 16.5111 4.04417 16.5294V16.5294L5.5 17.5", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M10 20L11.9516 20.9758C11.9821 20.991 12.0179 20.991 12.0484 20.9758V20.9758L14 20", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M12 21V18.5", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M18.5 17.5L19.9612 16.5258V16.5258C19.9855 16.5097 20 16.4825 20 16.4534V14.5", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" })
] });
const Lock = (props) => /* @__PURE__ */ jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "2.400 0.400 19.200 23.200", width: props.size ?? 32, height: props.size ?? 32, fill: "none", ...props, children: [
  /* @__PURE__ */ jsx("path", { d: "M13 15C13 15.5523 12.5523 16 12 16C11.4477 16 11 15.5523 11 15C11 14.4477 11.4477 14 12 14C12.5523 14 13 14.4477 13 15Z", stroke: "currentColor", strokeWidth: "2" }),
  /* @__PURE__ */ jsx("path", { d: "M15 9C16.8856 9 17.8284 9 18.4142 9.58579C19 10.1716 19 11.1144 19 13L19 15L19 17C19 18.8856 19 19.8284 18.4142 20.4142C17.8284 21 16.8856 21 15 21L12 21L9 21C7.11438 21 6.17157 21 5.58579 20.4142C5 19.8284 5 18.8856 5 17L5 15L5 13C5 11.1144 5 10.1716 5.58579 9.58579C6.17157 9 7.11438 9 9 9L12 9L15 9Z", stroke: "currentColor", strokeWidth: "2", strokeLinejoin: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M9 9V5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5V9", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" })
] });
const Rss = (props) => /* @__PURE__ */ jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "2.720 2.720 18.560 18.560", width: props.size ?? 32, height: props.size ?? 32, fill: "none", ...props, children: [
  /* @__PURE__ */ jsx("path", { d: "M7 18C7 18.5523 6.55228 19 6 19C5.44772 19 5 18.5523 5 18C5 17.4477 5.44772 17 6 17C6.55228 17 7 17.4477 7 18Z", stroke: "currentColor", strokeWidth: "2" }),
  /* @__PURE__ */ jsx("path", { d: "M11 19C11 15.6863 8.31371 13 5 13", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M15 19C15 13.4772 10.5228 9 5 9", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" }),
  /* @__PURE__ */ jsx("path", { d: "M19 19C19 11.268 12.732 5 5 5", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" })
] });
const Zap = (props) => /* @__PURE__ */ jsx("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "4.681 1.743 15.616 20.383", width: props.size ?? 32, height: props.size ?? 32, fill: "none", ...props, children: /* @__PURE__ */ jsx("path", { d: "M17.7634 10.7614L17.8704 10.5979C17.9261 10.5129 17.8651 10.4 17.7634 10.4H13.5C13.3817 10.4 13.2857 10.3041 13.2857 10.1857V4.23047V4.21257C13.2857 4.14957 13.2038 4.12513 13.1693 4.17784L7.18868 13.3118L7.10336 13.4421C7.05895 13.51 7.10761 13.6 7.18868 13.6H11.4488H11.5027C11.6196 13.6 11.7143 13.6947 11.7143 13.8116V19.6027C11.7143 19.7205 11.8683 19.7647 11.9328 19.6662L17.7634 10.7614Z", stroke: "currentColor", strokeWidth: "2", strokeLinejoin: "round" }) });
var ambient = "_1f5mth33";
var dotGrid = "_1f5mth34";
var blob1 = "_1f5mth35";
var blob2 = "_1f5mth36";
var blob3 = "_1f5mth37";
function AmbientBackground() {
  return /* @__PURE__ */ jsxs("div", { class: ambient, "aria-hidden": "true", children: [
    /* @__PURE__ */ jsx("div", { class: blob1 }),
    /* @__PURE__ */ jsx("div", { class: blob2 }),
    /* @__PURE__ */ jsx("div", { class: blob3 }),
    /* @__PURE__ */ jsx("div", { class: dotGrid })
  ] });
}
var section$5 = "_1srrnnr0";
var header$4 = "_1srrnnr1";
var title$5 = "_1srrnnr2";
var subtitle$4 = "_1srrnnr3";
var diagramHidden = "_1srrnnr4";
var diagramVisible = "_1srrnnr5";
var whyGridHidden = "_1srrnnr6";
var whyGridVisible = "_1srrnnr7";
var fileCard = "_1srrnnr9";
var fileCardHeader = "_1srrnnra";
var fileCardDot = "_1srrnnrb";
var fileCardName = "_1srrnnrc";
var blockList = "_1srrnnrd";
var block = "_1srrnnre";
var blockText = "_1srrnnrf";
var blockLabel = "_1srrnnrg";
var blockDesc = "_1srrnnrh";
var hookPills = "_1srrnnri";
var hookPill = "_1srrnnrj";
var badges = "_1srrnnrk";
var badgeSSR = "_1srrnnrl";
var badgeSSG = "_1srrnnrm";
var connectors = "_1srrnnrn";
var bundles = "_1srrnnro";
var bundleServer = "_1srrnnrp";
var bundleClient = "_1srrnnrq";
var whyGrid = "_1srrnnrr";
var whyCard = "_1srrnnrs";
var whyTitle = "_1srrnnrt";
var whyDesc = "_1srrnnru";
var pulseServer = "_1srrnnrw";
var pulseClient = "_1srrnnrx";
function useInView(threshold = 0.2) {
  const ssr = typeof window === "undefined";
  const [visible, setVisible] = useState(ssr);
  const ref = useRef(null);
  useEffect(() => {
    if (ssr) return;
    const el = ref.current;
    if (!el) return;
    setVisible(false);
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry && entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold, rootMargin: "0px 0px -10% 0px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [threshold]);
  return [ref, visible];
}
function ComponentAnatomy() {
  const [ref, visible] = useInView(0.25);
  return /* @__PURE__ */ jsxs("section", { class: section$5, children: [
    /* @__PURE__ */ jsxs("div", { class: header$4, children: [
      /* @__PURE__ */ jsx("h2", { class: title$5, children: "One component. SSR or SSG, same code." }),
      /* @__PURE__ */ jsx("p", { class: subtitle$4, children: "Loader, action, and UI live in the same file. The plugin splits server from client at build time; the CLI picks SSR or SSG. Business logic travels with the UI that uses it." })
    ] }),
    /* @__PURE__ */ jsxs(
      "div",
      {
        ref,
        class: visible ? diagramVisible : diagramHidden,
        children: [
          /* @__PURE__ */ jsxs("div", { class: fileCard, children: [
            /* @__PURE__ */ jsxs("div", { class: fileCardHeader, children: [
              /* @__PURE__ */ jsx("span", { class: fileCardDot }),
              /* @__PURE__ */ jsx("span", { class: fileCardName, children: "Dashboard.tsx" })
            ] }),
            /* @__PURE__ */ jsxs("div", { class: blockList, children: [
              /* @__PURE__ */ jsxs("div", { class: block, children: [
                /* @__PURE__ */ jsxs("div", { class: blockText, children: [
                  /* @__PURE__ */ jsx("span", { class: blockLabel, children: "loader" }),
                  /* @__PURE__ */ jsx("span", { class: blockDesc, children: "Loads data from the server before the UI renders" })
                ] }),
                /* @__PURE__ */ jsxs("div", { class: badges, children: [
                  /* @__PURE__ */ jsx("span", { class: badgeSSR, children: "SSR" }),
                  /* @__PURE__ */ jsx("span", { class: badgeSSG, children: "SSG" })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { class: block, children: [
                /* @__PURE__ */ jsxs("div", { class: blockText, children: [
                  /* @__PURE__ */ jsx("span", { class: blockLabel, children: "action_*" }),
                  /* @__PURE__ */ jsx("span", { class: blockDesc, children: "Call server code from the UI like a local function" })
                ] }),
                /* @__PURE__ */ jsx("div", { class: badges, children: /* @__PURE__ */ jsx("span", { class: badgeSSR, children: "SSR" }) })
              ] }),
              /* @__PURE__ */ jsxs("div", { class: block, children: [
                /* @__PURE__ */ jsxs("div", { class: blockText, children: [
                  /* @__PURE__ */ jsx("span", { class: blockLabel, children: "Component" }),
                  /* @__PURE__ */ jsx("span", { class: blockDesc, children: "Your UI — rendered on the server, hydrated on the client" }),
                  /* @__PURE__ */ jsxs("div", { class: hookPills, children: [
                    /* @__PURE__ */ jsx("span", { class: hookPill, children: "useLoader()" }),
                    /* @__PURE__ */ jsx("span", { class: hookPill, children: "action_*()" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { class: badges, children: [
                  /* @__PURE__ */ jsx("span", { class: badgeSSR, children: "SSR" }),
                  /* @__PURE__ */ jsx("span", { class: badgeSSG, children: "SSG" })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs(
            "svg",
            {
              class: connectors,
              viewBox: "0 0 100 40",
              preserveAspectRatio: "none",
              "aria-hidden": "true",
              children: [
                /* @__PURE__ */ jsx(
                  "path",
                  {
                    class: pulseServer,
                    d: "M 50 0 C 50 22, 25 18, 25 40",
                    "vector-effect": "non-scaling-stroke"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "path",
                  {
                    class: pulseClient,
                    d: "M 50 0 C 50 22, 75 18, 75 40",
                    "vector-effect": "non-scaling-stroke"
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsxs("div", { class: bundles, children: [
            /* @__PURE__ */ jsx("div", { class: bundleServer, children: "server bundle" }),
            /* @__PURE__ */ jsx("div", { class: bundleClient, children: "client bundle" })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ jsx("div", { class: visible ? whyGridVisible : whyGridHidden, children: /* @__PURE__ */ jsxs("div", { class: whyGrid, children: [
      /* @__PURE__ */ jsxs("div", { class: whyCard, children: [
        /* @__PURE__ */ jsx("h3", { class: whyTitle, children: "Same component, same business rules" }),
        /* @__PURE__ */ jsx("p", { class: whyDesc, children: "Data fetching, mutations, and UI live side by side in the same file. Business rules stay where they belong — next to the UI that uses them." })
      ] }),
      /* @__PURE__ */ jsxs("div", { class: whyCard, children: [
        /* @__PURE__ */ jsx("h3", { class: whyTitle, children: "Zero path mapping" }),
        /* @__PURE__ */ jsx("p", { class: whyDesc, children: "Routes are generated automatically. Export a function, the framework registers it. No path mapping, no handler plumbing, nothing to wire by hand." })
      ] }),
      /* @__PURE__ */ jsxs("div", { class: whyCard, children: [
        /* @__PURE__ */ jsx("h3", { class: whyTitle, children: "SSR or SSG, same code" }),
        /* @__PURE__ */ jsx("p", { class: whyDesc, children: "Ship dynamic or pre-rendered with one flag. Same component, same loader, same TypeScript — the build mode doesn't change what you write." })
      ] })
    ] }) })
  ] });
}
var wrapper = "_1cv55lu1";
var titleBar = "_1cv55lu2";
var dots = "_1cv55lu3";
var dotRed = "_1cv55lu4";
var dotYellow = "_1cv55lu5";
var dotGreen = "_1cv55lu6";
var filename = "_1cv55lu7";
var body = "_1cv55lu8";
function CodeWindow({
  filename: filename$1,
  titlebarContent,
  html,
  children,
  class: className
}) {
  const wrapperClass = className ? `${wrapper} ${className}` : wrapper;
  return /* @__PURE__ */ jsxs("div", { class: wrapperClass, children: [
    /* @__PURE__ */ jsxs("div", { class: titleBar, children: [
      /* @__PURE__ */ jsxs("div", { class: dots, children: [
        /* @__PURE__ */ jsx("span", { class: dotRed }),
        /* @__PURE__ */ jsx("span", { class: dotYellow }),
        /* @__PURE__ */ jsx("span", { class: dotGreen })
      ] }),
      titlebarContent ?? /* @__PURE__ */ jsx("span", { class: filename, children: filename$1 ?? "" })
    ] }),
    /* @__PURE__ */ jsx("div", { class: body, children: html ? /* @__PURE__ */ jsx("div", { dangerouslySetInnerHTML: { __html: html } }) : children })
  ] });
}
var section$4 = "_62g670";
var header$3 = "_62g671";
var title$4 = "_62g672";
var subtitle$3 = "_62g673";
var codeHidden = "_62g674";
var codeVisible = "_62g675";
var takeawaysHidden = "_62g676";
var takeawaysVisible = "_62g677";
var codeWrap$1 = "_62g678";
var takeaways$2 = "_62g679";
var takeaway$2 = "_62g67a";
var takeawayDot$2 = "_62g67b";
var takeawayText = "_62g67c";
var takeawayTitle$2 = "_62g67d";
var takeawayDesc$2 = "_62g67e";
function WritingShowcase({ codeHtml }) {
  const [codeRef, codeVisible$1] = useInView(0.2);
  const [takeawaysRef, takeawaysVisible$1] = useInView(0.2);
  return /* @__PURE__ */ jsxs("section", { class: section$4, children: [
    /* @__PURE__ */ jsxs("div", { class: header$3, children: [
      /* @__PURE__ */ jsx("h2", { class: title$4, children: "What writing VeloJS feels like" }),
      /* @__PURE__ */ jsx("p", { class: subtitle$3, children: "A real component. The loader fetches, the action mutates, the Component renders — all in the same file, all in TypeScript." })
    ] }),
    /* @__PURE__ */ jsx(
      "div",
      {
        ref: codeRef,
        class: `${codeWrap$1} ${codeVisible$1 ? codeVisible : codeHidden}`,
        children: /* @__PURE__ */ jsx(CodeWindow, { filename: "app/Products.tsx", html: codeHtml })
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        ref: takeawaysRef,
        class: takeawaysVisible$1 ? takeawaysVisible : takeawaysHidden,
        children: /* @__PURE__ */ jsxs("div", { class: takeaways$2, children: [
          /* @__PURE__ */ jsxs("div", { class: takeaway$2, children: [
            /* @__PURE__ */ jsx("span", { class: takeawayDot$2 }),
            /* @__PURE__ */ jsxs("div", { class: takeawayText, children: [
              /* @__PURE__ */ jsx("h3", { class: takeawayTitle$2, children: "No fetch, no endpoints" }),
              /* @__PURE__ */ jsxs("p", { class: takeawayDesc$2, children: [
                "The button calls ",
                /* @__PURE__ */ jsx("code", { children: "action_toggleActiveProduct" }),
                " ",
                "directly. The plugin wires the server call for you."
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { class: takeaway$2, children: [
            /* @__PURE__ */ jsx("span", { class: takeawayDot$2 }),
            /* @__PURE__ */ jsxs("div", { class: takeawayText, children: [
              /* @__PURE__ */ jsx("h3", { class: takeawayTitle$2, children: "No duplicated types" }),
              /* @__PURE__ */ jsx("p", { class: takeawayDesc$2, children: "The loader returns data. The Component consumes it. Same TypeScript, both sides." })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { class: takeaway$2, children: [
            /* @__PURE__ */ jsx("span", { class: takeawayDot$2 }),
            /* @__PURE__ */ jsxs("div", { class: takeawayText, children: [
              /* @__PURE__ */ jsx("h3", { class: takeawayTitle$2, children: "No glue code" }),
              /* @__PURE__ */ jsx("p", { class: takeawayDesc$2, children: "No request handlers, no zod schemas, no React Query. You write logic; velojs does the plumbing." })
            ] })
          ] })
        ] })
      }
    )
  ] });
}
var section$3 = "_17asmys0";
var header$2 = "_17asmys1";
var title$3 = "_17asmys2";
var subtitle$2 = "_17asmys3";
var topRow = "_17asmys4";
var panel = "_17asmys5";
var treeCard = "_17asmys7";
var treeRoot = "_17asmys8";
var treeChildren = "_17asmys9";
var treeItem = "_17asmysa";
var treeItemRoot = "_17asmysb";
var treeNode = "_17asmysc";
var treeDot = "_17asmysd";
var treeDotLayout = "_17asmyse";
var treeDotPage = "_17asmysf";
var treeDotEndpoint = "_17asmysg";
var treePath = "_17asmysh";
var treeModule = "_17asmysi";
var treeKindLayout = "_17asmysj";
var treeKindPage = "_17asmysk";
var treeKindEndpoint = "_17asmysl";
var mwBadge = "_17asmysm";
var mwBadgeInherited = "_17asmysn";
var mwBadgePulse = "_17asmysp";
var resolvesTo = "_17asmysq";
var resolvesArrow = "_17asmysr";
var tableCard = "_17asmyss";
var table = "_17asmyst";
var tableRow = "_17asmysu";
var tableCell = "_17asmysv";
var cellMethod = "_17asmysw";
var cellPath = "_17asmysx";
var cellArrow = "_17asmysy";
var cellModule = "_17asmysz";
var cellMw = "_17asmys10";
var methodGet = "_17asmys11";
var methodPost = "_17asmys12";
var fadeHidden$2 = "_17asmys13";
var fadeVisible$2 = "_17asmys14";
var rowAnimated = "_17asmys16";
var takeaways$1 = "_17asmys17";
var takeaway$1 = "_17asmys18";
var takeawayDot$1 = "_17asmys19";
var takeawayTitle$1 = "_17asmys1a";
var takeawayDesc$1 = "_17asmys1b";
const ROUTES = {
  module: "Root",
  kind: "layout",
  children: [
    { path: "/", module: "Home", kind: "page" },
    {
      path: "/app",
      module: "AdminLayout",
      kind: "layout",
      middlewares: ["auth"],
      pulseMw: true,
      children: [
        { path: "/dashboard", module: "Dashboard", kind: "page" },
        { path: "/products", module: "Products", kind: "page" }
      ]
    },
    {
      path: "/api/github",
      module: "githubWebhook",
      kind: "endpoint",
      method: "POST"
    }
  ]
};
function flatten(node, parentPath = "", parentMw = []) {
  const myPath = parentPath + (node.path ?? "");
  const myMw = [...parentMw, ...node.middlewares ?? []];
  if (!node.children) {
    return [
      {
        method: node.method ?? "GET",
        path: myPath || "/",
        module: node.module,
        middlewares: myMw
      }
    ];
  }
  return node.children.flatMap((child) => flatten(child, myPath, myMw));
}
function dotClass(kind) {
  if (kind === "layout") return treeDotLayout;
  if (kind === "page") return treeDotPage;
  return treeDotEndpoint;
}
function kindBadgeClass(kind) {
  if (kind === "layout") return treeKindLayout;
  if (kind === "page") return treeKindPage;
  return treeKindEndpoint;
}
function kindLabel(kind, method) {
  if (kind === "endpoint") return `${method ?? "GET"} · endpoint`;
  return kind;
}
function TreeNode({
  node,
  inheritedMw,
  isRoot = false
}) {
  const myMw = [...inheritedMw, ...node.middlewares ?? []];
  return /* @__PURE__ */ jsxs("li", { class: isRoot ? treeItemRoot : treeItem, children: [
    /* @__PURE__ */ jsxs("div", { class: treeNode, children: [
      /* @__PURE__ */ jsx("span", { class: `${treeDot} ${dotClass(node.kind)}` }),
      node.path && /* @__PURE__ */ jsx("span", { class: treePath, children: node.path }),
      /* @__PURE__ */ jsx("span", { class: treeModule, children: node.module }),
      node.middlewares?.map((mw) => /* @__PURE__ */ jsxs(
        "span",
        {
          class: `${mwBadge} ${node.pulseMw ? mwBadgePulse : ""}`,
          children: [
            "🛡 ",
            mw
          ]
        },
        mw
      )),
      !node.children && inheritedMw.map((mw) => /* @__PURE__ */ jsxs("span", { class: mwBadgeInherited, children: [
        "🛡 ",
        mw
      ] }, `i-${mw}`)),
      /* @__PURE__ */ jsx("span", { class: kindBadgeClass(node.kind), children: kindLabel(node.kind, node.method) })
    ] }),
    node.children && /* @__PURE__ */ jsx("ul", { class: treeChildren, children: node.children.map((c) => /* @__PURE__ */ jsx(TreeNode, { node: c, inheritedMw: myMw }, c.module)) })
  ] });
}
function MethodBadge({ method }) {
  const className = method === "POST" || method === "PUT" || method === "PATCH" || method === "DELETE" ? methodPost : methodGet;
  return /* @__PURE__ */ jsx("span", { class: className, children: method });
}
function RoutesShowcase({ codeHtml }) {
  const [topRef, topVisible] = useInView(0.15);
  const [tableRef, tableVisible] = useInView(0.15);
  const [takeawaysRef, takeawaysVisible2] = useInView(0.2);
  const rows = flatten(ROUTES);
  return /* @__PURE__ */ jsxs("section", { class: section$3, children: [
    /* @__PURE__ */ jsxs("div", { class: header$2, children: [
      /* @__PURE__ */ jsx("h2", { class: title$3, children: "One routes.tsx. Every URL." }),
      /* @__PURE__ */ jsx("p", { class: subtitle$2, children: "Pages, APIs, webhooks — all declared in a single tree. Middleware flows down; paths resolve automatically." })
    ] }),
    /* @__PURE__ */ jsxs(
      "div",
      {
        ref: topRef,
        class: `${topRow} ${topVisible ? fadeVisible$2 : fadeHidden$2}`,
        children: [
          /* @__PURE__ */ jsx("div", { class: panel, children: /* @__PURE__ */ jsx(CodeWindow, { filename: "app/routes.tsx", html: codeHtml }) }),
          /* @__PURE__ */ jsx("div", { class: panel, children: /* @__PURE__ */ jsx("div", { class: treeCard, children: /* @__PURE__ */ jsx("ul", { class: treeRoot, children: /* @__PURE__ */ jsx(TreeNode, { node: ROUTES, inheritedMw: [], isRoot: true }) }) }) })
        ]
      }
    ),
    /* @__PURE__ */ jsxs("div", { class: resolvesTo, children: [
      "resolves to",
      /* @__PURE__ */ jsx("span", { class: resolvesArrow, children: "↓" })
    ] }),
    /* @__PURE__ */ jsx(
      "div",
      {
        ref: tableRef,
        class: tableVisible ? fadeVisible$2 : fadeHidden$2,
        children: /* @__PURE__ */ jsx("div", { class: tableCard, children: /* @__PURE__ */ jsx("table", { class: table, children: /* @__PURE__ */ jsx("tbody", { children: rows.map((r, i) => /* @__PURE__ */ jsxs(
          "tr",
          {
            class: `${tableRow} ${tableVisible ? rowAnimated : ""}`,
            style: { animationDelay: `${0.08 * i}s` },
            children: [
              /* @__PURE__ */ jsx("td", { class: `${tableCell} ${cellMethod}`, children: /* @__PURE__ */ jsx(MethodBadge, { method: r.method }) }),
              /* @__PURE__ */ jsx("td", { class: `${tableCell} ${cellPath}`, children: r.path }),
              /* @__PURE__ */ jsx("td", { class: `${tableCell} ${cellArrow}`, children: "→" }),
              /* @__PURE__ */ jsx("td", { class: `${tableCell} ${cellModule}`, children: r.module }),
              /* @__PURE__ */ jsx("td", { class: `${tableCell} ${cellMw}`, children: r.middlewares.map((mw) => /* @__PURE__ */ jsxs("span", { class: mwBadge, children: [
                "🛡 ",
                mw
              ] }, mw)) })
            ]
          },
          `${r.method}-${r.path}`
        )) }) }) })
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        ref: takeawaysRef,
        class: takeawaysVisible2 ? fadeVisible$2 : fadeHidden$2,
        children: /* @__PURE__ */ jsxs("div", { class: takeaways$1, children: [
          /* @__PURE__ */ jsxs("div", { class: takeaway$1, children: [
            /* @__PURE__ */ jsx("span", { class: takeawayDot$1 }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { class: takeawayTitle$1, children: "Paths compose automatically" }),
              /* @__PURE__ */ jsxs("p", { class: takeawayDesc$1, children: [
                "Nested ",
                /* @__PURE__ */ jsx("code", { children: "path" }),
                " segments stack up. ",
                /* @__PURE__ */ jsx("code", { children: "/app" }),
                " ",
                "+ ",
                /* @__PURE__ */ jsx("code", { children: "/dashboard" }),
                " becomes ",
                /* @__PURE__ */ jsx("code", { children: "/app/dashboard" }),
                "."
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { class: takeaway$1, children: [
            /* @__PURE__ */ jsx("span", { class: takeawayDot$1 }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { class: takeawayTitle$1, children: "Middleware flows down the branches" }),
              /* @__PURE__ */ jsxs("p", { class: takeawayDesc$1, children: [
                "Set on a parent node, inherited by every descendant. Auth on ",
                /* @__PURE__ */ jsx("code", { children: "/app" }),
                " protects every route under it."
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { class: takeaway$1, children: [
            /* @__PURE__ */ jsx("span", { class: takeawayDot$1 }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { class: takeawayTitle$1, children: "One tree, all HTTP surfaces" }),
              /* @__PURE__ */ jsx("p", { class: takeawayDesc$1, children: "Pages, APIs, webhooks — declared side by side. The framework discovers them by shape." })
            ] })
          ] })
        ] })
      }
    )
  ] });
}
var section$2 = "_1bfbgf00";
var header$1 = "_1bfbgf01";
var title$2 = "_1bfbgf02";
var subtitle$1 = "_1bfbgf03";
var codeWrap = "_1bfbgf04";
var fadeHidden$1 = "_1bfbgf05";
var fadeVisible$1 = "_1bfbgf06";
var takeawaysFadeHidden = "_1bfbgf07";
var takeawaysFadeVisible = "_1bfbgf08";
var tabStrip = "_1bfbgf09";
var tab = "_1bfbgf0a";
var tabActive = "_1bfbgf0b";
var bodySlot = "_1bfbgf0c";
var slot = "_1bfbgf0d";
var slotActive = "_1bfbgf0e";
var takeaways = "_1bfbgf0f";
var takeaway = "_1bfbgf0g";
var takeawayDot = "_1bfbgf0h";
var takeawayTitle = "_1bfbgf0i";
var takeawayDesc = "_1bfbgf0j";
function RealtimeShowcase({ streamHtml, socketHtml }) {
  const activeTab = useSignal("stream");
  const [codeRef, codeVisible2] = useInView(0.2);
  const [takeawaysRef, takeawaysVisible2] = useInView(0.2);
  const tabStrip$1 = /* @__PURE__ */ jsxs("div", { class: tabStrip, children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        class: `${tab} ${activeTab.value === "stream" ? tabActive : ""}`,
        onClick: () => activeTab.value = "stream",
        "aria-pressed": activeTab.value === "stream",
        children: "stream_*"
      }
    ),
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        class: `${tab} ${activeTab.value === "socket" ? tabActive : ""}`,
        onClick: () => activeTab.value = "socket",
        "aria-pressed": activeTab.value === "socket",
        children: "socket_*"
      }
    )
  ] });
  return /* @__PURE__ */ jsxs("section", { class: section$2, children: [
    /* @__PURE__ */ jsxs("div", { class: header$1, children: [
      /* @__PURE__ */ jsx("h2", { class: title$2, children: "Real-time, when you need it." }),
      /* @__PURE__ */ jsxs("p", { class: subtitle$1, children: [
        "Push events with ",
        /* @__PURE__ */ jsx("code", { children: "stream_*" }),
        ". Open a bidirectional connection with ",
        /* @__PURE__ */ jsx("code", { children: "socket_*" }),
        ". Same shape as loader and action — declare, export, done."
      ] })
    ] }),
    /* @__PURE__ */ jsx(
      "div",
      {
        ref: codeRef,
        class: `${codeWrap} ${codeVisible2 ? fadeVisible$1 : fadeHidden$1}`,
        children: /* @__PURE__ */ jsx(CodeWindow, { titlebarContent: tabStrip$1, children: /* @__PURE__ */ jsxs("div", { class: bodySlot, children: [
          /* @__PURE__ */ jsx(
            "div",
            {
              class: `${slot} ${activeTab.value === "stream" ? slotActive : ""}`,
              dangerouslySetInnerHTML: { __html: streamHtml }
            }
          ),
          /* @__PURE__ */ jsx(
            "div",
            {
              class: `${slot} ${activeTab.value === "socket" ? slotActive : ""}`,
              dangerouslySetInnerHTML: { __html: socketHtml }
            }
          )
        ] }) })
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        ref: takeawaysRef,
        class: takeawaysVisible2 ? takeawaysFadeVisible : takeawaysFadeHidden,
        children: /* @__PURE__ */ jsxs("div", { class: takeaways, children: [
          /* @__PURE__ */ jsxs("div", { class: takeaway, children: [
            /* @__PURE__ */ jsx("span", { class: takeawayDot }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { class: takeawayTitle, children: "Server pushes to the client" }),
              /* @__PURE__ */ jsxs("p", { class: takeawayDesc, children: [
                /* @__PURE__ */ jsx("code", { children: "stream_*" }),
                " broadcasts events via SSE. The framework handles the transport; the browser reconnects automatically."
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { class: takeaway, children: [
            /* @__PURE__ */ jsx("span", { class: takeawayDot }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { class: takeawayTitle, children: "Two-way when it matters" }),
              /* @__PURE__ */ jsxs("p", { class: takeawayDesc, children: [
                /* @__PURE__ */ jsx("code", { children: "socket_*" }),
                " opens a WebSocket. Client and server speak through the same typed primitive, in the same file."
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { class: takeaway, children: [
            /* @__PURE__ */ jsx("span", { class: takeawayDot }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { class: takeawayTitle, children: "Same middleware tree" }),
              /* @__PURE__ */ jsx("p", { class: takeawayDesc, children: "Auth, rate limits — same inheritance as pages and actions. Real-time doesn't break your route structure." })
            ] })
          ] })
        ] })
      }
    )
  ] });
}
var section$1 = "jdk15c0";
var header = "jdk15c1";
var title$1 = "jdk15c2";
var subtitle = "jdk15c3";
var grid = "jdk15c4";
var card = "jdk15c5";
var cardVisible = "jdk15c6";
var cardIcon = "jdk15c7";
var cardTitle = "jdk15c8";
var cardDesc = "jdk15c9";
function FeatureGrid({
  features: features2,
  title: title2 = "Everything else, included.",
  subtitle: subtitle$12 = "No plugins to add, no escape hatches. The platform under the framework is already production-ready."
}) {
  const [ref, visible] = useInView(0.15);
  const handleMove = (e) => {
    const card2 = e.currentTarget;
    const rect = card2.getBoundingClientRect();
    card2.style.setProperty("--mouse-x", `${e.clientX - rect.left}px`);
    card2.style.setProperty("--mouse-y", `${e.clientY - rect.top}px`);
  };
  return /* @__PURE__ */ jsxs("section", { class: section$1, children: [
    /* @__PURE__ */ jsxs("div", { class: header, children: [
      /* @__PURE__ */ jsx("h2", { class: title$1, children: title2 }),
      /* @__PURE__ */ jsx("p", { class: subtitle, children: subtitle$12 })
    ] }),
    /* @__PURE__ */ jsx("div", { ref, class: grid, children: features2.map((f, i) => /* @__PURE__ */ jsxs(
      "div",
      {
        class: `${card} ${visible ? cardVisible : ""}`,
        style: { transitionDelay: `${i * 0.06}s` },
        onMouseMove: handleMove,
        children: [
          /* @__PURE__ */ jsx(f.Icon, { class: cardIcon, size: 28 }),
          /* @__PURE__ */ jsx("h3", { class: cardTitle, children: f.title }),
          /* @__PURE__ */ jsx("p", { class: cardDesc, children: f.desc })
        ]
      },
      f.title
    )) })
  ] });
}
var section = "_1pln2by0";
var title = "_1pln2by1";
var terminalWrap = "_1pln2by2";
var tbStrip = "_1pln2by3";
var tbLabel = "_1pln2by4";
var copyBtn = "_1pln2by5";
var copyBtnCopied = "_1pln2by6";
var command = "_1pln2by7";
var prompt = "_1pln2by8";
var actions = "_1pln2bya";
var btnPrimary = "_1pln2byb";
var btnSecondary = "_1pln2byc";
var fadeHidden = "_1pln2byd";
var fadeVisible = "_1pln2bye";
const INSTALL_COMMAND = "npx @mauroandre/velojs init my-app";
function CallToAction() {
  const [ref, visible] = useInView(0.2);
  const copied = useSignal(false);
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(INSTALL_COMMAND);
      copied.value = true;
      setTimeout(() => {
        copied.value = false;
      }, 1500);
    } catch {
    }
  };
  const titlebar = /* @__PURE__ */ jsxs("div", { class: tbStrip, children: [
    /* @__PURE__ */ jsx("span", { class: tbLabel, children: "bash" }),
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        class: `${copyBtn} ${copied.value ? copyBtnCopied : ""}`,
        onClick: handleCopy,
        "aria-label": "Copy install command",
        children: copied.value ? "Copied" : "Copy"
      }
    )
  ] });
  return /* @__PURE__ */ jsx("section", { class: section, children: /* @__PURE__ */ jsxs("div", { ref, class: visible ? fadeVisible : fadeHidden, children: [
    /* @__PURE__ */ jsx("h2", { class: title, children: "Get from zero to running in seconds." }),
    /* @__PURE__ */ jsx("div", { class: terminalWrap, children: /* @__PURE__ */ jsx(CodeWindow, { titlebarContent: titlebar, children: /* @__PURE__ */ jsxs("div", { class: command, children: [
      /* @__PURE__ */ jsx("span", { class: prompt, children: "$" }),
      /* @__PURE__ */ jsx("span", { children: INSTALL_COMMAND })
    ] }) }) }),
    /* @__PURE__ */ jsxs("div", { class: actions, children: [
      /* @__PURE__ */ jsx(Link, { to: "/docs/getting-started", class: btnPrimary, children: "Read the docs" }),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "https://github.com/mauro-andre/velojs",
          target: "_blank",
          class: btnSecondary,
          children: "View on GitHub"
        }
      )
    ] })
  ] }) });
}
let highlighterPromise = null;
async function getHighlighter() {
  if (!highlighterPromise) {
    highlighterPromise = createHighlighter({
      themes: ["one-dark-pro"],
      langs: ["tsx", "typescript", "bash", "json"]
    });
  }
  return highlighterPromise;
}
async function highlight(code, lang = "tsx") {
  const h = await getHighlighter();
  return h.codeToHtml(code.trim(), { lang, theme: "one-dark-pro" });
}
const metadata$2 = { moduleId: "Landing", fullPath: "/", path: "/" };
const PRODUCTS_TSX = `// app/Products.tsx

// Runs on the server — fetches the products list
export const loader = async () => ({
    products: await db.products.findMany(),
});

// Toggle a product's active state on the server
export const action_toggleActiveProduct = async ({ body }) => {
    await db.products.toggleActive(body.id);
};

export const Component = () => {
    // Reads the products from the loader
    const { data } = useLoader();

    // Calls the server action for the given product id
    const toggle = (id) => action_toggleActiveProduct({ body: { id } });

    return (
        <ul>
            {data.value?.products.map(p => (
                <li key={p.id}>
                    {p.name}
                    <button onClick={() => toggle(p.id)}>Toggle</button>
                </li>
            ))}
        </ul>
    );
};`;
const ROUTES_TSX = `// app/routes.tsx

export default [{
    module: Root,
    isRoot: true,
    children: [
        { path: "/", module: Home },
        {
            path: "/app",
            middlewares: [authMiddleware],
            children: [
                { path: "/dashboard", module: Dashboard },
                { path: "/products", module: Products },
            ],
        },
        // Endpoint, not a page — handles GitHub webhooks
        {
            path: "/api/github",
            method: "POST",
            handler: githubWebhook,
        },
    ],
}];`;
const STREAM_TSX = `// app/Deploy.tsx

// Server pushes events through this stream
export const stream_progress = createEventStream<string>();

export const action_deploy = async () => {
    stream_progress.emit("Build complete");
    stream_progress.emit("Deploy live");
};

export const Component = () => {
    // Subscribes — updates reactively as events arrive
    const { data } = useEventStream(stream_progress);
    return <p>{data.value ?? "Waiting..."}</p>;
};`;
const SOCKET_TSX = `// app/Chat.tsx

// Bidirectional — both sides send and receive
export const socket_chat = async ({ incoming, send, keepOpen }) => {
    send({ from: "server", text: "Hi!" });
    keepOpen();

    // Server receives client messages, replies
    for await (const msg of incoming) {
        send({ from: "server", text: "Got: " + msg.text });
    }
};

export const Component = () => {
    // Receive via onMessage; send via the returned function
    const { send } = useSocket(socket_chat, {
        onMessage: (msg) => console.log(msg),
    });
    return <button onClick={() => send({ text: "Hi!" })}>Say Hi</button>;
};`;
const loader$2 = async (_args) => {
  const [productsHtml, routesHtml, streamHtml, socketHtml] = await Promise.all(
    [
      highlight(PRODUCTS_TSX, "tsx"),
      highlight(ROUTES_TSX, "tsx"),
      highlight(STREAM_TSX, "tsx"),
      highlight(SOCKET_TSX, "tsx")
    ]
  );
  return { productsHtml, routesHtml, streamHtml, socketHtml };
};
const features = [
  {
    Icon: Zap,
    title: "Hybrid SSR + SPA",
    desc: "Server-rendered first paint, client-side navigation after. No opt-in flag — it's how the framework works."
  },
  {
    Icon: CubeTransparent,
    title: "Static Generation",
    desc: "Same component, ship as static HTML. One CLI flag flips it: velojs build --static."
  },
  {
    Icon: Rss,
    title: "Reactive Signals",
    desc: "@preact/signals baked in. Fine-grained updates, no virtual DOM thrash, no re-render storms."
  },
  {
    Icon: Lock,
    title: "Type-Safe",
    desc: "Full TypeScript. Loaders, actions, middlewares — typed end to end. Autocomplete everywhere."
  },
  {
    Icon: Cog,
    title: "Zero Config",
    desc: "One plugin, one install. Hono + Preact + Vite + wouter wired together out of the box."
  },
  {
    Icon: Beaker,
    title: "Testing Built In",
    desc: "createTestApp() spins up your app in memory. HTTP, streams, sockets — all from one API."
  }
];
const Component$2 = () => {
  const { data } = useLoader("Landing");
  return /* @__PURE__ */ jsxs("div", { class: page, children: [
    /* @__PURE__ */ jsx(AmbientBackground, {}),
    /* @__PURE__ */ jsx("nav", { class: nav, children: /* @__PURE__ */ jsxs("div", { class: navInner, children: [
      /* @__PURE__ */ jsx("span", { class: logo, children: "VeloJS" }),
      /* @__PURE__ */ jsxs("div", { class: navLinks, children: [
        /* @__PURE__ */ jsx(Link, { to: "/docs/getting-started", class: navLink, children: "Docs" }),
        /* @__PURE__ */ jsx("a", { href: "https://github.com/mauro-andre/velojs", target: "_blank", class: navLink, children: "GitHub" }),
        /* @__PURE__ */ jsx("a", { href: "https://www.npmjs.com/package/@mauroandre/velojs", target: "_blank", class: navLink, children: "npm" }),
        /* @__PURE__ */ jsx(Link, { to: "/docs/getting-started", class: navCta, children: "Get Started" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("section", { class: hero, children: [
      /* @__PURE__ */ jsx("span", { class: `${heroEyebrow} ${heroStep1}`, children: "VeloJS" }),
      /* @__PURE__ */ jsxs("h1", { class: `${heroTitle} ${heroStep2}`, children: [
        /* @__PURE__ */ jsx("span", { class: heroTitleLine, children: "Full-stack TypeScript." }),
        /* @__PURE__ */ jsx("span", { class: heroTitleLine, children: "One mental model." })
      ] }),
      /* @__PURE__ */ jsx("p", { class: `${heroSubtitle} ${heroStep3}`, children: "Build web apps where server and client share a codebase. Pages, APIs, webhooks, and real-time — one framework, one language, one component." }),
      /* @__PURE__ */ jsxs("div", { class: `${heroActions} ${heroStep4}`, children: [
        /* @__PURE__ */ jsx(Link, { to: "/docs/getting-started", class: btnPrimary$1, children: "Get Started" }),
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "https://github.com/mauro-andre/velojs",
            target: "_blank",
            class: btnSecondary$1,
            children: "View on GitHub"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("ul", { class: `${heroPills} ${heroStep5}`, "aria-label": "What you build with VeloJS", children: [
        /* @__PURE__ */ jsx("li", { class: heroPill, children: "Pages" }),
        /* @__PURE__ */ jsx("li", { class: heroPill, children: "Actions" }),
        /* @__PURE__ */ jsx("li", { class: heroPill, children: "Webhooks" }),
        /* @__PURE__ */ jsx("li", { class: heroPill, children: "Real-time" }),
        /* @__PURE__ */ jsx("li", { class: heroPill, children: "Static sites" })
      ] })
    ] }),
    /* @__PURE__ */ jsx(ComponentAnatomy, {}),
    /* @__PURE__ */ jsx(WritingShowcase, { codeHtml: data.value?.productsHtml ?? "" }),
    /* @__PURE__ */ jsx(RoutesShowcase, { codeHtml: data.value?.routesHtml ?? "" }),
    /* @__PURE__ */ jsx(
      RealtimeShowcase,
      {
        streamHtml: data.value?.streamHtml ?? "",
        socketHtml: data.value?.socketHtml ?? ""
      }
    ),
    /* @__PURE__ */ jsx(FeatureGrid, { features }),
    /* @__PURE__ */ jsx(CallToAction, {}),
    /* @__PURE__ */ jsx("footer", { class: footer, children: /* @__PURE__ */ jsxs("div", { class: footerInner, children: [
      /* @__PURE__ */ jsx("span", { class: logo, children: "VeloJS" }),
      /* @__PURE__ */ jsxs("div", { class: footerLinks, children: [
        /* @__PURE__ */ jsx(Link, { to: "/docs/getting-started", class: footerLink, children: "Docs" }),
        /* @__PURE__ */ jsx("a", { href: "https://github.com/mauro-andre/velojs", target: "_blank", class: footerLink, children: "GitHub" }),
        /* @__PURE__ */ jsx("a", { href: "https://www.npmjs.com/package/@mauroandre/velojs", target: "_blank", class: footerLink, children: "npm" })
      ] }),
      /* @__PURE__ */ jsxs("p", { class: footerCopyright, children: [
        "© ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " Mauro André Silva. MIT License."
      ] })
    ] }) })
  ] });
};
const Landing = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Component: Component$2,
  loader: loader$2,
  metadata: metadata$2
}, Symbol.toStringTag, { value: "Module" }));
var layout = "_10zzsyq0";
var sidebar = "_10zzsyq1";
var sidebarVisible = "_10zzsyq2";
var sidebarHeader = "_10zzsyq3";
var sidebarLogo = "_10zzsyq4";
var sidebarNav = "_10zzsyq5";
var sidebarLink = "_10zzsyq6";
var sidebarLinkActive = "_10zzsyq7";
var sidebarFooter = "_10zzsyq8";
var downloadBtn = "_10zzsyq9";
var mobileToggle = "_10zzsyqa";
var content = "_10zzsyqb";
var contentHeader = "_10zzsyqc";
var contentTitle = "_10zzsyqd";
var downloadMdBtn = "_10zzsyqe";
var prevNext = "_10zzsyqf";
var prevNextLink = "_10zzsyqg";
var prevNextLabel = "_10zzsyqh";
var prevNextTitle = "_10zzsyqi";
var prose = "_10zzsyqj";
const metadata$1 = { moduleId: "docs/Layout", fullPath: "/docs", path: "/docs" };
const loader$1 = async ({}) => {
  const { default: manifest } = await import("./assets/_virtual_docs-manifest-C0Va-fz6.js");
  return { manifest };
};
const Component$1 = ({ children }) => {
  const sidebarOpen = useSignal(false);
  const pathname = usePathname();
  const { data } = useLoader("docs/Layout", [pathname]);
  const entries = data.value?.manifest ?? [];
  return /* @__PURE__ */ jsxs("div", { class: layout, children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        class: mobileToggle,
        onClick: () => sidebarOpen.value = !sidebarOpen.value,
        children: sidebarOpen.value ? "✕" : "☰"
      }
    ),
    /* @__PURE__ */ jsxs("aside", { class: `${sidebar} ${sidebarOpen.value ? sidebarVisible : ""}`, children: [
      /* @__PURE__ */ jsx("div", { class: sidebarHeader, children: /* @__PURE__ */ jsx(Link, { to: "~/", class: sidebarLogo, children: "VeloJS" }) }),
      /* @__PURE__ */ jsx("nav", { class: sidebarNav, children: entries.map(
        (entry) => /* @__PURE__ */ jsx(
          Link,
          {
            to: `/${entry.slug}`,
            class: `${sidebarLink} ${pathname === `/docs/${entry.slug}` ? sidebarLinkActive : ""}`,
            children: entry.title
          },
          entry.slug
        )
      ) }),
      /* @__PURE__ */ jsx("div", { class: sidebarFooter, children: /* @__PURE__ */ jsx("a", { href: "/docs/velojs-docs.zip", download: true, class: downloadBtn, children: "↓ Download all docs (.zip)" }) })
    ] }),
    /* @__PURE__ */ jsx("main", { class: content, children })
  ] });
};
const DocsLayout = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Component: Component$1,
  loader: loader$1,
  metadata: metadata$1
}, Symbol.toStringTag, { value: "Module" }));
const metadata = { moduleId: "docs/DocPage", fullPath: "/docs/:slug", path: "/:slug" };
const staticPaths = async () => {
  const { default: manifest } = await import("./assets/_virtual_docs-manifest-C0Va-fz6.js");
  return manifest.map((entry) => ({ slug: entry.slug }));
};
const loader = async ({ params }) => {
  const { default: manifest } = await import("./assets/_virtual_docs-manifest-C0Va-fz6.js");
  const { default: content2 } = await import("./assets/_virtual_docs-content-Db60MvOP.js");
  const slug = params.slug;
  const doc = content2[slug];
  const entry = manifest.find((m) => m.slug === slug);
  const index = manifest.findIndex((m) => m.slug === slug);
  const prev = index > 0 ? manifest[index - 1] : null;
  const next = index < manifest.length - 1 ? manifest[index + 1] : null;
  return {
    html: doc?.html ?? "",
    title: entry?.title ?? slug,
    filename: entry?.filename ?? "",
    prevSlug: prev?.slug ?? null,
    prevTitle: prev?.title ?? null,
    nextSlug: next?.slug ?? null,
    nextTitle: next?.title ?? null
  };
};
const Component = () => {
  const params = useParams();
  const { data } = useLoader("docs/DocPage", [params.slug]);
  if (!data.value) return null;
  const { html, title: title2, filename: filename2, prevSlug, prevTitle, nextSlug, nextTitle } = data.value;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { class: contentHeader, children: [
      /* @__PURE__ */ jsx("h1", { class: contentTitle, children: title2 }),
      filename2 && /* @__PURE__ */ jsx(
        "a",
        {
          href: `/docs/${filename2}`,
          download: true,
          class: downloadMdBtn,
          children: "↓ Download .md"
        }
      )
    ] }),
    /* @__PURE__ */ jsx(
      "div",
      {
        class: prose,
        dangerouslySetInnerHTML: { __html: html }
      }
    ),
    /* @__PURE__ */ jsxs("div", { class: prevNext, children: [
      /* @__PURE__ */ jsx("div", { children: prevSlug && /* @__PURE__ */ jsxs(Link, { to: `/${prevSlug}`, class: prevNextLink, children: [
        /* @__PURE__ */ jsx("span", { class: prevNextLabel, children: "← Previous" }),
        /* @__PURE__ */ jsx("span", { class: prevNextTitle, children: prevTitle })
      ] }) }),
      /* @__PURE__ */ jsx("div", { children: nextSlug && /* @__PURE__ */ jsxs(Link, { to: `/${nextSlug}`, class: prevNextLink, style: { textAlign: "right" }, children: [
        /* @__PURE__ */ jsx("span", { class: prevNextLabel, children: "Next →" }),
        /* @__PURE__ */ jsx("span", { class: prevNextTitle, children: nextTitle })
      ] }) })
    ] })
  ] });
};
const DocPage = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Component,
  loader,
  metadata,
  staticPaths
}, Symbol.toStringTag, { value: "Module" }));
const routes = [
  {
    module: Root,
    isRoot: true,
    children: [
      { path: "/", module: Landing },
      {
        path: "/docs",
        module: DocsLayout,
        children: [
          { path: "/:slug", module: DocPage }
        ]
      }
    ]
  }
];
const adapters = /* @__PURE__ */ new WeakMap();
const appSockets = /* @__PURE__ */ new WeakMap();
const activeSessions = /* @__PURE__ */ new WeakMap();
async function getAdapter(app) {
  let adapter = adapters.get(app);
  if (adapter) return adapter;
  try {
    const mod = await import("@hono/node-ws");
    adapter = mod.createNodeWebSocket({ app });
    adapters.set(app, adapter);
    return adapter;
  } catch (err) {
    console.error("[velojs] failed to load @hono/node-ws:", err);
    return null;
  }
}
function addSession(app, ctrl) {
  let set = activeSessions.get(app);
  if (!set) {
    set = /* @__PURE__ */ new Set();
    activeSessions.set(app, set);
  }
  set.add(ctrl);
}
function removeSession(app, ctrl) {
  activeSessions.get(app)?.delete(ctrl);
}
function buildEvents(app, handler, c) {
  const queue = [];
  let resolveNext = null;
  let streamClosed = false;
  let kept = false;
  let wsRef = null;
  const ctrl = new AbortController();
  addSession(app, ctrl);
  const incoming = {
    async *[Symbol.asyncIterator]() {
      while (true) {
        while (queue.length > 0) {
          yield queue.shift();
        }
        if (streamClosed) return;
        await new Promise((r) => {
          resolveNext = r;
        });
        resolveNext = null;
      }
    }
  };
  const send = (msg) => {
    if (!wsRef || streamClosed) return;
    try {
      if (typeof msg === "string" || msg instanceof Uint8Array) {
        wsRef.send(msg);
      } else {
        wsRef.send(JSON.stringify(msg));
      }
    } catch (err) {
      console.error("[velojs] socket send failed:", err);
    }
  };
  const closeFn = (code, reason) => {
    if (!wsRef) return;
    try {
      wsRef.close(code, reason);
    } catch {
    }
  };
  const keepOpen = () => {
    kept = true;
  };
  const finalize = () => {
    if (!streamClosed) {
      streamClosed = true;
      resolveNext?.();
    }
    if (!ctrl.signal.aborted) {
      try {
        ctrl.abort();
      } catch {
      }
    }
    removeSession(app, ctrl);
  };
  return {
    events: {
      onOpen(_evt, ws) {
        wsRef = ws;
        Promise.resolve(
          handler({
            incoming,
            send,
            close: closeFn,
            keepOpen,
            abortSignal: ctrl.signal,
            c,
            params: c.req.param(),
            query: c.req.query()
          })
        ).then(() => {
          if (!kept && wsRef && !streamClosed) {
            try {
              wsRef.close();
            } catch {
            }
          }
        }).catch((err) => {
          console.error("[velojs] socket handler threw:", err);
          try {
            wsRef?.close(1011, "handler error");
          } catch {
          }
        });
      },
      onMessage(evt) {
        if (streamClosed) return;
        const data = evt.data;
        if (typeof data === "string") {
          queue.push(data);
        } else if (data instanceof ArrayBuffer) {
          queue.push(new Uint8Array(data));
        } else if (data && typeof data === "object" && "buffer" in data && data.buffer instanceof ArrayBuffer) {
          queue.push(new Uint8Array(data.buffer));
        }
        resolveNext?.();
      },
      onClose() {
        finalize();
      },
      onError() {
        finalize();
      }
    },
    cleanup: finalize
  };
}
async function registerSocketHandler(app, path, handler, middlewares = []) {
  let reg = appSockets.get(app);
  if (!reg) {
    reg = /* @__PURE__ */ new Map();
    appSockets.set(app, reg);
  }
  reg.set(path, { path, handler, middlewares });
  const adapter = await getAdapter(app);
  if (!adapter) return;
  const routeMw = adapter.upgradeWebSocket((c) => {
    return buildEvents(app, handler, c).events;
  });
  if (middlewares.length > 0) {
    app.on(["GET"], [path], ...middlewares, routeMw);
  } else {
    app.on(["GET"], [path], routeMw);
  }
}
async function registerSocketRoutes(app, nodes, parentMiddlewares = []) {
  const visit = async (subNodes, inherited) => {
    for (const node of subNodes) {
      const moduleId = node.module?.metadata?.moduleId;
      const currentMw = [...inherited, ...node.middlewares ?? []];
      if (node.module && moduleId) {
        for (const key of Object.keys(node.module)) {
          if (!key.startsWith("socket_")) continue;
          const handler = node.module[key];
          if (typeof handler !== "function") {
            console.warn(
              `[velojs] socket_* export ${moduleId}/${key} is not a function; skipped`
            );
            continue;
          }
          const name = key.replace("socket_", "");
          const path = `/_socket/${moduleId}/${name}`;
          try {
            handler.__path = path;
          } catch {
          }
          try {
            handler.__isVeloSocket = true;
          } catch {
          }
          await registerSocketHandler(app, path, handler, currentMw);
        }
      }
      if (node.children) await visit(node.children, currentMw);
    }
  };
  await visit(nodes, parentMiddlewares);
}
async function injectWebSocketServer(app, server) {
  const adapter = adapters.get(app);
  if (!adapter) return;
  const filteredServer = new Proxy(server, {
    get(target, prop, receiver) {
      if (prop === "on" || prop === "addListener") {
        return (event, listener) => {
          if (event !== "upgrade") {
            return target[prop](event, listener);
          }
          return target[prop]("upgrade", (req, socket, head) => {
            const host = req.headers?.host ?? "localhost";
            let pathname;
            try {
              pathname = new URL(req.url ?? "/", `http://${host}`).pathname;
            } catch {
              return;
            }
            if (!appSockets.get(app)?.has(pathname)) return;
            listener(req, socket, head);
          });
        };
      }
      return Reflect.get(target, prop, receiver);
    }
  });
  try {
    adapter.injectWebSocket(filteredServer);
  } catch (err) {
    console.error("[velojs] injectWebSocket failed:", err);
  }
}
const serverDataStorage = new AsyncLocalStorage();
globalThis.__veloServerData = serverDataStorage;
function flushServerCallbacks(server) {
  const ctx = getAppContext();
  for (const fn of ctx.serverCallbacks) fn(server);
  ctx.serverCallbacks.length = 0;
}
const renderPage = (c, Component2, data, statusCode) => {
  if (statusCode && statusCode !== 200) {
    c.status(statusCode);
  }
  if (c.req.query("_data") === "1") {
    const buildHash = globalThis.__veloBuildHash || void 0;
    const json = data ? { ...data, __buildHash: buildHash } : { __buildHash: buildHash };
    return c.json(json);
  }
  const path = c.req.path;
  const html = serverDataStorage.run(
    data ?? {},
    () => {
      return render(/* @__PURE__ */ jsx(Router, { ssrPath: path, children: Component2 }));
    }
  );
  c.header("Cache-Control", "no-cache");
  if (!data) {
    return c.html(html);
  }
  const script = `<script>window.__PAGE_DATA__=${JSON.stringify(
    data
  )}<\/script>`;
  return c.html(html.replace("</head>", `${script}</head>`));
};
const loadPage = async (modules, c) => {
  const params = c.req.param();
  const query = c.req.query();
  const loaderArgs = { params, query, c };
  const results = await Promise.all(
    modules.map(async (module) => {
      if (!module.loader) return null;
      const loaderData = await module.loader(loaderArgs);
      const moduleId = module.metadata?.moduleId;
      return moduleId ? { moduleId, loaderData } : null;
    })
  );
  const data = {
    __params: params,
    __query: query,
    __pathname: c.req.path
  };
  for (const result of results) {
    if (result) {
      data[result.moduleId] = result.loaderData;
    }
  }
  return {
    components: modules.map((m) => m.Component),
    data
  };
};
const nestComponents = (components) => {
  if (components.length === 0) return null;
  const validComponents = components.filter(Boolean);
  if (validComponents.length === 0) return null;
  if (validComponents.length === 1) {
    const Page2 = validComponents[0];
    return /* @__PURE__ */ jsx(Page2, {});
  }
  const Page = validComponents[validComponents.length - 1];
  const layouts = validComponents.slice(0, -1);
  return layouts.reduceRight((child, Layout) => {
    return /* @__PURE__ */ jsx(Layout, { children: child });
  }, /* @__PURE__ */ jsx(Page, {}));
};
const registerRoutes = (app, nodes, parentModules = [], parentMiddlewares = []) => {
  for (const node of nodes) {
    if (node.handler && !node.module) {
      if (node.children) {
        registerRoutes(
          app,
          node.children,
          parentModules,
          [...parentMiddlewares, ...node.middlewares || []]
        );
      }
      continue;
    }
    const currentModules = node.module ? [...parentModules, node.module] : parentModules;
    const currentMiddlewares = [
      ...parentMiddlewares,
      ...node.middlewares || []
    ];
    if (node.children) {
      registerRoutes(
        app,
        node.children,
        currentModules,
        currentMiddlewares
      );
    } else if (!node.module) {
      continue;
    } else {
      const isCatchAll = node.path === "*";
      const statusCode = node.statusCode ?? (isCatchAll ? 404 : void 0);
      const fullPath = node.module.metadata?.fullPath;
      if (!fullPath && !isCatchAll) {
        console.warn(
          `Module ${node.module.metadata?.moduleId} has no fullPath`
        );
        continue;
      }
      const handler = async (c) => {
        const { components, data } = await loadPage(currentModules, c);
        const nested = nestComponents(components);
        return renderPage(c, nested, data, statusCode);
      };
      if (isCatchAll) {
        app.notFound(handler);
      } else if (currentMiddlewares.length > 0) {
        app.on(["GET"], [fullPath], ...currentMiddlewares, handler);
      } else {
        app.on(["GET"], [fullPath], handler);
      }
    }
  }
};
const registerActionRoutes = (app, nodes, parentMiddlewares = []) => {
  for (const node of nodes) {
    const moduleId = node.module?.metadata?.moduleId;
    const currentMiddlewares = [
      ...parentMiddlewares,
      ...node.middlewares || []
    ];
    if (node.module && moduleId) {
      const actionKeys = Object.keys(node.module).filter(
        (k) => k.startsWith("action_")
      );
      for (const actionKey of actionKeys) {
        const actionName = actionKey.replace("action_", "");
        const action = node.module[actionKey];
        if (typeof action === "function") {
          const actionPath = `/_action/${moduleId}/${actionName}`;
          const handler = async (c) => {
            let body2 = {};
            try {
              body2 = await c.req.json();
            } catch {
            }
            const actionArgs = {
              body: body2,
              params: c.req.param(),
              query: c.req.query(),
              c
            };
            try {
              const result = await action(actionArgs);
              return c.json(result ?? { ok: true });
            } catch (error) {
              const message = error instanceof Error ? error.message : "Action failed";
              return c.json({ error: message }, 500);
            }
          };
          if (currentMiddlewares.length > 0) {
            app.on(
              ["POST"],
              [actionPath],
              ...currentMiddlewares,
              handler
            );
          } else {
            app.on(["POST"], [actionPath], handler);
          }
        }
      }
    }
    if (node.children) {
      registerActionRoutes(app, node.children, currentMiddlewares);
    }
  }
};
const registerStreamRoutes = async (app, nodes, parentMiddlewares = []) => {
  const visit = (subNodes, inheritedMiddlewares) => {
    for (const node of subNodes) {
      const moduleId = node.module?.metadata?.moduleId;
      const currentMiddlewares = [
        ...inheritedMiddlewares,
        ...node.middlewares || []
      ];
      if (node.module && moduleId) {
        const streamKeys = Object.keys(node.module).filter(
          (k) => k.startsWith("stream_")
        );
        for (const streamKey of streamKeys) {
          const streamName = streamKey.replace("stream_", "");
          const stream = node.module[streamKey];
          if (stream?.__isVeloEventStream) {
            const streamPath = `/_event/${moduleId}/${streamName}`;
            stream.__path = streamPath;
            registerStreamHandler(
              app,
              streamPath,
              stream,
              currentMiddlewares
            );
          }
        }
      }
      if (node.children) {
        visit(node.children, currentMiddlewares);
      }
    }
  };
  visit(nodes, parentMiddlewares);
};
const joinPath = (parent, segment) => {
  if (!segment) return parent || "";
  return segment.startsWith("/") ? parent + segment : parent ? parent + "/" + segment : "/" + segment;
};
const collectPageGetPaths = (nodes) => {
  const paths = /* @__PURE__ */ new Set();
  const walk = (subNodes) => {
    for (const node of subNodes) {
      if (node.module && !node.children) {
        const fullPath = node.module.metadata?.fullPath;
        if (fullPath) paths.add(fullPath);
      }
      if (node.children) walk(node.children);
    }
  };
  walk(nodes);
  return paths;
};
const registerEndpointRoutes = (app, nodes, pageGetPaths, parentPath = "", parentMiddlewares = []) => {
  for (const node of nodes) {
    const fullPath = joinPath(parentPath, node.path);
    const currentMiddlewares = [
      ...parentMiddlewares,
      ...node.middlewares || []
    ];
    const hasHandler = !!node.handler;
    const hasMethod = !!node.method;
    if (hasHandler && !hasMethod) {
      console.warn(
        `[velojs] invalid route at "${fullPath || "/"}" — "handler" set without "method"; endpoint skipped`
      );
    } else if (hasMethod && !hasHandler) {
      console.warn(
        `[velojs] invalid route at "${fullPath || "/"}" — "method" set without "handler"; endpoint skipped`
      );
    } else if (hasHandler && node.module) {
      console.warn(
        `[velojs] ambiguous route at "${fullPath || "/"}" — both "module" and "handler" set; endpoint ignored, page kept`
      );
    } else if (hasHandler && node.isRoot) {
      console.warn(
        `[velojs] "isRoot" has no effect on endpoint at "${fullPath || "/"}"; ignored`
      );
    }
    const canRegister = hasHandler && hasMethod && !node.module;
    if (canRegister) {
      const method = node.method;
      if (method === "GET" && pageGetPaths.has(fullPath)) {
        console.warn(
          `[velojs] path "${fullPath}" has both a page GET and an endpoint GET; endpoint will win. Consider renaming one.`
        );
      }
      const handlerFn = node.handler;
      const wrapped = async (c) => {
        return await handlerFn({
          c,
          params: c.req.param(),
          query: c.req.query()
        });
      };
      if (currentMiddlewares.length > 0) {
        app.on([method], [fullPath], ...currentMiddlewares, wrapped);
      } else {
        app.on([method], [fullPath], wrapped);
      }
    }
    if (node.children) {
      registerEndpointRoutes(
        app,
        node.children,
        pageGetPaths,
        fullPath,
        currentMiddlewares
      );
    }
  }
};
const createApp = async (routes2) => {
  const app = new Hono();
  app.use(trimTrailingSlash());
  const ctx = getAppContext();
  const pending = ctx.pendingRoutes.splice(0);
  for (const fn of pending) {
    await fn(app);
  }
  registerRoutes(app, routes2);
  registerActionRoutes(app, routes2);
  await registerStreamRoutes(app, routes2);
  const pageGetPaths = collectPageGetPaths(routes2);
  registerEndpointRoutes(app, routes2, pageGetPaths);
  await registerSocketRoutes(app, routes2);
  flushPendingStreamRoutes(app);
  return app;
};
const startServer = async (options) => {
  const { routes: routes2 } = options;
  const port = Number(process.env.PORT) || options.port || 3e3;
  const app = await createApp(routes2);
  if (!process.env.VELO_STATIC) {
    const { serve } = await import("@hono/node-server");
    const { serveStatic } = await import("@hono/node-server/serve-static");
    const { join } = await import("node:path");
    const clientDir = join(process.cwd(), "dist/client");
    const staticUrl = "/client";
    if (!staticUrl.startsWith("http")) {
      app.use("/*", serveStatic({ root: clientDir }));
    }
    console.log(`Server running on http://localhost:${port}`);
    const server = serve({ fetch: app.fetch, port });
    await injectWebSocketServer(app, server);
    flushServerCallbacks(server);
  }
  return app;
};
globalThis.__veloBuildHash = "mqphb2yt";
globalThis.__veloClientJs = "client.BWXN6_Ie.js";
globalThis.__veloClientCss = "client.mGLnjzc4.css";
const serverEntry = await startServer({ routes, port: null });
export {
  serverEntry as default,
  routes
};
