import { jsx, jsxs, Fragment } from "preact/jsx-runtime";
import { useParams as useParams$1, useLocation, useRouter, Link as Link$1, Router } from "wouter-preact";
import { signal, useSignal } from "@preact/signals";
import { useRef, useEffect } from "preact/hooks";
import { Hono } from "hono";
import "hono/logger";
import { trimTrailingSlash } from "hono/trailing-slash";
import { render } from "preact-render-to-string";
import { AsyncLocalStorage } from "node:async_hooks";
const __veloUpdatePending = signal(false);
function useLoader(moduleIdOrDeps, deps) {
  let moduleId;
  let resolvedDeps;
  if (Array.isArray(moduleIdOrDeps)) {
    resolvedDeps = moduleIdOrDeps;
  } else {
    moduleId = moduleIdOrDeps;
    resolvedDeps = deps;
  }
  let initialData = null;
  if (typeof window === "undefined" && moduleId) {
    const storage = globalThis.__veloServerData;
    const serverData = storage?.getStore?.();
    if (serverData?.[moduleId]) {
      initialData = serverData[moduleId];
    }
  }
  if (typeof window !== "undefined" && moduleId) {
    const pageData = window.__PAGE_DATA__;
    if (pageData?.[moduleId]) {
      initialData = pageData[moduleId];
      delete pageData[moduleId];
    }
  }
  const data = useSignal(initialData);
  const loading = useSignal(false);
  const fetchData = () => {
    if (typeof window === "undefined" || !moduleId) return;
    const currentPath = window.location.pathname;
    loading.value = true;
    const dataUrl = `${currentPath === "/" ? "" : currentPath}/index.json`;
    fetch(dataUrl, { cache: "no-cache" }).then((res) => res.json()).then((json) => {
      if (json.__buildHash && json.__buildHash !== "mo86zfro") {
        __veloUpdatePending.value = true;
      }
      data.value = json[moduleId];
      loading.value = false;
    }).catch(() => {
      loading.value = false;
    });
  };
  const isHydrated = useRef(initialData !== null);
  useEffect(() => {
    if (isHydrated.current) {
      isHydrated.current = false;
      return;
    }
    fetchData();
  }, resolvedDeps ?? []);
  return { data, loading, refetch: fetchData };
}
function useParams() {
  if (typeof window === "undefined") {
    const storage = globalThis.__veloServerData;
    const serverData = storage?.getStore?.();
    return serverData?.__params ?? {};
  }
  return useParams$1();
}
function usePathname() {
  if (typeof window === "undefined") {
    const storage = globalThis.__veloServerData;
    const serverData = storage?.getStore?.();
    return serverData?.__pathname ?? "/";
  }
  useLocation();
  return window.location.pathname;
}
function Scripts({ basePath, favicon = "/favicon.ico" } = {}) {
  basePath = basePath || "/client";
  const faviconTag = favicon !== false && /* @__PURE__ */ jsx("link", { rel: "icon", href: `${basePath}${favicon}`, type: "image/x-icon" });
  const jsFile = globalThis.__veloClientJs || "client.CIywn97n.js";
  const cssFile = globalThis.__veloClientCss || "client.wEWg14G5.css";
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    faviconTag,
    /* @__PURE__ */ jsx("link", { rel: "stylesheet", href: `${basePath}/${cssFile}` }),
    /* @__PURE__ */ jsx("script", { type: "module", src: `${basePath}/${jsFile}` })
  ] });
}
function substituteParams(path, params) {
  let result = path;
  for (const [key, value] of Object.entries(params)) {
    result = result.replace(`:${key}`, value);
  }
  return result;
}
function Link({ to, params, search, absolute, ...rest }) {
  const isModule = typeof to !== "string";
  const router = useRouter();
  const basePath = isModule ? (absolute ? to.metadata?.fullPath : to.metadata?.path) ?? "/" : to;
  const finalPath = params ? substituteParams(basePath, params) : basePath;
  const routePath = isModule && absolute ? `~${finalPath}` : finalPath;
  const queryString = search ? `?${new URLSearchParams(search).toString()}` : "";
  const href = `${routePath}${queryString}`;
  if (typeof window !== "undefined" && __veloUpdatePending.value) {
    let fullHref;
    if (isModule) {
      const absPath = to.metadata?.fullPath ?? basePath;
      fullHref = `${params ? substituteParams(absPath, params) : absPath}${queryString}`;
    } else {
      const path = finalPath.replace(/^~/, "");
      const needsBase = !finalPath.startsWith("~") && router.base;
      fullHref = `${needsBase ? router.base : ""}${path}${queryString}`;
    }
    const { onClick, ...anchorRest } = rest;
    return /* @__PURE__ */ jsx(
      "a",
      {
        href: fullHref,
        onClick: (e) => {
          if (onClick) onClick(e);
          if (!e.defaultPrevented) {
            e.preventDefault();
            window.location.href = fullHref;
          }
        },
        ...anchorRest
      }
    );
  }
  return /* @__PURE__ */ jsx(Link$1, { to: href, ...rest });
}
function emptyContext() {
  return {
    pendingRoutes: [],
    pendingStreamRoutes: [],
    serverCallbacks: [],
    disposers: /* @__PURE__ */ new Set()
  };
}
const defaultContext = emptyContext();
let currentContext = defaultContext;
function getAppContext() {
  return currentContext;
}
const metadata$3 = { moduleId: "client-root", fullPath: "", path: "" };
const Component$3 = ({ children }) => {
  return /* @__PURE__ */ jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxs("head", { children: [
      /* @__PURE__ */ jsx("meta", { charSet: "utf-8" }),
      /* @__PURE__ */ jsx("meta", { name: "viewport", content: "width=device-width, initial-scale=1.0" }),
      /* @__PURE__ */ jsx("title", { children: "VeloJS — Fullstack Web Framework" }),
      /* @__PURE__ */ jsx("meta", { name: "description", content: "Fullstack web framework built on Hono + Preact with Vite-powered AST transforms. SSR, hydration, RPC actions, file-based routing — zero config." }),
      /* @__PURE__ */ jsx("link", { rel: "preconnect", href: "https://fonts.googleapis.com" }),
      /* @__PURE__ */ jsx("link", { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" }),
      /* @__PURE__ */ jsx("link", { href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap", rel: "stylesheet" }),
      /* @__PURE__ */ jsx(Scripts, {})
    ] }),
    /* @__PURE__ */ jsx("body", { children })
  ] });
};
const Root = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Component: Component$3,
  metadata: metadata$3
}, Symbol.toStringTag, { value: "Module" }));
var page = "emptfk0";
var nav = "emptfk1";
var navInner = "emptfk2";
var logo = "emptfk3";
var navLinks = "emptfk4";
var navLink = "emptfk5";
var navCta = "emptfk6";
var hero = "emptfk7";
var heroTitle = "emptfk8";
var heroTagline = "emptfk9";
var heroSubtitle = "emptfka";
var heroActions = "emptfkb";
var btnPrimary = "emptfkc";
var btnSecondary = "emptfkd";
var section = "emptfke";
var sectionTitle = "emptfkf";
var sectionSubtitle = "emptfkg";
var featuresGrid = "emptfkh";
var featureCard = "emptfki";
var featureIcon = "emptfkj";
var featureTitle = "emptfkk";
var featureDesc = "emptfkl";
var installSection = "emptfkq";
var installCode = "emptfkr";
var footer = "emptfks";
var footerInner = "emptfkt";
var footerLinks = "emptfku";
var footerLink = "emptfkv";
var footerCopyright = "emptfkw";
const metadata$2 = { moduleId: "Landing", fullPath: "/", path: "/" };
const features = [
  {
    icon: "🌳",
    title: "File-Based Routing",
    desc: "Define your entire app as a route tree in routes.tsx. Nested layouts, automatic path resolution, and middleware inheritance."
  },
  {
    icon: "⚡",
    title: "SSR + Hydration",
    desc: "Server-side rendering with seamless client hydration. Loaders run in parallel on the server, data flows automatically."
  },
  {
    icon: "🔄",
    title: "RPC Actions",
    desc: "Write server functions, call them from the client. The Vite plugin transforms action bodies into fetch stubs via AST."
  },
  {
    icon: "📡",
    title: "Reactive Signals",
    desc: "@preact/signals for fine-grained reactivity. No re-renders, no selectors — just signals that update the DOM directly."
  },
  {
    icon: "📦",
    title: "Zero Config",
    desc: "One plugin, one install. Hono, Preact, Vite, wouter — everything included and wired together out of the box."
  },
  {
    icon: "🔒",
    title: "Type-Safe",
    desc: "Full TypeScript. Typed loaders, actions, route modules, and middleware. Autocomplete everywhere."
  }
];
const Component$2 = () => {
  return /* @__PURE__ */ jsxs("div", { class: page, children: [
    /* @__PURE__ */ jsx("nav", { class: nav, children: /* @__PURE__ */ jsxs("div", { class: navInner, children: [
      /* @__PURE__ */ jsx("span", { class: logo, children: "VeloJS" }),
      /* @__PURE__ */ jsxs("div", { class: navLinks, children: [
        /* @__PURE__ */ jsx(Link, { to: "/docs/getting-started", class: navLink, children: "Docs" }),
        /* @__PURE__ */ jsx("a", { href: "https://github.com/mauro-andre/velojs", target: "_blank", class: navLink, children: "GitHub" }),
        /* @__PURE__ */ jsx("a", { href: "https://www.npmjs.com/package/@mauroandre/velojs", target: "_blank", class: navLink, children: "npm" }),
        /* @__PURE__ */ jsx(Link, { to: "/docs/getting-started", class: navCta, children: "Get Started" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("section", { class: hero, children: [
      /* @__PURE__ */ jsx("h1", { class: heroTitle, children: "VeloJS" }),
      /* @__PURE__ */ jsx("p", { class: heroTagline, children: "Fullstack web framework that just works" }),
      /* @__PURE__ */ jsx("p", { class: heroSubtitle, children: "Hono + Preact + Vite. Server-side rendering, client hydration, RPC actions, nested routing — everything wired together with a single plugin." }),
      /* @__PURE__ */ jsxs("div", { class: heroActions, children: [
        /* @__PURE__ */ jsx(Link, { to: "/docs/getting-started", class: btnPrimary, children: "Get Started" }),
        /* @__PURE__ */ jsx("a", { href: "https://github.com/mauro-andre/velojs", target: "_blank", class: btnSecondary, children: "View on GitHub" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { class: installSection, children: [
      /* @__PURE__ */ jsx("h2", { class: sectionTitle, children: "Get started in seconds" }),
      /* @__PURE__ */ jsx("code", { class: installCode, children: "npx @mauroandre/velojs init my-app" })
    ] }),
    /* @__PURE__ */ jsxs("section", { class: section, children: [
      /* @__PURE__ */ jsx("h2", { class: sectionTitle, children: "Everything you need" }),
      /* @__PURE__ */ jsx("p", { class: sectionSubtitle, children: "An opinionated fullstack framework that handles routing, SSR, state, and builds — so you can focus on your app." }),
      /* @__PURE__ */ jsx("div", { class: featuresGrid, children: features.map(
        (f, i) => /* @__PURE__ */ jsxs("div", { class: featureCard, children: [
          /* @__PURE__ */ jsx("span", { class: featureIcon, children: f.icon }),
          /* @__PURE__ */ jsx("h3", { class: featureTitle, children: f.title }),
          /* @__PURE__ */ jsx("p", { class: featureDesc, children: f.desc })
        ] }, i)
      ) })
    ] }),
    /* @__PURE__ */ jsx("footer", { class: footer, children: /* @__PURE__ */ jsxs("div", { class: footerInner, children: [
      /* @__PURE__ */ jsx("span", { class: logo, children: "VeloJS" }),
      /* @__PURE__ */ jsxs("div", { class: footerLinks, children: [
        /* @__PURE__ */ jsx(Link, { to: "/docs/getting-started", class: footerLink, children: "Docs" }),
        /* @__PURE__ */ jsx("a", { href: "https://github.com/mauro-andre/velojs", target: "_blank", class: footerLink, children: "GitHub" }),
        /* @__PURE__ */ jsx("a", { href: "https://www.npmjs.com/package/@mauroandre/velojs", target: "_blank", class: footerLink, children: "npm" })
      ] }),
      /* @__PURE__ */ jsx("p", { class: footerCopyright, children: "© 2025 Mauro André Silva. MIT License." })
    ] }) })
  ] });
};
const Landing = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Component: Component$2,
  metadata: metadata$2
}, Symbol.toStringTag, { value: "Module" }));
var layout = "_10zzsyq0";
var sidebar = "_10zzsyq1";
var sidebarVisible = "_10zzsyq2";
var sidebarHeader = "_10zzsyq3";
var sidebarLogo = "_10zzsyq4";
var sidebarNav = "_10zzsyq5";
var sidebarLink = "_10zzsyq6";
var sidebarLinkActive = "_10zzsyq7";
var sidebarFooter = "_10zzsyq8";
var downloadBtn = "_10zzsyq9";
var mobileToggle = "_10zzsyqa";
var content = "_10zzsyqb";
var contentHeader = "_10zzsyqc";
var contentTitle = "_10zzsyqd";
var downloadMdBtn = "_10zzsyqe";
var prevNext = "_10zzsyqf";
var prevNextLink = "_10zzsyqg";
var prevNextLabel = "_10zzsyqh";
var prevNextTitle = "_10zzsyqi";
var prose = "_10zzsyqj";
const metadata$1 = { moduleId: "docs/Layout", fullPath: "/docs", path: "/docs" };
const loader$1 = async ({}) => {
  const { default: manifest } = await import("./assets/_virtual_docs-manifest-DDu1UWyz.js");
  return { manifest };
};
const Component$1 = ({ children }) => {
  const sidebarOpen = useSignal(false);
  const pathname = usePathname();
  const { data } = useLoader("docs/Layout", [pathname]);
  const entries = data.value?.manifest ?? [];
  return /* @__PURE__ */ jsxs("div", { class: layout, children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        class: mobileToggle,
        onClick: () => sidebarOpen.value = !sidebarOpen.value,
        children: sidebarOpen.value ? "✕" : "☰"
      }
    ),
    /* @__PURE__ */ jsxs("aside", { class: `${sidebar} ${sidebarOpen.value ? sidebarVisible : ""}`, children: [
      /* @__PURE__ */ jsx("div", { class: sidebarHeader, children: /* @__PURE__ */ jsx(Link, { to: "~/", class: sidebarLogo, children: "VeloJS" }) }),
      /* @__PURE__ */ jsx("nav", { class: sidebarNav, children: entries.map(
        (entry) => /* @__PURE__ */ jsx(
          Link,
          {
            to: `/${entry.slug}`,
            class: `${sidebarLink} ${pathname === `/docs/${entry.slug}` ? sidebarLinkActive : ""}`,
            children: entry.title
          },
          entry.slug
        )
      ) }),
      /* @__PURE__ */ jsx("div", { class: sidebarFooter, children: /* @__PURE__ */ jsx("a", { href: "/docs/velojs-docs.zip", download: true, class: downloadBtn, children: "↓ Download all docs (.zip)" }) })
    ] }),
    /* @__PURE__ */ jsx("main", { class: content, children })
  ] });
};
const DocsLayout = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Component: Component$1,
  loader: loader$1,
  metadata: metadata$1
}, Symbol.toStringTag, { value: "Module" }));
const metadata = { moduleId: "docs/DocPage", fullPath: "/docs/:slug", path: "/:slug" };
const staticPaths = async () => {
  const { default: manifest } = await import("./assets/_virtual_docs-manifest-DDu1UWyz.js");
  return manifest.map((entry) => ({ slug: entry.slug }));
};
const loader = async ({ params }) => {
  const { default: manifest } = await import("./assets/_virtual_docs-manifest-DDu1UWyz.js");
  const { default: content2 } = await import("./assets/_virtual_docs-content-20bkBrCs.js");
  const slug = params.slug;
  const doc = content2[slug];
  const entry = manifest.find((m) => m.slug === slug);
  const index = manifest.findIndex((m) => m.slug === slug);
  const prev = index > 0 ? manifest[index - 1] : null;
  const next = index < manifest.length - 1 ? manifest[index + 1] : null;
  return {
    html: doc?.html ?? "",
    title: entry?.title ?? slug,
    filename: entry?.filename ?? "",
    prevSlug: prev?.slug ?? null,
    prevTitle: prev?.title ?? null,
    nextSlug: next?.slug ?? null,
    nextTitle: next?.title ?? null
  };
};
const Component = () => {
  const params = useParams();
  const { data } = useLoader("docs/DocPage", [params.slug]);
  if (!data.value) return null;
  const { html, title, filename, prevSlug, prevTitle, nextSlug, nextTitle } = data.value;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { class: contentHeader, children: [
      /* @__PURE__ */ jsx("h1", { class: contentTitle, children: title }),
      filename && /* @__PURE__ */ jsx(
        "a",
        {
          href: `/docs/${filename}`,
          download: true,
          class: downloadMdBtn,
          children: "↓ Download .md"
        }
      )
    ] }),
    /* @__PURE__ */ jsx(
      "div",
      {
        class: prose,
        dangerouslySetInnerHTML: { __html: html }
      }
    ),
    /* @__PURE__ */ jsxs("div", { class: prevNext, children: [
      /* @__PURE__ */ jsx("div", { children: prevSlug && /* @__PURE__ */ jsxs(Link, { to: `/${prevSlug}`, class: prevNextLink, children: [
        /* @__PURE__ */ jsx("span", { class: prevNextLabel, children: "← Previous" }),
        /* @__PURE__ */ jsx("span", { class: prevNextTitle, children: prevTitle })
      ] }) }),
      /* @__PURE__ */ jsx("div", { children: nextSlug && /* @__PURE__ */ jsxs(Link, { to: `/${nextSlug}`, class: prevNextLink, style: { textAlign: "right" }, children: [
        /* @__PURE__ */ jsx("span", { class: prevNextLabel, children: "Next →" }),
        /* @__PURE__ */ jsx("span", { class: prevNextTitle, children: nextTitle })
      ] }) })
    ] })
  ] });
};
const DocPage = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Component,
  loader,
  metadata,
  staticPaths
}, Symbol.toStringTag, { value: "Module" }));
const routes = [
  {
    module: Root,
    isRoot: true,
    children: [
      { path: "/", module: Landing },
      {
        path: "/docs",
        module: DocsLayout,
        children: [
          { path: "/:slug", module: DocPage }
        ]
      }
    ]
  }
];
const serverDataStorage = new AsyncLocalStorage();
globalThis.__veloServerData = serverDataStorage;
function flushServerCallbacks(server) {
  const ctx = getAppContext();
  for (const fn of ctx.serverCallbacks) fn(server);
  ctx.serverCallbacks.length = 0;
}
const renderPage = (c, Component2, data) => {
  if (c.req.query("_data") === "1") {
    const buildHash = globalThis.__veloBuildHash || void 0;
    const json = data ? { ...data, __buildHash: buildHash } : { __buildHash: buildHash };
    return c.json(json);
  }
  const path = c.req.path;
  const html = serverDataStorage.run(
    data ?? {},
    () => {
      return render(/* @__PURE__ */ jsx(Router, { ssrPath: path, children: Component2 }));
    }
  );
  c.header("Cache-Control", "no-cache");
  if (!data) {
    return c.html(html);
  }
  const script = `<script>window.__PAGE_DATA__=${JSON.stringify(
    data
  )}<\/script>`;
  return c.html(html.replace("</head>", `${script}</head>`));
};
const loadPage = async (modules, c) => {
  const params = c.req.param();
  const query = c.req.query();
  const loaderArgs = { params, query, c };
  const results = await Promise.all(
    modules.map(async (module) => {
      if (!module.loader) return null;
      const loaderData = await module.loader(loaderArgs);
      const moduleId = module.metadata?.moduleId;
      return moduleId ? { moduleId, loaderData } : null;
    })
  );
  const data = {
    __params: params,
    __query: query,
    __pathname: c.req.path
  };
  for (const result of results) {
    if (result) {
      data[result.moduleId] = result.loaderData;
    }
  }
  return {
    components: modules.map((m) => m.Component),
    data
  };
};
const nestComponents = (components) => {
  if (components.length === 0) return null;
  const validComponents = components.filter(Boolean);
  if (validComponents.length === 0) return null;
  if (validComponents.length === 1) {
    const Page2 = validComponents[0];
    return /* @__PURE__ */ jsx(Page2, {});
  }
  const Page = validComponents[validComponents.length - 1];
  const layouts = validComponents.slice(0, -1);
  return layouts.reduceRight((child, Layout) => {
    return /* @__PURE__ */ jsx(Layout, { children: child });
  }, /* @__PURE__ */ jsx(Page, {}));
};
const registerRoutes = (app, nodes, parentModules = [], parentMiddlewares = []) => {
  for (const node of nodes) {
    const currentModules = [...parentModules, node.module];
    const currentMiddlewares = [
      ...parentMiddlewares,
      ...node.middlewares || []
    ];
    if (node.children) {
      registerRoutes(
        app,
        node.children,
        currentModules,
        currentMiddlewares
      );
    } else {
      const fullPath = node.module.metadata?.fullPath;
      if (!fullPath) {
        console.warn(
          `Module ${node.module.metadata?.moduleId} has no fullPath`
        );
        continue;
      }
      const handler = async (c) => {
        const { components, data } = await loadPage(currentModules, c);
        const nested = nestComponents(components);
        return renderPage(c, nested, data);
      };
      if (currentMiddlewares.length > 0) {
        app.on(["GET"], [fullPath], ...currentMiddlewares, handler);
      } else {
        app.on(["GET"], [fullPath], handler);
      }
    }
  }
};
const registerActionRoutes = (app, nodes, parentMiddlewares = []) => {
  for (const node of nodes) {
    const moduleId = node.module.metadata?.moduleId;
    const currentMiddlewares = [
      ...parentMiddlewares,
      ...node.middlewares || []
    ];
    if (moduleId) {
      const actionKeys = Object.keys(node.module).filter(
        (k) => k.startsWith("action_")
      );
      for (const actionKey of actionKeys) {
        const actionName = actionKey.replace("action_", "");
        const action = node.module[actionKey];
        if (typeof action === "function") {
          const actionPath = `/_action/${moduleId}/${actionName}`;
          const handler = async (c) => {
            let body = {};
            try {
              body = await c.req.json();
            } catch {
            }
            const actionArgs = {
              body,
              params: c.req.param(),
              query: c.req.query(),
              c
            };
            try {
              const result = await action(actionArgs);
              return c.json(result ?? { ok: true });
            } catch (error) {
              const message = error instanceof Error ? error.message : "Action failed";
              return c.json({ error: message }, 500);
            }
          };
          if (currentMiddlewares.length > 0) {
            app.on(
              ["POST"],
              [actionPath],
              ...currentMiddlewares,
              handler
            );
          } else {
            app.on(["POST"], [actionPath], handler);
          }
        }
      }
    }
    if (node.children) {
      registerActionRoutes(app, node.children, currentMiddlewares);
    }
  }
};
const registerStreamRoutes = async (app, nodes, parentMiddlewares = []) => {
  const { registerStreamHandler } = await import("./assets/events-B0xtr4IK.js");
  const visit = (subNodes, inheritedMiddlewares) => {
    for (const node of subNodes) {
      const moduleId = node.module.metadata?.moduleId;
      const currentMiddlewares = [
        ...inheritedMiddlewares,
        ...node.middlewares || []
      ];
      if (moduleId) {
        const streamKeys = Object.keys(node.module).filter(
          (k) => k.startsWith("stream_")
        );
        for (const streamKey of streamKeys) {
          const streamName = streamKey.replace("stream_", "");
          const stream = node.module[streamKey];
          if (stream?.__isVeloEventStream) {
            const streamPath = `/_event/${moduleId}/${streamName}`;
            stream.__path = streamPath;
            registerStreamHandler(
              app,
              streamPath,
              stream,
              currentMiddlewares
            );
          }
        }
      }
      if (node.children) {
        visit(node.children, currentMiddlewares);
      }
    }
  };
  visit(nodes, parentMiddlewares);
};
const createApp = async (routes2) => {
  const app = new Hono();
  app.use(trimTrailingSlash());
  const ctx = getAppContext();
  const pending = ctx.pendingRoutes.splice(0);
  for (const fn of pending) {
    await fn(app);
  }
  registerRoutes(app, routes2);
  registerActionRoutes(app, routes2);
  await registerStreamRoutes(app, routes2);
  const { flushPendingStreamRoutes } = await import("./assets/events-B0xtr4IK.js");
  flushPendingStreamRoutes(app);
  return app;
};
const startServer = async (options) => {
  const { routes: routes2, port = Number(process.env.SERVER_PORT) || 3e3 } = options;
  const app = await createApp(routes2);
  if (!process.env.VELO_STATIC) {
    const { serve } = await import("@hono/node-server");
    const { serveStatic } = await import("@hono/node-server/serve-static");
    const { join } = await import("node:path");
    const clientDir = join(process.cwd(), "dist/client");
    const staticUrl = "/client";
    if (!staticUrl.startsWith("http")) {
      app.use("/*", serveStatic({ root: clientDir }));
    }
    console.log(`Server running on http://localhost:${port}`);
    const server = serve({ fetch: app.fetch, port });
    flushServerCallbacks(server);
  }
  return app;
};
globalThis.__veloBuildHash = "mo86zfro";
globalThis.__veloClientJs = "client.CIywn97n.js";
globalThis.__veloClientCss = "client.wEWg14G5.css";
const serverEntry = await startServer({ routes });
export {
  serverEntry as default,
  getAppContext as g,
  routes
};
