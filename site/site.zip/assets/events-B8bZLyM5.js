const DEFAULT_HEARTBEAT_MS = 2e4;
const BROADCAST_CHANNEL = "";
const pendingStreamRoutes = [];
function flushPendingStreamRoutes(app) {
  for (const fn of pendingStreamRoutes) fn(app);
  pendingStreamRoutes.length = 0;
}
function defaultChannelFn(c) {
  return c.req.query("channel") ?? BROADCAST_CHANNEL;
}
function registerStreamHandler(app, path, stream, middlewares = []) {
  const handler = async (c) => {
    const { streamSSE } = await import("hono/streaming");
    let channelKey;
    if (stream.__config.broadcast) {
      channelKey = BROADCAST_CHANNEL;
    } else {
      const resolver = stream.__config.channel ?? defaultChannelFn;
      let resolved;
      try {
        resolved = await resolver(c);
      } catch (err) {
        console.error("[velojs] channel resolver threw:", err);
        return c.json({ error: "internal" }, 500);
      }
      if (resolved == null) {
        return c.json({ error: "forbidden" }, 403);
      }
      channelKey = resolved;
    }
    const heartbeatMs = stream.__config.heartbeatMs;
    const heartbeatInterval = heartbeatMs === false ? 0 : heartbeatMs ?? DEFAULT_HEARTBEAT_MS;
    return streamSSE(c, async (sse) => {
      const bufferedEvents = stream.__buffers.get(channelKey);
      if (bufferedEvents && bufferedEvents.length > 0) {
        await sse.writeSSE({
          event: "snapshot",
          data: JSON.stringify(bufferedEvents)
        });
      }
      if (stream.__config.snapshot) {
        const snapshot = await stream.__config.snapshot(
          channelKey === BROADCAST_CHANNEL ? void 0 : channelKey
        );
        if (snapshot !== void 0) {
          await sse.writeSSE({
            event: "snapshot",
            data: JSON.stringify(snapshot)
          });
        }
      }
      let resolveDone;
      const done = new Promise((resolve) => {
        resolveDone = resolve;
      });
      let disposed = false;
      let heartbeat = null;
      const cleanup = () => {
        if (disposed) return;
        disposed = true;
        if (heartbeat) clearInterval(heartbeat);
        stream.__onDisconnect(channelKey, listener);
        resolveDone();
      };
      const listener = ((event) => {
        if (disposed) return;
        sse.writeSSE({ data: JSON.stringify(event) }).catch(() => {
        });
        if (stream.__config.closeOn?.(event)) {
          sse.close();
          cleanup();
        }
      });
      listener.close = () => {
        if (disposed) return;
        sse.writeSSE({ event: "close", data: "" }).catch(() => {
        });
        sse.close();
        cleanup();
      };
      stream.__onConnect(channelKey, listener);
      heartbeat = heartbeatInterval > 0 ? setInterval(() => {
        if (disposed) return;
        sse.writeSSE({ event: "heartbeat", data: "" }).catch(() => {
        });
      }, heartbeatInterval) : null;
      sse.onAbort(cleanup);
      await done;
    });
  };
  if (middlewares.length > 0) {
    app.on(["GET"], [path], ...middlewares, handler);
  } else {
    app.on(["GET"], [path], handler);
  }
}
export {
  flushPendingStreamRoutes,
  registerStreamHandler
};
