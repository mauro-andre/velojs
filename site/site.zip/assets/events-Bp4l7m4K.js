const DEFAULT_HEARTBEAT_MS = 2e4;
const BROADCAST_CHANNEL = "";
const pendingStreamRoutes = [];
function flushPendingStreamRoutes(app) {
  for (const fn of pendingStreamRoutes) fn(app);
  pendingStreamRoutes.length = 0;
}
function registerStreamHandler(app, path, stream, middlewares = []) {
  const handler = async (c) => {
    const { streamSSE } = await import("hono/streaming");
    const channelKey = stream.__config.channel ? stream.__config.channel(c) : BROADCAST_CHANNEL;
    const heartbeatMs = stream.__config.heartbeatMs;
    const heartbeatInterval = heartbeatMs === false ? 0 : heartbeatMs ?? DEFAULT_HEARTBEAT_MS;
    return streamSSE(c, async (sse) => {
      if (stream.__config.snapshot) {
        const snapshot = await stream.__config.snapshot(
          channelKey === BROADCAST_CHANNEL ? void 0 : channelKey
        );
        if (snapshot !== void 0) {
          await sse.writeSSE({
            event: "snapshot",
            data: JSON.stringify(snapshot)
          });
        }
      }
      let resolveDone;
      const done = new Promise((resolve) => {
        resolveDone = resolve;
      });
      let closed = false;
      let heartbeat = null;
      let channelListeners;
      const cleanup = () => {
        if (closed) return;
        closed = true;
        if (heartbeat) clearInterval(heartbeat);
        channelListeners?.delete(listener);
        if (channelListeners?.size === 0) {
          stream.__listeners.delete(channelKey);
        }
        resolveDone();
      };
      const listener = (event) => {
        if (closed) return;
        sse.writeSSE({ data: JSON.stringify(event) }).catch(() => {
        });
        if (stream.__config.closeOn?.(event)) {
          sse.close();
          cleanup();
        }
      };
      channelListeners = stream.__listeners.get(channelKey);
      if (!channelListeners) {
        channelListeners = /* @__PURE__ */ new Set();
        stream.__listeners.set(channelKey, channelListeners);
      }
      channelListeners.add(listener);
      heartbeat = heartbeatInterval > 0 ? setInterval(() => {
        if (closed) return;
        sse.writeSSE({ event: "heartbeat", data: "" }).catch(() => {
        });
      }, heartbeatInterval) : null;
      sse.onAbort(cleanup);
      await done;
    });
  };
  if (middlewares.length > 0) {
    app.on(["GET"], [path], ...middlewares, handler);
  } else {
    app.on(["GET"], [path], handler);
  }
}
export {
  flushPendingStreamRoutes,
  registerStreamHandler
};
