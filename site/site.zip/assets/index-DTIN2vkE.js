(function(){const s=document.createElement("link").relList;if(s&&s.supports&&s.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))a(t);new MutationObserver(t=>{for(const o of t)if(o.type==="childList")for(const p of o.addedNodes)p.tagName==="LINK"&&p.rel==="modulepreload"&&a(p)}).observe(document,{childList:!0,subtree:!0});function e(t){const o={};return t.integrity&&(o.integrity=t.integrity),t.referrerPolicy&&(o.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?o.credentials="include":t.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function a(t){if(t.ep)return;t.ep=!0;const o=e(t);fetch(t.href,o)}})();var as,h,$s,qs,x,bs,Js,Ws,rs,W,H,Ys,As,ys,Bs,z={},Q=[],Cn=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,os=Array.isArray;function _(n,s){for(var e in s)n[e]=s[e];return n}function fs(n){n&&n.parentNode&&n.parentNode.removeChild(n)}function An(n,s,e){var a,t,o,p={};for(o in s)o=="key"?a=s[o]:o=="ref"?t=s[o]:p[o]=s[o];if(arguments.length>2&&(p.children=arguments.length>3?as.call(arguments,2):e),typeof n=="function"&&n.defaultProps!=null)for(o in n.defaultProps)p[o]===void 0&&(p[o]=n.defaultProps[o]);return Y(n,p,a,t,null)}function Y(n,s,e,a,t){var o={type:n,props:s,key:e,ref:a,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:t??++$s,__i:-1,__u:0};return t==null&&h.vnode!=null&&h.vnode(o),o}function O(n){return n.children}function V(n,s){this.props=n,this.context=s}function j(n,s){if(s==null)return n.__?j(n.__,n.__i+1):null;for(var e;s<n.__k.length;s++)if((e=n.__k[s])!=null&&e.__e!=null)return e.__e;return typeof n.type=="function"?j(n):null}function fn(n){if(n.__P&&n.__d){var s=n.__v,e=s.__e,a=[],t=[],o=_({},s);o.__v=s.__v+1,h.vnode&&h.vnode(o),Fs(n.__P,o,s,n.__n,n.__P.namespaceURI,32&s.__u?[e]:null,a,e??j(s),!!(32&s.__u),t),o.__v=s.__v,o.__.__k[o.__i]=o,Ks(a,o,t),s.__e=s.__=null,o.__e!=e&&Gs(o)}}function Gs(n){if((n=n.__)!=null&&n.__c!=null)return n.__e=n.__c.base=null,n.__k.some(function(s){if(s!=null&&s.__e!=null)return n.__e=n.__c.base=s.__e}),Gs(n)}function Ds(n){(!n.__d&&(n.__d=!0)&&x.push(n)&&!K.__r++||bs!=h.debounceRendering)&&((bs=h.debounceRendering)||Js)(K)}function K(){try{for(var n,s=1;x.length;)x.length>s&&x.sort(Ws),n=x.shift(),s=x.length,fn(n)}finally{x.length=K.__r=0}}function zs(n,s,e,a,t,o,p,r,y,c,B){var l,C,d,m,b,g,A,f=a&&a.__k||Q,k=s.length;for(y=Fn(e,s,f,y,k),l=0;l<k;l++)(d=e.__k[l])!=null&&(C=d.__i!=-1&&f[d.__i]||z,d.__i=l,g=Fs(n,d,C,t,o,p,r,y,c,B),m=d.__e,d.ref&&C.ref!=d.ref&&(C.ref&&ms(C.ref,null,d),B.push(d.ref,d.__c||m,d)),b==null&&m!=null&&(b=m),(A=!!(4&d.__u))||C.__k===d.__k?(y=Qs(d,y,n,A),A&&C.__e&&(C.__e=null)):typeof d.type=="function"&&g!==void 0?y=g:m&&(y=m.nextSibling),d.__u&=-7);return e.__e=b,y}function Fn(n,s,e,a,t){var o,p,r,y,c,B=e.length,l=B,C=0;for(n.__k=new Array(t),o=0;o<t;o++)(p=s[o])!=null&&typeof p!="boolean"&&typeof p!="function"?(typeof p=="string"||typeof p=="number"||typeof p=="bigint"||p.constructor==String?p=n.__k[o]=Y(null,p,null,null,null):os(p)?p=n.__k[o]=Y(O,{children:p},null,null,null):p.constructor===void 0&&p.__b>0?p=n.__k[o]=Y(p.type,p.props,p.key,p.ref?p.ref:null,p.__v):n.__k[o]=p,y=o+C,p.__=n,p.__b=n.__b+1,r=null,(c=p.__i=mn(p,e,y,l))!=-1&&(l--,(r=e[c])&&(r.__u|=2)),r==null||r.__v==null?(c==-1&&(t>B?C--:t<B&&C++),typeof p.type!="function"&&(p.__u|=4)):c!=y&&(c==y-1?C--:c==y+1?C++:(c>y?C--:C++,p.__u|=4))):n.__k[o]=null;if(l)for(o=0;o<B;o++)(r=e[o])!=null&&(2&r.__u)==0&&(r.__e==a&&(a=j(r)),Zs(r,r));return a}function Qs(n,s,e,a){var t,o;if(typeof n.type=="function"){for(t=n.__k,o=0;t&&o<t.length;o++)t[o]&&(t[o].__=n,s=Qs(t[o],s,e,a));return s}n.__e!=s&&(a&&(s&&n.type&&!s.parentNode&&(s=j(n)),e.insertBefore(n.__e,s||null)),s=n.__e);do s=s&&s.nextSibling;while(s!=null&&s.nodeType==8);return s}function mn(n,s,e,a){var t,o,p,r=n.key,y=n.type,c=s[e],B=c!=null&&(2&c.__u)==0;if(c===null&&r==null||B&&r==c.key&&y==c.type)return e;if(a>(B?1:0)){for(t=e-1,o=e+1;t>=0||o<s.length;)if((c=s[p=t>=0?t--:o++])!=null&&(2&c.__u)==0&&r==c.key&&y==c.type)return p}return-1}function _s(n,s,e){s[0]=="-"?n.setProperty(s,e??""):n[s]=e==null?"":typeof e!="number"||Cn.test(s)?e:e+"px"}function q(n,s,e,a,t){var o,p;s:if(s=="style")if(typeof e=="string")n.style.cssText=e;else{if(typeof a=="string"&&(n.style.cssText=a=""),a)for(s in a)e&&s in e||_s(n.style,s,"");if(e)for(s in e)a&&e[s]==a[s]||_s(n.style,s,e[s])}else if(s[0]=="o"&&s[1]=="n")o=s!=(s=s.replace(Ys,"$1")),p=s.toLowerCase(),s=p in n||s=="onFocusOut"||s=="onFocusIn"?p.slice(2):s.slice(2),n.l||(n.l={}),n.l[s+o]=e,e?a?e[H]=a[H]:(e[H]=As,n.addEventListener(s,o?Bs:ys,o)):n.removeEventListener(s,o?Bs:ys,o);else{if(t=="http://www.w3.org/2000/svg")s=s.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(s!="width"&&s!="height"&&s!="href"&&s!="list"&&s!="form"&&s!="tabIndex"&&s!="download"&&s!="rowSpan"&&s!="colSpan"&&s!="role"&&s!="popover"&&s in n)try{n[s]=e??"";break s}catch{}typeof e=="function"||(e==null||e===!1&&s[4]!="-"?n.removeAttribute(s):n.setAttribute(s,s=="popover"&&e==1?"":e))}}function ws(n){return function(s){if(this.l){var e=this.l[s.type+n];if(s[W]==null)s[W]=As++;else if(s[W]<e[H])return;return e(h.event?h.event(s):s)}}}function Fs(n,s,e,a,t,o,p,r,y,c){var B,l,C,d,m,b,g,A,f,k,L,M,Es,$,ps,D=s.type;if(s.constructor!==void 0)return null;128&e.__u&&(y=!!(32&e.__u),o=[r=s.__e=e.__e]),(B=h.__b)&&B(s);s:if(typeof D=="function")try{if(A=s.props,f=D.prototype&&D.prototype.render,k=(B=D.contextType)&&a[B.__c],L=B?k?k.props.value:B.__:a,e.__c?g=(l=s.__c=e.__c).__=l.__E:(f?s.__c=l=new D(A,L):(s.__c=l=new V(A,L),l.constructor=D,l.render=vn),k&&k.sub(l),l.state||(l.state={}),l.__n=a,C=l.__d=!0,l.__h=[],l._sb=[]),f&&l.__s==null&&(l.__s=l.state),f&&D.getDerivedStateFromProps!=null&&(l.__s==l.state&&(l.__s=_({},l.__s)),_(l.__s,D.getDerivedStateFromProps(A,l.__s))),d=l.props,m=l.state,l.__v=s,C)f&&D.getDerivedStateFromProps==null&&l.componentWillMount!=null&&l.componentWillMount(),f&&l.componentDidMount!=null&&l.__h.push(l.componentDidMount);else{if(f&&D.getDerivedStateFromProps==null&&A!==d&&l.componentWillReceiveProps!=null&&l.componentWillReceiveProps(A,L),s.__v==e.__v||!l.__e&&l.shouldComponentUpdate!=null&&l.shouldComponentUpdate(A,l.__s,L)===!1){s.__v!=e.__v&&(l.props=A,l.state=l.__s,l.__d=!1),s.__e=e.__e,s.__k=e.__k,s.__k.some(function(R){R&&(R.__=s)}),Q.push.apply(l.__h,l._sb),l._sb=[],l.__h.length&&p.push(l);break s}l.componentWillUpdate!=null&&l.componentWillUpdate(A,l.__s,L),f&&l.componentDidUpdate!=null&&l.__h.push(function(){l.componentDidUpdate(d,m,b)})}if(l.context=L,l.props=A,l.__P=n,l.__e=!1,M=h.__r,Es=0,f)l.state=l.__s,l.__d=!1,M&&M(s),B=l.render(l.props,l.state,l.context),Q.push.apply(l.__h,l._sb),l._sb=[];else do l.__d=!1,M&&M(s),B=l.render(l.props,l.state,l.context),l.state=l.__s;while(l.__d&&++Es<25);l.state=l.__s,l.getChildContext!=null&&(a=_(_({},a),l.getChildContext())),f&&!C&&l.getSnapshotBeforeUpdate!=null&&(b=l.getSnapshotBeforeUpdate(d,m)),$=B!=null&&B.type===O&&B.key==null?Xs(B.props.children):B,r=zs(n,os($)?$:[$],s,e,a,t,o,p,r,y,c),l.base=s.__e,s.__u&=-161,l.__h.length&&p.push(l),g&&(l.__E=l.__=null)}catch(R){if(s.__v=null,y||o!=null)if(R.then){for(s.__u|=y?160:128;r&&r.nodeType==8&&r.nextSibling;)r=r.nextSibling;o[o.indexOf(r)]=null,s.__e=r}else{for(ps=o.length;ps--;)fs(o[ps]);us(s)}else s.__e=e.__e,s.__k=e.__k,R.then||us(s);h.__e(R,s,e)}else o==null&&s.__v==e.__v?(s.__k=e.__k,s.__e=e.__e):r=s.__e=gn(e.__e,s,e,a,t,o,p,y,c);return(B=h.diffed)&&B(s),128&s.__u?void 0:r}function us(n){n&&(n.__c&&(n.__c.__e=!0),n.__k&&n.__k.some(us))}function Ks(n,s,e){for(var a=0;a<e.length;a++)ms(e[a],e[++a],e[++a]);h.__c&&h.__c(s,n),n.some(function(t){try{n=t.__h,t.__h=[],n.some(function(o){o.call(t)})}catch(o){h.__e(o,t.__v)}})}function Xs(n){return typeof n!="object"||n==null||n.__b>0?n:os(n)?n.map(Xs):_({},n)}function gn(n,s,e,a,t,o,p,r,y){var c,B,l,C,d,m,b,g=e.props||z,A=s.props,f=s.type;if(f=="svg"?t="http://www.w3.org/2000/svg":f=="math"?t="http://www.w3.org/1998/Math/MathML":t||(t="http://www.w3.org/1999/xhtml"),o!=null){for(c=0;c<o.length;c++)if((d=o[c])&&"setAttribute"in d==!!f&&(f?d.localName==f:d.nodeType==3)){n=d,o[c]=null;break}}if(n==null){if(f==null)return document.createTextNode(A);n=document.createElementNS(t,f,A.is&&A),r&&(h.__m&&h.__m(s,o),r=!1),o=null}if(f==null)g===A||r&&n.data==A||(n.data=A);else{if(o=o&&as.call(n.childNodes),!r&&o!=null)for(g={},c=0;c<n.attributes.length;c++)g[(d=n.attributes[c]).name]=d.value;for(c in g)d=g[c],c=="dangerouslySetInnerHTML"?l=d:c=="children"||c in A||c=="value"&&"defaultValue"in A||c=="checked"&&"defaultChecked"in A||q(n,c,null,d,t);for(c in A)d=A[c],c=="children"?C=d:c=="dangerouslySetInnerHTML"?B=d:c=="value"?m=d:c=="checked"?b=d:r&&typeof d!="function"||g[c]===d||q(n,c,d,g[c],t);if(B)r||l&&(B.__html==l.__html||B.__html==n.innerHTML)||(n.innerHTML=B.__html),s.__k=[];else if(l&&(n.innerHTML=""),zs(s.type=="template"?n.content:n,os(C)?C:[C],s,e,a,f=="foreignObject"?"http://www.w3.org/1999/xhtml":t,o,p,o?o[0]:e.__k&&j(e,0),r,y),o!=null)for(c=o.length;c--;)fs(o[c]);r||(c="value",f=="progress"&&m==null?n.removeAttribute("value"):m!=null&&(m!==n[c]||f=="progress"&&!m||f=="option"&&m!=g[c])&&q(n,c,m,g[c],t),c="checked",b!=null&&b!=n[c]&&q(n,c,b,g[c],t))}return n}function ms(n,s,e){try{if(typeof n=="function"){var a=typeof n.__u=="function";a&&n.__u(),a&&s==null||(n.__u=n(s))}else n.current=s}catch(t){h.__e(t,e)}}function Zs(n,s,e){var a,t;if(h.unmount&&h.unmount(n),(a=n.ref)&&(a.current&&a.current!=n.__e||ms(a,null,s)),(a=n.__c)!=null){if(a.componentWillUnmount)try{a.componentWillUnmount()}catch(o){h.__e(o,s)}a.base=a.__P=null}if(a=n.__k)for(t=0;t<a.length;t++)a[t]&&Zs(a[t],s,e||typeof n.type!="function");e||fs(n.__e),n.__c=n.__=n.__e=void 0}function vn(n,s,e){return this.constructor(n,e)}function En(n,s,e){var a,t,o,p;s==document&&(s=document.documentElement),h.__&&h.__(n,s),t=(a=!1)?null:s.__k,o=[],p=[],Fs(s,n=s.__k=An(O,null,[n]),t||z,z,s.namespaceURI,t?null:s.firstChild?as.call(s.childNodes):null,o,t?t.__e:s.firstChild,a,p),Ks(o,n,p)}as=Q.slice,h={__e:function(n,s,e,a){for(var t,o,p;s=s.__;)if((t=s.__c)&&!t.__)try{if((o=t.constructor)&&o.getDerivedStateFromError!=null&&(t.setState(o.getDerivedStateFromError(n)),p=t.__d),t.componentDidCatch!=null&&(t.componentDidCatch(n,a||{}),p=t.__d),p)return t.__E=t}catch(r){n=r}throw n}},$s=0,qs=function(n){return n!=null&&n.constructor===void 0},V.prototype.setState=function(n,s){var e;e=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=_({},this.state),typeof n=="function"&&(n=n(_({},e),this.props)),n&&_(e,n),n!=null&&this.__v&&(s&&this._sb.push(s),Ds(this))},V.prototype.forceUpdate=function(n){this.__v&&(this.__e=!0,n&&this.__h.push(n),Ds(this))},V.prototype.render=O,x=[],Js=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Ws=function(n,s){return n.__v.__b-s.__v.__b},K.__r=0,rs=Math.random().toString(8),W="__d"+rs,H="__a"+rs,Ys=/(PointerCapture)$|Capture$/i,As=0,ys=ws(!1),Bs=ws(!0);var bn=0;function i(n,s,e,a,t,o){s||(s={});var p,r,y=s;if("ref"in y)for(r in y={},s)r=="ref"?p=s[r]:y[r]=s[r];var c={type:n,props:y,key:e,ref:p,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--bn,__i:-1,__u:0,__source:t,__self:o};if(typeof n=="function"&&(p=n.defaultProps))for(r in p)y[r]===void 0&&(y[r]=p[r]);return h.vnode&&h.vnode(c),c}var X,E,cs,ks,Ss=0,sn=[],F=h,xs=F.__b,Ls=F.__r,Ts=F.diffed,Rs=F.__c,js=F.unmount,Ps=F.__;function nn(n,s){F.__h&&F.__h(E,n,Ss||s),Ss=0;var e=E.__H||(E.__H={__:[],__h:[]});return n>=e.__.length&&e.__.push({}),e.__[n]}function Dn(n,s){var e=nn(X++,3);!F.__s&&an(e.__H,s)&&(e.__=n,e.u=s,E.__H.__h.push(e))}function en(n,s){var e=nn(X++,7);return an(e.__H,s)&&(e.__=n(),e.__H=s,e.__h=n),e.__}function _n(){for(var n;n=sn.shift();){var s=n.__H;if(n.__P&&s)try{s.__h.some(G),s.__h.some(hs),s.__h=[]}catch(e){s.__h=[],F.__e(e,n.__v)}}}F.__b=function(n){E=null,xs&&xs(n)},F.__=function(n,s){n&&s.__k&&s.__k.__m&&(n.__m=s.__k.__m),Ps&&Ps(n,s)},F.__r=function(n){Ls&&Ls(n),X=0;var s=(E=n.__c).__H;s&&(cs===E?(s.__h=[],E.__h=[],s.__.some(function(e){e.__N&&(e.__=e.__N),e.u=e.__N=void 0})):(s.__h.some(G),s.__h.some(hs),s.__h=[],X=0)),cs=E},F.diffed=function(n){Ts&&Ts(n);var s=n.__c;s&&s.__H&&(s.__H.__h.length&&(sn.push(s)!==1&&ks===F.requestAnimationFrame||((ks=F.requestAnimationFrame)||wn)(_n)),s.__H.__.some(function(e){e.u&&(e.__H=e.u),e.u=void 0})),cs=E=null},F.__c=function(n,s){s.some(function(e){try{e.__h.some(G),e.__h=e.__h.filter(function(a){return!a.__||hs(a)})}catch(a){s.some(function(t){t.__h&&(t.__h=[])}),s=[],F.__e(a,e.__v)}}),Rs&&Rs(n,s)},F.unmount=function(n){js&&js(n);var s,e=n.__c;e&&e.__H&&(e.__H.__.some(function(a){try{G(a)}catch(t){s=t}}),e.__H=void 0,s&&F.__e(s,e.__v))};var Us=typeof requestAnimationFrame=="function";function wn(n){var s,e=function(){clearTimeout(a),Us&&cancelAnimationFrame(s),setTimeout(n)},a=setTimeout(e,35);Us&&(s=requestAnimationFrame(e))}function G(n){var s=E,e=n.__c;typeof e=="function"&&(n.__c=void 0,e()),E=s}function hs(n){var s=E;n.__c=n.__(),E=s}function an(n,s){return!n||n.length!==s.length||s.some(function(e,a){return e!==n[a]})}var kn=Symbol.for("preact-signals");function ts(){if(w>1)w--;else{var n,s=!1;for((function(){var t=ss;for(ss=void 0;t!==void 0;)t.S.v===t.v&&(t.S.i=t.i),t=t.o})();N!==void 0;){var e=N;for(N=void 0,Z++;e!==void 0;){var a=e.u;if(e.u=void 0,e.f&=-3,!(8&e.f)&&ln(e))try{e.c()}catch(t){s||(n=t,s=!0)}e=a}}if(Z=0,w--,s)throw n}}function Sn(n){if(w>0)return n();Cs=++xn,w++;try{return n()}finally{ts()}}var u=void 0;function on(n){var s=u;u=void 0;try{return n()}finally{u=s}}var N=void 0,w=0,Z=0,xn=0,Cs=0,ss=void 0,ns=0;function tn(n){if(u!==void 0){var s=n.n;if(s===void 0||s.t!==u)return s={i:0,S:n,p:u.s,n:void 0,t:u,e:void 0,x:void 0,r:s},u.s!==void 0&&(u.s.n=s),u.s=s,n.n=s,32&u.f&&n.S(s),s;if(s.i===-1)return s.i=0,s.n!==void 0&&(s.n.p=s.p,s.p!==void 0&&(s.p.n=s.n),s.p=u.s,s.n=void 0,u.s.n=s,u.s=s),s}}function v(n,s){this.v=n,this.i=0,this.n=void 0,this.t=void 0,this.l=0,this.W=s?.watched,this.Z=s?.unwatched,this.name=s?.name}v.prototype.brand=kn;v.prototype.h=function(){return!0};v.prototype.S=function(n){var s=this,e=this.t;e!==n&&n.e===void 0&&(n.x=e,this.t=n,e!==void 0?e.e=n:on(function(){var a;(a=s.W)==null||a.call(s)}))};v.prototype.U=function(n){var s=this;if(this.t!==void 0){var e=n.e,a=n.x;e!==void 0&&(e.x=a,n.e=void 0),a!==void 0&&(a.e=e,n.x=void 0),n===this.t&&(this.t=a,a===void 0&&on(function(){var t;(t=s.Z)==null||t.call(s)}))}};v.prototype.subscribe=function(n){var s=this;return U(function(){var e=s.value,a=u;u=void 0;try{n(e)}finally{u=a}},{name:"sub"})};v.prototype.valueOf=function(){return this.value};v.prototype.toString=function(){return this.value+""};v.prototype.toJSON=function(){return this.value};v.prototype.peek=function(){var n=u;u=void 0;try{return this.value}finally{u=n}};Object.defineProperty(v.prototype,"value",{get:function(){var n=tn(this);return n!==void 0&&(n.i=this.i),this.v},set:function(n){if(n!==this.v){if(Z>100)throw new Error("Cycle detected");(function(e){w!==0&&Z===0&&e.l!==Cs&&(e.l=Cs,ss={S:e,v:e.v,i:e.i,o:ss})})(this),this.v=n,this.i++,ns++,w++;try{for(var s=this.t;s!==void 0;s=s.x)s.t.N()}finally{ts()}}}});function gs(n,s){return new v(n,s)}function ln(n){for(var s=n.s;s!==void 0;s=s.n)if(s.S.i!==s.i||!s.S.h()||s.S.i!==s.i)return!0;return!1}function pn(n){for(var s=n.s;s!==void 0;s=s.n){var e=s.S.n;if(e!==void 0&&(s.r=e),s.S.n=s,s.i=-1,s.n===void 0){n.s=s;break}}}function rn(n){for(var s=n.s,e=void 0;s!==void 0;){var a=s.p;s.i===-1?(s.S.U(s),a!==void 0&&(a.n=s.n),s.n!==void 0&&(s.n.p=a)):e=s,s.S.n=s.r,s.r!==void 0&&(s.r=void 0),s=a}n.s=e}function T(n,s){v.call(this,void 0),this.x=n,this.s=void 0,this.g=ns-1,this.f=4,this.W=s?.watched,this.Z=s?.unwatched,this.name=s?.name}T.prototype=new v;T.prototype.h=function(){if(this.f&=-3,1&this.f)return!1;if((36&this.f)==32||(this.f&=-5,this.g===ns))return!0;if(this.g=ns,this.f|=1,this.i>0&&!ln(this))return this.f&=-2,!0;var n=u;try{pn(this),u=this;var s=this.x();(16&this.f||this.v!==s||this.i===0)&&(this.v=s,this.f&=-17,this.i++)}catch(e){this.v=e,this.f|=16,this.i++}return u=n,rn(this),this.f&=-2,!0};T.prototype.S=function(n){if(this.t===void 0){this.f|=36;for(var s=this.s;s!==void 0;s=s.n)s.S.S(s)}v.prototype.S.call(this,n)};T.prototype.U=function(n){if(this.t!==void 0&&(v.prototype.U.call(this,n),this.t===void 0)){this.f&=-33;for(var s=this.s;s!==void 0;s=s.n)s.S.U(s)}};T.prototype.N=function(){if(!(2&this.f)){this.f|=6;for(var n=this.t;n!==void 0;n=n.x)n.t.N()}};Object.defineProperty(T.prototype,"value",{get:function(){if(1&this.f)throw new Error("Cycle detected");var n=tn(this);if(this.h(),n!==void 0&&(n.i=this.i),16&this.f)throw this.v;return this.v}});function Is(n,s){return new T(n,s)}function cn(n){var s=n.m;if(n.m=void 0,typeof s=="function"){w++;var e=u;u=void 0;try{s()}catch(a){throw n.f&=-2,n.f|=8,vs(n),a}finally{u=e,ts()}}}function vs(n){for(var s=n.s;s!==void 0;s=s.n)s.S.U(s);n.x=void 0,n.s=void 0,cn(n)}function Ln(n){if(u!==this)throw new Error("Out-of-order effect");rn(this),u=n,this.f&=-2,8&this.f&&vs(this),ts()}function P(n,s){this.x=n,this.m=void 0,this.s=void 0,this.u=void 0,this.f=32,this.name=s?.name}P.prototype.c=function(){var n=this.S();try{if(8&this.f||this.x===void 0)return;var s=this.x();typeof s=="function"&&(this.m=s)}finally{n()}};P.prototype.S=function(){if(1&this.f)throw new Error("Cycle detected");this.f|=1,this.f&=-9,cn(this),pn(this),w++;var n=u;return u=this,Ln.bind(this,n)};P.prototype.N=function(){2&this.f||(this.f|=2,this.u=N,N=this)};P.prototype.d=function(){this.f|=8,1&this.f||vs(this)};P.prototype.dispose=function(){this.d()};function U(n,s){var e=new P(n,s);try{e.c()}catch(t){throw e.d(),t}var a=e.d.bind(e);return a[Symbol.dispose]=a,a}var dn,J,Tn=typeof window<"u"&&!!window.__PREACT_SIGNALS_DEVTOOLS__,yn=[];U(function(){dn=this.N})();function I(n,s){h[n]=s.bind(null,h[n]||function(){})}function es(n){if(J){var s=J;J=void 0,s()}J=n&&n.S()}function Bn(n){var s=this,e=n.data,a=un(e);a.value=e;var t=en(function(){for(var r=s,y=s.__v;y=y.__;)if(y.__c){y.__c.__$f|=4;break}var c=Is(function(){var d=a.value.value;return d===0?0:d===!0?"":d||""}),B=Is(function(){return!Array.isArray(c.value)&&!qs(c.value)}),l=U(function(){if(this.N=hn,B.value){var d=c.value;r.__v&&r.__v.__e&&r.__v.__e.nodeType===3&&(r.__v.__e.data=d)}}),C=s.__$u.d;return s.__$u.d=function(){l(),C.call(this)},[B,c]},[]),o=t[0],p=t[1];return o.value?p.peek():p.value}Bn.displayName="ReactiveTextNode";Object.defineProperties(v.prototype,{constructor:{configurable:!0,value:void 0},type:{configurable:!0,value:Bn},props:{configurable:!0,get:function(){var n=this;return{data:{get value(){return n.value}}}}},__b:{configurable:!0,value:1}});I("__b",function(n,s){if(typeof s.type=="string"){var e,a=s.props;for(var t in a)if(t!=="children"){var o=a[t];o instanceof v&&(e||(s.__np=e={}),e[t]=o,a[t]=o.peek())}}n(s)});I("__r",function(n,s){if(n(s),s.type!==O){es();var e,a=s.__c;a&&(a.__$f&=-2,(e=a.__$u)===void 0&&(a.__$u=e=(function(t,o){var p;return U(function(){p=this},{name:o}),p.c=t,p})(function(){var t;Tn&&((t=e.y)==null||t.call(e)),a.__$f|=1,a.setState({})},typeof s.type=="function"?s.type.displayName||s.type.name:""))),es(e)}});I("__e",function(n,s,e,a){es(),n(s,e,a)});I("diffed",function(n,s){es();var e;if(typeof s.type=="string"&&(e=s.__e)){var a=s.__np,t=s.props;if(a){var o=e.U;if(o)for(var p in o){var r=o[p];r!==void 0&&!(p in a)&&(r.d(),o[p]=void 0)}else o={},e.U=o;for(var y in a){var c=o[y],B=a[y];c===void 0?(c=Rn(e,y,B),o[y]=c):c.o(B,t)}for(var l in a)t[l]=a[l]}}n(s)});function Rn(n,s,e,a){var t=s in n&&n.ownerSVGElement===void 0,o=gs(e),p=e.peek();return{o:function(r,y){o.value=r,p=r.peek()},d:U(function(){this.N=hn;var r=o.value.value;p!==r?(p=void 0,t?n[s]=r:r!=null&&(r!==!1||s[4]==="-")?n.setAttribute(s,r):n.removeAttribute(s)):p=void 0})}}I("unmount",function(n,s){if(typeof s.type=="string"){var e=s.__e;if(e){var a=e.U;if(a){e.U=void 0;for(var t in a){var o=a[t];o&&o.d()}}}s.__np=void 0}else{var p=s.__c;if(p){var r=p.__$u;r&&(p.__$u=void 0,r.d())}}n(s)});I("__h",function(n,s,e,a){(a<3||a===9)&&(s.__$f|=2),n(s,e,a)});V.prototype.shouldComponentUpdate=function(n,s){if(this.__R)return!0;var e=this.__$u,a=e&&e.s!==void 0;for(var t in s)return!0;if(this.__f||typeof this.u=="boolean"&&this.u===!0){var o=2&this.__$f;if(!(a||o||4&this.__$f)||1&this.__$f)return!0}else if(!(a||4&this.__$f)||3&this.__$f)return!0;for(var p in n)if(p!=="__source"&&n[p]!==this.props[p])return!0;for(var r in this.props)if(!(r in n))return!0;return!1};function un(n,s){return en(function(){return gs(n,s)},[])}var jn=function(n){queueMicrotask(function(){queueMicrotask(n)})};function Pn(){Sn(function(){for(var n;n=yn.shift();)dn.call(n)})}function hn(){yn.push(this)===1&&(h.requestAnimationFrame||jn)(Pn)}var Un="vh710c0",In="vh710c1",Mn="vh710c2",Ms="vh710c3",Hn="vh710c4",is="vh710c5",Vn="vh710c6",Nn="vh710c7",On="vh710c8",$n="vh710c9",qn="vh710ca",Jn="vh710cb",Wn="vh710cc",Yn="vh710cd",Gn="vh710ce",Hs="vh710cf",zn="vh710cg",Qn="vh710ch",Kn="vh710ci",Xn="vh710cj",Zn="vh710ck",se="vh710cl",ne="vh710cq",ee="vh710cr",ae="vh710cs",oe="vh710ct",te="vh710cu",ds="vh710cv",le="vh710cw";const pe=[{icon:"🌳",title:"File-Based Routing",desc:"Define your entire app as a route tree in routes.tsx. Nested layouts, automatic path resolution, and middleware inheritance."},{icon:"⚡",title:"SSR + Hydration",desc:"Server-side rendering with seamless client hydration. Loaders run in parallel on the server, data flows automatically."},{icon:"🔄",title:"RPC Actions",desc:"Write server functions, call them from the client. The Vite plugin transforms action bodies into fetch stubs via AST."},{icon:"📡",title:"Reactive Signals",desc:"@preact/signals for fine-grained reactivity. No re-renders, no selectors — just signals that update the DOM directly."},{icon:"📦",title:"Zero Config",desc:"One plugin, one install. Hono, Preact, Vite, wouter — everything included and wired together out of the box."},{icon:"🔒",title:"Type-Safe",desc:"Full TypeScript. Typed loaders, actions, route modules, and middleware. Autocomplete everywhere."}];function re(){return i("div",{class:Un,children:[i("nav",{class:In,children:i("div",{class:Mn,children:[i("span",{class:Ms,children:"VeloJS"}),i("div",{class:Hn,children:[i("a",{href:"#/docs/getting-started",class:is,children:"Docs"}),i("a",{href:"https://github.com/mauro-andre/velojs",target:"_blank",class:is,children:"GitHub"}),i("a",{href:"https://www.npmjs.com/package/@mauroandre/velojs",target:"_blank",class:is,children:"npm"}),i("a",{href:"#/docs/getting-started",class:Vn,children:"Get Started"})]})]})}),i("section",{class:Nn,children:[i("h1",{class:On,children:"VeloJS"}),i("p",{class:$n,children:"Fullstack web framework that just works"}),i("p",{class:qn,children:"Hono + Preact + Vite. Server-side rendering, client hydration, RPC actions, nested routing — everything wired together with a single plugin."}),i("div",{class:Jn,children:[i("a",{href:"#/docs/getting-started",class:Wn,children:"Get Started"}),i("a",{href:"https://github.com/mauro-andre/velojs",target:"_blank",class:Yn,children:"View on GitHub"})]})]}),i("section",{class:ne,children:[i("h2",{class:Hs,children:"Get started in seconds"}),i("code",{class:ee,children:"npx @mauroandre/velojs init my-app"})]}),i("section",{class:Gn,children:[i("h2",{class:Hs,children:"Everything you need"}),i("p",{class:zn,children:"An opinionated fullstack framework that handles routing, SSR, state, and builds — so you can focus on your app."}),i("div",{class:Qn,children:pe.map((n,s)=>i("div",{class:Kn,children:[i("span",{class:Xn,children:n.icon}),i("h3",{class:Zn,children:n.title}),i("p",{class:se,children:n.desc})]},s))})]}),i("footer",{class:ae,children:i("div",{class:oe,children:[i("span",{class:Ms,children:"VeloJS"}),i("div",{class:te,children:[i("a",{href:"#/docs/getting-started",class:ds,children:"Docs"}),i("a",{href:"https://github.com/mauro-andre/velojs",target:"_blank",class:ds,children:"GitHub"}),i("a",{href:"https://www.npmjs.com/package/@mauroandre/velojs",target:"_blank",class:ds,children:"npm"})]}),i("p",{class:le,children:["© ",new Date().getFullYear()," Mauro André Silva. MIT License."]})]})})]})}const S=[{slug:"getting-started",title:"Getting Started",order:1,filename:"01-getting-started.md"},{slug:"routes",title:"Routes",order:2,filename:"02-routes.md"},{slug:"components",title:"Components",order:3,filename:"03-components.md"},{slug:"loaders",title:"Loaders",order:4,filename:"04-loaders.md"},{slug:"actions",title:"Actions",order:5,filename:"05-actions.md"},{slug:"hooks",title:"Hooks",order:6,filename:"06-hooks.md"},{slug:"link-component",title:"Link Component",order:7,filename:"07-link-component.md"},{slug:"scripts-component",title:"Scripts Component",order:8,filename:"08-scripts-component.md"},{slug:"middlewares",title:"Middlewares",order:9,filename:"09-middlewares.md"},{slug:"server-api",title:"Server API",order:10,filename:"10-server-api.md"},{slug:"vite-plugin",title:"Vite Plugin",order:11,filename:"11-vite-plugin.md"},{slug:"type-reference",title:"Type Reference",order:12,filename:"12-type-reference.md"},{slug:"production-deploy",title:"Production Deploy",order:13,filename:"13-production-deploy.md"}],ce={"getting-started":{html:`<h1 id="getting-started">Getting Started</h1><p>VeloJS is a fullstack web framework that combines Hono (server), Preact (UI), and Vite (build) into a single, cohesive experience. You write your pages, loaders, and server actions in one place — VeloJS handles the rest.</p>
<h2 id="create-a-new-project">Create a new project</h2><p>The fastest way to start is with the CLI:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#61AFEF">npx</span><span style="color:#98C379"> @mauroandre/velojs</span><span style="color:#98C379"> init</span><span style="color:#98C379"> my-app</span></span>
<span class="line"><span style="color:#56B6C2">cd</span><span style="color:#98C379"> my-app</span></span>
<span class="line"><span style="color:#61AFEF">npm</span><span style="color:#98C379"> install</span></span>
<span class="line"><span style="color:#61AFEF">npx</span><span style="color:#98C379"> velojs</span><span style="color:#98C379"> dev</span></span></code></pre><p>This creates a ready-to-run project. Open <code>http://localhost:5173</code> and you should see your app.</p>
<h2 id="project-structure">Project structure</h2><p>Every VeloJS project follows this layout:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span>my-app/</span></span>
<span class="line"><span>├── app/</span></span>
<span class="line"><span>│   ├── routes.tsx        # Where you define all your routes</span></span>
<span class="line"><span>│   ├── server.tsx        # Server-only init (databases, APIs, etc)</span></span>
<span class="line"><span>│   ├── client.tsx        # Client-only init (global CSS, etc)</span></span>
<span class="line"><span>│   ├── client-root.tsx   # The HTML shell (&#x3C;html>, &#x3C;head>, &#x3C;body>)</span></span>
<span class="line"><span>│   └── pages/            # Your pages, layouts, and modules</span></span>
<span class="line"><span>├── vite.config.ts        # Vite configuration (just one plugin)</span></span>
<span class="line"><span>├── tsconfig.json</span></span>
<span class="line"><span>└── package.json</span></span></code></pre><p>Let&#39;s walk through each file.</p>
<h2 id="vite-config-ts">vite.config.ts</h2><p>VeloJS works through a single Vite plugin that handles everything — SSR, route scanning, code transforms, and the dev server:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">defineConfig</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "vite"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">veloPlugin</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/vite"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> default</span><span style="color:#61AFEF"> defineConfig</span><span style="color:#ABB2BF">({</span></span>
<span class="line"><span style="color:#E06C75">    plugins</span><span style="color:#ABB2BF">: [</span><span style="color:#61AFEF">veloPlugin</span><span style="color:#ABB2BF">()],</span></span>
<span class="line"><span style="color:#ABB2BF">});</span></span></code></pre><p>That&#39;s it. No extra plugins needed.</p>
<h2 id="package-json-scripts">package.json scripts</h2><p>Your project needs three scripts:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#ABB2BF">{</span></span>
<span class="line"><span style="color:#E06C75">    "scripts"</span><span style="color:#ABB2BF">: {</span></span>
<span class="line"><span style="color:#E06C75">        "dev"</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"velojs dev"</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        "build"</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"velojs build"</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        "start"</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"velojs start"</span></span>
<span class="line"><span style="color:#ABB2BF">    }</span></span>
<span class="line"><span style="color:#ABB2BF">}</span></span></code></pre><ul>
<li><code>dev</code> — starts the development server with hot reload</li>
<li><code>build</code> — compiles the client bundle and server entry for production</li>
<li><code>start</code> — runs the production server (automatically sets <code>NODE_ENV=production</code>)</li>
</ul>
<h2 id="app-client-root-tsx-the-html-shell">app/client-root.tsx — The HTML shell</h2><p>This is the outermost component of your app. It renders the <code>&lt;html&gt;</code>, <code>&lt;head&gt;</code>, and <code>&lt;body&gt;</code> tags. Every page in your app will be rendered inside this shell.</p>
<p>The <code>&lt;Scripts /&gt;</code> component is required — it injects the CSS and JavaScript that your app needs (Vite HMR in dev, compiled assets in production).</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#C678DD"> type</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">ComponentChildren</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "preact"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">Scripts</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> Component</span><span style="color:#56B6C2"> =</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">children</span><span style="color:#ABB2BF"> }: { </span><span style="color:#E06C75">children</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">ComponentChildren</span><span style="color:#ABB2BF"> }) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> (</span></span>
<span class="line"><span style="color:#ABB2BF">    &#x3C;</span><span style="color:#E06C75">html</span><span style="color:#D19A66;font-style:italic"> lang</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"en"</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">        &#x3C;</span><span style="color:#E06C75">head</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">            &#x3C;</span><span style="color:#E06C75">meta</span><span style="color:#D19A66;font-style:italic"> charset</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"UTF-8"</span><span style="color:#ABB2BF"> /></span></span>
<span class="line"><span style="color:#ABB2BF">            &#x3C;</span><span style="color:#E06C75">meta</span><span style="color:#D19A66;font-style:italic"> name</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"viewport"</span><span style="color:#D19A66;font-style:italic"> content</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"width=device-width, initial-scale=1.0"</span><span style="color:#ABB2BF"> /></span></span>
<span class="line"><span style="color:#ABB2BF">            &#x3C;</span><span style="color:#E06C75">title</span><span style="color:#ABB2BF">>My App&#x3C;/</span><span style="color:#E06C75">title</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">            &#x3C;</span><span style="color:#E5C07B">Scripts</span><span style="color:#ABB2BF"> /></span></span>
<span class="line"><span style="color:#ABB2BF">        &#x3C;/</span><span style="color:#E06C75">head</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">        &#x3C;</span><span style="color:#E06C75">body</span><span style="color:#ABB2BF">></span><span style="color:#C678DD">{</span><span style="color:#E06C75">children</span><span style="color:#C678DD">}</span><span style="color:#ABB2BF">&#x3C;/</span><span style="color:#E06C75">body</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">    &#x3C;/</span><span style="color:#E06C75">html</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">);</span></span></code></pre><h2 id="app-client-tsx-client-entry">app/client.tsx — Client entry</h2><p>This file runs only on the client (browser). Use it to import global CSS or initialize client-side libraries:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#98C379"> "./styles/global.css"</span><span style="color:#ABB2BF">;</span></span></code></pre><h2 id="app-server-tsx-server-entry">app/server.tsx — Server entry</h2><p>This file runs only on the server. Use it to connect to databases, register custom API routes, or start background jobs:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">addRoutes</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/server"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#C678DD"> type</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">Hono</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "hono"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Register custom API routes</span></span>
<span class="line"><span style="color:#61AFEF">addRoutes</span><span style="color:#ABB2BF">((</span><span style="color:#E06C75;font-style:italic">app</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">Hono</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E5C07B">    app</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">get</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/api/health"</span><span style="color:#ABB2BF">, (</span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">json</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">ok</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF"> }));</span></span>
<span class="line"><span style="color:#ABB2BF">});</span></span></code></pre><h2 id="app-routes-tsx-route-definitions">app/routes.tsx — Route definitions</h2><p>Routes are defined as a tree. Each node has a <code>module</code> (the page or layout component) and optionally <code>path</code>, <code>children</code>, and <code>middlewares</code>:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#C678DD"> type</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">AppRoutes</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> Root</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./client-root.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> Home</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./pages/Home.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> default</span><span style="color:#ABB2BF"> [</span></span>
<span class="line"><span style="color:#ABB2BF">    {</span></span>
<span class="line"><span style="color:#E06C75">        module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Root</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        isRoot</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#ABB2BF">            { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Home</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">        ],</span></span>
<span class="line"><span style="color:#ABB2BF">    },</span></span>
<span class="line"><span style="color:#ABB2BF">] </span><span style="color:#C678DD">satisfies</span><span style="color:#E5C07B"> AppRoutes</span><span style="color:#ABB2BF">;</span></span></code></pre><p>Notice the <code>import *</code> syntax — this imports the entire module (Component, loader, actions, metadata) as a single object.</p>
<h2 id="your-first-page">Your first page</h2><p>A page in VeloJS can export three things:</p>
<ul>
<li><code>Component</code> — the Preact component that renders the UI</li>
<li><code>loader</code> — a server-side function that fetches data</li>
<li><code>action_*</code> — server-side functions callable from the client</li>
</ul>
<p>Here&#39;s a simple page with a loader:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#C678DD"> type</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">LoaderArgs</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">useLoader</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/hooks"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// This runs on the server. It fetches data for the page.</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> loader</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF"> }: </span><span style="color:#E5C07B">LoaderArgs</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">message</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"Hello, VeloJS!"</span><span style="color:#ABB2BF"> };</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// This runs on both server (SSR) and client (hydration).</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> Component</span><span style="color:#56B6C2"> =</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">data</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#61AFEF"> useLoader</span><span style="color:#ABB2BF">&#x3C;{ </span><span style="color:#E06C75">message</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF"> }>();</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> &#x3C;</span><span style="color:#E5C07B">h1</span><span style="color:#ABB2BF">>{data.value?.</span><span style="color:#E06C75">message</span><span style="color:#ABB2BF">}</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">h1</span><span style="color:#56B6C2">></span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><p>The loader runs on the server, and the data is automatically available in the component through <code>useLoader()</code>. On the first page load (SSR), the data is injected into the HTML. On client-side navigation, it&#39;s fetched via an API call — all automatically.</p>
<h2 id="run-the-dev-server">Run the dev server</h2><pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#61AFEF">npm</span><span style="color:#98C379"> run</span><span style="color:#98C379"> dev</span></span></code></pre><p>Open <code>http://localhost:5173</code> in your browser. Changes to your code will hot-reload instantly.</p>
<h2 id="configuration">Configuration</h2><p>The <code>veloPlugin()</code> accepts optional configuration:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#61AFEF">veloPlugin</span><span style="color:#ABB2BF">({</span></span>
<span class="line"><span style="color:#E06C75">    appDirectory</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"./app"</span><span style="color:#ABB2BF">,      </span><span style="color:#7F848E;font-style:italic">// where your app files live (default: "./app")</span></span>
<span class="line"><span style="color:#E06C75">    routesFile</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"routes.tsx"</span><span style="color:#ABB2BF">,   </span><span style="color:#7F848E;font-style:italic">// your routes file (default: "routes.tsx")</span></span>
<span class="line"><span style="color:#E06C75">    serverInit</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"server.tsx"</span><span style="color:#ABB2BF">,   </span><span style="color:#7F848E;font-style:italic">// server init file (default: "server.tsx")</span></span>
<span class="line"><span style="color:#E06C75">    clientInit</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"client.tsx"</span><span style="color:#ABB2BF">,   </span><span style="color:#7F848E;font-style:italic">// client init file (default: "client.tsx")</span></span>
<span class="line"><span style="color:#ABB2BF">});</span></span></code></pre><p>Most projects don&#39;t need to change these defaults.</p>
`,rawMd:`# Getting Started

VeloJS is a fullstack web framework that combines Hono (server), Preact (UI), and Vite (build) into a single, cohesive experience. You write your pages, loaders, and server actions in one place — VeloJS handles the rest.

## Create a new project

The fastest way to start is with the CLI:

\`\`\`bash
npx @mauroandre/velojs init my-app
cd my-app
npm install
npx velojs dev
\`\`\`

This creates a ready-to-run project. Open \`http://localhost:5173\` and you should see your app.

## Project structure

Every VeloJS project follows this layout:

\`\`\`
my-app/
├── app/
│   ├── routes.tsx        # Where you define all your routes
│   ├── server.tsx        # Server-only init (databases, APIs, etc)
│   ├── client.tsx        # Client-only init (global CSS, etc)
│   ├── client-root.tsx   # The HTML shell (<html>, <head>, <body>)
│   └── pages/            # Your pages, layouts, and modules
├── vite.config.ts        # Vite configuration (just one plugin)
├── tsconfig.json
└── package.json
\`\`\`

Let's walk through each file.

## vite.config.ts

VeloJS works through a single Vite plugin that handles everything — SSR, route scanning, code transforms, and the dev server:

\`\`\`typescript
import { defineConfig } from "vite";
import { veloPlugin } from "@mauroandre/velojs/vite";

export default defineConfig({
    plugins: [veloPlugin()],
});
\`\`\`

That's it. No extra plugins needed.

## package.json scripts

Your project needs three scripts:

\`\`\`json
{
    "scripts": {
        "dev": "velojs dev",
        "build": "velojs build",
        "start": "velojs start"
    }
}
\`\`\`

- \`dev\` — starts the development server with hot reload
- \`build\` — compiles the client bundle and server entry for production
- \`start\` — runs the production server (automatically sets \`NODE_ENV=production\`)

## app/client-root.tsx — The HTML shell

This is the outermost component of your app. It renders the \`<html>\`, \`<head>\`, and \`<body>\` tags. Every page in your app will be rendered inside this shell.

The \`<Scripts />\` component is required — it injects the CSS and JavaScript that your app needs (Vite HMR in dev, compiled assets in production).

\`\`\`tsx
import type { ComponentChildren } from "preact";
import { Scripts } from "@mauroandre/velojs";

export const Component = ({ children }: { children?: ComponentChildren }) => (
    <html lang="en">
        <head>
            <meta charset="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>My App</title>
            <Scripts />
        </head>
        <body>{children}</body>
    </html>
);
\`\`\`

## app/client.tsx — Client entry

This file runs only on the client (browser). Use it to import global CSS or initialize client-side libraries:

\`\`\`typescript
import "./styles/global.css";
\`\`\`

## app/server.tsx — Server entry

This file runs only on the server. Use it to connect to databases, register custom API routes, or start background jobs:

\`\`\`typescript
import { addRoutes } from "@mauroandre/velojs/server";
import type { Hono } from "hono";

// Register custom API routes
addRoutes((app: Hono) => {
    app.get("/api/health", (c) => c.json({ ok: true }));
});
\`\`\`

## app/routes.tsx — Route definitions

Routes are defined as a tree. Each node has a \`module\` (the page or layout component) and optionally \`path\`, \`children\`, and \`middlewares\`:

\`\`\`typescript
import type { AppRoutes } from "@mauroandre/velojs";
import * as Root from "./client-root.js";
import * as Home from "./pages/Home.js";

export default [
    {
        module: Root,
        isRoot: true,
        children: [
            { path: "/", module: Home },
        ],
    },
] satisfies AppRoutes;
\`\`\`

Notice the \`import *\` syntax — this imports the entire module (Component, loader, actions, metadata) as a single object.

## Your first page

A page in VeloJS can export three things:

- \`Component\` — the Preact component that renders the UI
- \`loader\` — a server-side function that fetches data
- \`action_*\` — server-side functions callable from the client

Here's a simple page with a loader:

\`\`\`typescript
import type { LoaderArgs } from "@mauroandre/velojs";
import { useLoader } from "@mauroandre/velojs/hooks";

// This runs on the server. It fetches data for the page.
export const loader = async ({ c }: LoaderArgs) => {
    return { message: "Hello, VeloJS!" };
};

// This runs on both server (SSR) and client (hydration).
export const Component = () => {
    const { data } = useLoader<{ message: string }>();
    return <h1>{data.value?.message}</h1>;
};
\`\`\`

The loader runs on the server, and the data is automatically available in the component through \`useLoader()\`. On the first page load (SSR), the data is injected into the HTML. On client-side navigation, it's fetched via an API call — all automatically.

## Run the dev server

\`\`\`bash
npm run dev
\`\`\`

Open \`http://localhost:5173\` in your browser. Changes to your code will hot-reload instantly.

## Configuration

The \`veloPlugin()\` accepts optional configuration:

\`\`\`typescript
veloPlugin({
    appDirectory: "./app",      // where your app files live (default: "./app")
    routesFile: "routes.tsx",   // your routes file (default: "routes.tsx")
    serverInit: "server.tsx",   // server init file (default: "server.tsx")
    clientInit: "client.tsx",   // client init file (default: "client.tsx")
});
\`\`\`

Most projects don't need to change these defaults.
`},routes:{html:`<h1 id="routes">Routes</h1><p>In VeloJS, all routes are defined in a single file: <code>app/routes.tsx</code>. Instead of filesystem-based routing, you define your routes as a <strong>tree structure</strong>. This gives you full control over layouts, nesting, and middleware inheritance.</p>
<h2 id="the-route-tree">The route tree</h2><p>Each node in the tree represents either a <strong>page</strong> (leaf node) or a <strong>layout</strong> (node with children). Here&#39;s an example with authentication:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#C678DD"> type</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">AppRoutes</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> Root</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./client-root.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> AuthLayout</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./auth/Layout.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> Login</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./auth/Login.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> AdminLayout</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./admin/Layout.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> Dashboard</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./admin/Dashboard.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> Users</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./admin/Users.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> UserDetail</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./admin/UserDetail.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">authMiddleware</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "./modules/auth/auth.middleware.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> default</span><span style="color:#ABB2BF"> [</span></span>
<span class="line"><span style="color:#ABB2BF">    {</span></span>
<span class="line"><span style="color:#E06C75">        module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Root</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        isRoot</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Public routes — no authentication required</span></span>
<span class="line"><span style="color:#ABB2BF">            {</span></span>
<span class="line"><span style="color:#E06C75">                module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">AuthLayout</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/login"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Login</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                ],</span></span>
<span class="line"><span style="color:#ABB2BF">            },</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Protected routes — authMiddleware runs first</span></span>
<span class="line"><span style="color:#ABB2BF">            {</span></span>
<span class="line"><span style="color:#E06C75">                module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">AdminLayout</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                middlewares</span><span style="color:#ABB2BF">: [</span><span style="color:#E06C75">authMiddleware</span><span style="color:#ABB2BF">],</span></span>
<span class="line"><span style="color:#E06C75">                children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Dashboard</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/users"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Users</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/users/:id"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">UserDetail</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                ],</span></span>
<span class="line"><span style="color:#ABB2BF">            },</span></span>
<span class="line"><span style="color:#ABB2BF">        ],</span></span>
<span class="line"><span style="color:#ABB2BF">    },</span></span>
<span class="line"><span style="color:#ABB2BF">] </span><span style="color:#C678DD">satisfies</span><span style="color:#E5C07B"> AppRoutes</span><span style="color:#ABB2BF">;</span></span></code></pre><h2 id="how-nesting-works">How nesting works</h2><p>Routes with <code>children</code> act as <strong>layouts</strong>. Their <code>Component</code> receives <code>children</code> and wraps the nested routes. VeloJS renders the full hierarchy from root to leaf.</p>
<p>For example, when a user visits <code>/users/123</code>, VeloJS renders:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span>Root (isRoot — the &#x3C;html>, &#x3C;head>, &#x3C;body> shell)</span></span>
<span class="line"><span>  └─ AdminLayout (sidebar, navigation bar)</span></span>
<span class="line"><span>       └─ UserDetail (the actual page content)</span></span></code></pre><p>Here&#39;s what the layout components look like:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// app/admin/Layout.tsx — Layout wraps its children</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> Component</span><span style="color:#56B6C2"> =</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">children</span><span style="color:#ABB2BF"> }: { </span><span style="color:#E06C75">children</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">any</span><span style="color:#ABB2BF"> }) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> (</span></span>
<span class="line"><span style="color:#56B6C2">    &#x3C;</span><span style="color:#E06C75">div</span><span style="color:#E06C75"> class</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"layout"</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#56B6C2">        &#x3C;</span><span style="color:#E06C75">nav</span><span style="color:#E06C75"> class</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"sidebar"</span><span style="color:#56B6C2">></span><span style="color:#ABB2BF">...</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">nav</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#56B6C2">        &#x3C;</span><span style="color:#E06C75">main</span><span style="color:#E06C75"> class</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"content"</span><span style="color:#56B6C2">></span><span style="color:#ABB2BF">{</span><span style="color:#E06C75">children</span><span style="color:#ABB2BF">}</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">main</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#56B6C2">    &#x3C;/</span><span style="color:#E06C75">div</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// app/admin/UserDetail.tsx — Page is the leaf (no children)</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> Component</span><span style="color:#56B6C2"> =</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">data</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#61AFEF"> useLoader</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">User</span><span style="color:#ABB2BF">>();</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> &#x3C;</span><span style="color:#E5C07B">div</span><span style="color:#ABB2BF">>{data.value?.</span><span style="color:#E06C75">name</span><span style="color:#ABB2BF">}</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">div</span><span style="color:#56B6C2">></span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><p>Every layout and page can have its own <code>loader</code>. When a page is requested, <strong>all loaders in the hierarchy run in parallel</strong> — the Root loader, AdminLayout loader, and UserDetail loader all execute at the same time. This makes data loading fast.</p>
<h2 id="route-node-properties">Route node properties</h2><table>
<thead>
<tr>
<th>Property</th>
<th>Type</th>
<th>Description</th>
</tr>
</thead>
<tbody><tr>
<td><code>path</code></td>
<td><code>string</code></td>
<td>URL path segment. Supports <code>:params</code> (e.g., <code>/users/:id</code>).</td>
</tr>
<tr>
<td><code>module</code></td>
<td><code>RouteModule</code></td>
<td>The module with <code>Component</code>, <code>loader</code>, and <code>action_*</code> exports.</td>
</tr>
<tr>
<td><code>children</code></td>
<td><code>RouteNode[]</code></td>
<td>Nested routes. When present, the module acts as a layout.</td>
</tr>
<tr>
<td><code>middlewares</code></td>
<td><code>MiddlewareHandler[]</code></td>
<td>Server-side middlewares. Inherited by all children.</td>
</tr>
<tr>
<td><code>isRoot</code></td>
<td><code>boolean</code></td>
<td>Marks the root node (the HTML shell).</td>
</tr>
</tbody></table>
<h2 id="path-resolution">Path resolution</h2><p>Paths are <strong>segments</strong> that build up from parent to child:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span>Root (no path)</span></span>
<span class="line"><span>  └─ AdminLayout (no path)</span></span>
<span class="line"><span>       ├─ Dashboard    → path: "/"           → fullPath: "/"</span></span>
<span class="line"><span>       ├─ Users        → path: "/users"      → fullPath: "/users"</span></span>
<span class="line"><span>       └─ UserDetail   → path: "/users/:id"  → fullPath: "/users/:id"</span></span></code></pre><p>Nodes without a <code>path</code> don&#39;t add a segment to the URL — they are <strong>pure layout wrappers</strong>. This is useful when you want to wrap a group of pages in a shared layout without changing their URLs.</p>
<p>The Vite plugin automatically parses your <code>routes.tsx</code> at build time and calculates both <code>fullPath</code> (the complete URL) and <code>path</code> (the relative segment) for each module.</p>
<h2 id="shared-layouts-different-paths">Shared layouts, different paths</h2><p>You can reuse the same layout for different route groups:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> default</span><span style="color:#ABB2BF"> [</span></span>
<span class="line"><span style="color:#ABB2BF">    {</span></span>
<span class="line"><span style="color:#E06C75">        module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Root</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        isRoot</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Public pages — PublicLayout, no auth</span></span>
<span class="line"><span style="color:#ABB2BF">            {</span></span>
<span class="line"><span style="color:#E06C75">                module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">PublicLayout</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Home</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/about"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">About</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                ],</span></span>
<span class="line"><span style="color:#ABB2BF">            },</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Dashboard — DashboardLayout + auth middleware</span></span>
<span class="line"><span style="color:#ABB2BF">            {</span></span>
<span class="line"><span style="color:#E06C75">                path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/dashboard"</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">DashboardLayout</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                middlewares</span><span style="color:#ABB2BF">: [</span><span style="color:#E06C75">authMiddleware</span><span style="color:#ABB2BF">],</span></span>
<span class="line"><span style="color:#E06C75">                children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Overview</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/settings"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Settings</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                ],</span></span>
<span class="line"><span style="color:#ABB2BF">            },</span></span>
<span class="line"><span style="color:#ABB2BF">        ],</span></span>
<span class="line"><span style="color:#ABB2BF">    },</span></span>
<span class="line"><span style="color:#ABB2BF">] </span><span style="color:#C678DD">satisfies</span><span style="color:#E5C07B"> AppRoutes</span><span style="color:#ABB2BF">;</span></span></code></pre><p>Here, <code>PublicLayout</code> and <code>DashboardLayout</code> are completely separate layouts. Public pages live at <code>/</code> and <code>/about</code>, while dashboard pages live at <code>/dashboard</code> and <code>/dashboard/settings</code>.</p>
`,rawMd:`# Routes

In VeloJS, all routes are defined in a single file: \`app/routes.tsx\`. Instead of filesystem-based routing, you define your routes as a **tree structure**. This gives you full control over layouts, nesting, and middleware inheritance.

## The route tree

Each node in the tree represents either a **page** (leaf node) or a **layout** (node with children). Here's an example with authentication:

\`\`\`typescript
import type { AppRoutes } from "@mauroandre/velojs";
import * as Root from "./client-root.js";
import * as AuthLayout from "./auth/Layout.js";
import * as Login from "./auth/Login.js";
import * as AdminLayout from "./admin/Layout.js";
import * as Dashboard from "./admin/Dashboard.js";
import * as Users from "./admin/Users.js";
import * as UserDetail from "./admin/UserDetail.js";
import { authMiddleware } from "./modules/auth/auth.middleware.js";

export default [
    {
        module: Root,
        isRoot: true,
        children: [
            // Public routes — no authentication required
            {
                module: AuthLayout,
                children: [
                    { path: "/login", module: Login },
                ],
            },
            // Protected routes — authMiddleware runs first
            {
                module: AdminLayout,
                middlewares: [authMiddleware],
                children: [
                    { path: "/", module: Dashboard },
                    { path: "/users", module: Users },
                    { path: "/users/:id", module: UserDetail },
                ],
            },
        ],
    },
] satisfies AppRoutes;
\`\`\`

## How nesting works

Routes with \`children\` act as **layouts**. Their \`Component\` receives \`children\` and wraps the nested routes. VeloJS renders the full hierarchy from root to leaf.

For example, when a user visits \`/users/123\`, VeloJS renders:

\`\`\`
Root (isRoot — the <html>, <head>, <body> shell)
  └─ AdminLayout (sidebar, navigation bar)
       └─ UserDetail (the actual page content)
\`\`\`

Here's what the layout components look like:

\`\`\`typescript
// app/admin/Layout.tsx — Layout wraps its children
export const Component = ({ children }: { children: any }) => (
    <div class="layout">
        <nav class="sidebar">...</nav>
        <main class="content">{children}</main>
    </div>
);

// app/admin/UserDetail.tsx — Page is the leaf (no children)
export const Component = () => {
    const { data } = useLoader<User>();
    return <div>{data.value?.name}</div>;
};
\`\`\`

Every layout and page can have its own \`loader\`. When a page is requested, **all loaders in the hierarchy run in parallel** — the Root loader, AdminLayout loader, and UserDetail loader all execute at the same time. This makes data loading fast.

## Route node properties

| Property | Type | Description |
|----------|------|-------------|
| \`path\` | \`string\` | URL path segment. Supports \`:params\` (e.g., \`/users/:id\`). |
| \`module\` | \`RouteModule\` | The module with \`Component\`, \`loader\`, and \`action_*\` exports. |
| \`children\` | \`RouteNode[]\` | Nested routes. When present, the module acts as a layout. |
| \`middlewares\` | \`MiddlewareHandler[]\` | Server-side middlewares. Inherited by all children. |
| \`isRoot\` | \`boolean\` | Marks the root node (the HTML shell). |

## Path resolution

Paths are **segments** that build up from parent to child:

\`\`\`
Root (no path)
  └─ AdminLayout (no path)
       ├─ Dashboard    → path: "/"           → fullPath: "/"
       ├─ Users        → path: "/users"      → fullPath: "/users"
       └─ UserDetail   → path: "/users/:id"  → fullPath: "/users/:id"
\`\`\`

Nodes without a \`path\` don't add a segment to the URL — they are **pure layout wrappers**. This is useful when you want to wrap a group of pages in a shared layout without changing their URLs.

The Vite plugin automatically parses your \`routes.tsx\` at build time and calculates both \`fullPath\` (the complete URL) and \`path\` (the relative segment) for each module.

## Shared layouts, different paths

You can reuse the same layout for different route groups:

\`\`\`typescript
export default [
    {
        module: Root,
        isRoot: true,
        children: [
            // Public pages — PublicLayout, no auth
            {
                module: PublicLayout,
                children: [
                    { path: "/", module: Home },
                    { path: "/about", module: About },
                ],
            },
            // Dashboard — DashboardLayout + auth middleware
            {
                path: "/dashboard",
                module: DashboardLayout,
                middlewares: [authMiddleware],
                children: [
                    { path: "/", module: Overview },
                    { path: "/settings", module: Settings },
                ],
            },
        ],
    },
] satisfies AppRoutes;
\`\`\`

Here, \`PublicLayout\` and \`DashboardLayout\` are completely separate layouts. Public pages live at \`/\` and \`/about\`, while dashboard pages live at \`/dashboard\` and \`/dashboard/settings\`.
`},components:{html:`<h1 id="components">Components</h1><p>Every page and layout in VeloJS is a module that can export up to three things. Understanding these conventions is key to building with VeloJS.</p>
<h2 id="the-three-exports">The three exports</h2><table>
<thead>
<tr>
<th>Export</th>
<th>Purpose</th>
</tr>
</thead>
<tbody><tr>
<td><code>export const Component</code></td>
<td>The Preact component that renders the UI (required)</td>
</tr>
<tr>
<td><code>export const loader</code></td>
<td>A server-side function that fetches data for the page</td>
</tr>
<tr>
<td><code>export const action_*</code></td>
<td>Server-side functions callable from the client (RPC)</td>
</tr>
</tbody></table>
<h2 id="example-page">Example page</h2><p>Here&#39;s a complete page that uses all three:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// app/admin/Users.tsx</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#C678DD"> type</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">LoaderArgs</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">ActionArgs</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">useLoader</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/hooks"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">interface</span><span style="color:#E5C07B"> User</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">; </span><span style="color:#E06C75">name</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">; }</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// 1. Loader — runs on the server, fetches data</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> loader</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">params</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75;font-style:italic">query</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF"> }: </span><span style="color:#E5C07B">LoaderArgs</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">getUsers</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> import</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"./user.service.js"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#61AFEF"> getUsers</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// 2. Action — runs on the server, called from the client</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> action_delete</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> ({</span></span>
<span class="line"><span style="color:#E06C75">    body</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">    c</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#ABB2BF">}: </span><span style="color:#E5C07B">ActionArgs</span><span style="color:#ABB2BF">&#x3C;{ </span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF"> }>) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">deleteUser</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> import</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"./user.service.js"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    await</span><span style="color:#61AFEF"> deleteUser</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">body</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">ok</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF"> };</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// 3. Component — renders on both server (SSR) and client</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> Component</span><span style="color:#56B6C2"> =</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">data</span><span style="color:#ABB2BF">, </span><span style="color:#E5C07B">loading</span><span style="color:#ABB2BF">, </span><span style="color:#E5C07B">refetch</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#61AFEF"> useLoader</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">User</span><span style="color:#ABB2BF">[]>();</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">    if</span><span style="color:#ABB2BF"> (</span><span style="color:#E5C07B">loading</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">value</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">return</span><span style="color:#ABB2BF"> &#x3C;</span><span style="color:#E5C07B">div</span><span style="color:#ABB2BF">></span><span style="color:#E06C75">Loading</span><span style="color:#ABB2BF">...</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">div</span><span style="color:#56B6C2">></span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> (</span></span>
<span class="line"><span style="color:#ABB2BF">        &#x3C;</span><span style="color:#E5C07B">ul</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">            {</span><span style="color:#E06C75;font-style:italic">data</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75;font-style:italic">value</span><span style="color:#ABB2BF">?.</span><span style="color:#E06C75;font-style:italic">map</span><span style="color:#ABB2BF">((</span><span style="color:#E06C75;font-style:italic">u</span><span style="color:#ABB2BF">) </span><span style="color:#56B6C2">=></span><span style="color:#ABB2BF"> (</span></span>
<span class="line"><span style="color:#56B6C2">                &#x3C;</span><span style="color:#E06C75">li</span><span style="color:#E06C75"> key</span><span style="color:#56B6C2">=</span><span style="color:#ABB2BF">{u.</span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">}</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#ABB2BF">                    {</span><span style="color:#E06C75;font-style:italic">u</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75;font-style:italic">name</span><span style="color:#ABB2BF">}</span></span>
<span class="line"><span style="color:#56B6C2">                    &#x3C;</span><span style="color:#E06C75">button</span><span style="color:#E06C75"> onClick</span><span style="color:#56B6C2">=</span><span style="color:#ABB2BF">{</span><span style="color:#61AFEF">async</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E5C07B">                        await</span><span style="color:#61AFEF"> action_delete</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">body</span><span style="color:#ABB2BF">: { </span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75;font-style:italic">u</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75;font-style:italic">id</span><span style="color:#ABB2BF"> } });</span></span>
<span class="line"><span style="color:#61AFEF">                        refetch</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#ABB2BF">                    }}</span><span style="color:#56B6C2">></span><span style="color:#E06C75">Delete</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">button</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#56B6C2">                &#x3C;/</span><span style="color:#E06C75">li</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#ABB2BF">            ))}</span></span>
<span class="line"><span style="color:#56B6C2">        &#x3C;/</span><span style="color:#E06C75">ul</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#ABB2BF">    );</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><h2 id="server-only-imports-critical">Server-only imports (critical)</h2><p>This is the <strong>most important convention</strong> in VeloJS. Read this carefully.</p>
<p>Your page file is bundled for <strong>both</strong> server and client. The Vite plugin strips the loader body and transforms actions into fetch stubs for the client — but <strong>top-level imports are kept in the client bundle</strong>.</p>
<p>This means if you import a server-only module (database driver, file system, secrets) at the top of the file, it will leak into the client bundle and likely break the build.</p>
<p><strong>The rule</strong>: always use <code>await import()</code> inside loaders and actions for server-only code.</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// BAD — this import goes into the client bundle</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">getUsers</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "./user.service.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">db</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "../db/engine.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> loader</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#E5C07B"> db</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">collection</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"users"</span><span style="color:#ABB2BF">).</span><span style="color:#61AFEF">find</span><span style="color:#ABB2BF">().</span><span style="color:#61AFEF">toArray</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// GOOD — dynamic import only runs on the server</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> loader</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">getUsers</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> import</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"./user.service.js"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#61AFEF"> getUsers</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><p>Why does this matter? Because <code>user.service.js</code> might import a database driver, which imports Node.js native modules like <code>fs</code> or <code>crypto</code>. If that code ends up in the client bundle, Vite will throw errors or include unnecessary code.</p>
<p><strong>Think of it this way</strong>: any <code>import</code> at the top of the file is shared between server and client. Any <code>await import()</code> inside a function is server-only (because loaders and actions only run on the server).</p>
`,rawMd:`# Components

Every page and layout in VeloJS is a module that can export up to three things. Understanding these conventions is key to building with VeloJS.

## The three exports

| Export | Purpose |
|--------|---------|
| \`export const Component\` | The Preact component that renders the UI (required) |
| \`export const loader\` | A server-side function that fetches data for the page |
| \`export const action_*\` | Server-side functions callable from the client (RPC) |

## Example page

Here's a complete page that uses all three:

\`\`\`typescript
// app/admin/Users.tsx
import type { LoaderArgs, ActionArgs } from "@mauroandre/velojs";
import { useLoader } from "@mauroandre/velojs/hooks";

interface User { id: string; name: string; }

// 1. Loader — runs on the server, fetches data
export const loader = async ({ params, query, c }: LoaderArgs) => {
    const { getUsers } = await import("./user.service.js");
    return getUsers();
};

// 2. Action — runs on the server, called from the client
export const action_delete = async ({
    body,
    c,
}: ActionArgs<{ id: string }>) => {
    const { deleteUser } = await import("./user.service.js");
    await deleteUser(body.id);
    return { ok: true };
};

// 3. Component — renders on both server (SSR) and client
export const Component = () => {
    const { data, loading, refetch } = useLoader<User[]>();

    if (loading.value) return <div>Loading...</div>;

    return (
        <ul>
            {data.value?.map((u) => (
                <li key={u.id}>
                    {u.name}
                    <button onClick={async () => {
                        await action_delete({ body: { id: u.id } });
                        refetch();
                    }}>Delete</button>
                </li>
            ))}
        </ul>
    );
};
\`\`\`

## Server-only imports (critical)

This is the **most important convention** in VeloJS. Read this carefully.

Your page file is bundled for **both** server and client. The Vite plugin strips the loader body and transforms actions into fetch stubs for the client — but **top-level imports are kept in the client bundle**.

This means if you import a server-only module (database driver, file system, secrets) at the top of the file, it will leak into the client bundle and likely break the build.

**The rule**: always use \`await import()\` inside loaders and actions for server-only code.

\`\`\`typescript
// BAD — this import goes into the client bundle
import { getUsers } from "./user.service.js";
import { db } from "../db/engine.js";

export const loader = async () => {
    return db.collection("users").find().toArray();
};
\`\`\`

\`\`\`typescript
// GOOD — dynamic import only runs on the server
export const loader = async () => {
    const { getUsers } = await import("./user.service.js");
    return getUsers();
};
\`\`\`

Why does this matter? Because \`user.service.js\` might import a database driver, which imports Node.js native modules like \`fs\` or \`crypto\`. If that code ends up in the client bundle, Vite will throw errors or include unnecessary code.

**Think of it this way**: any \`import\` at the top of the file is shared between server and client. Any \`await import()\` inside a function is server-only (because loaders and actions only run on the server).
`},loaders:{html:`<h1 id="loaders">Loaders</h1><p>Loaders are how you fetch data on the server and make it available to your components. VeloJS provides two patterns, each designed for a different use case.</p>
<h2 id="useloader-component-level-data">useLoader — Component-level data</h2><p>Use <code>useLoader</code> inside a <code>Component</code> when you need data that&#39;s specific to that page. It supports both SSR (server-side rendering) and SPA navigation (client-side fetch).</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> Component</span><span style="color:#56B6C2"> =</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">data</span><span style="color:#ABB2BF">, </span><span style="color:#E5C07B">loading</span><span style="color:#ABB2BF">, </span><span style="color:#E5C07B">refetch</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#61AFEF"> useLoader</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">MyType</span><span style="color:#ABB2BF">>();</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // data: Signal&#x3C;T | null>     — the loader data (reactive)</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // loading: Signal&#x3C;boolean>   — true while fetching</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // refetch: () => void        — manually re-fetch the data</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><p><strong>How it works:</strong></p>
<ul>
<li>On the first page load (SSR), the data is rendered on the server and injected into the HTML</li>
<li>When the user navigates to this page via a link (SPA), <code>useLoader</code> fetches the data from the server automatically</li>
<li>The data is a Preact signal — your UI updates automatically when it changes</li>
</ul>
<h3 id="re-fetching-on-route-changes">Re-fetching on route changes</h3><p>If your page depends on URL parameters (like a user ID), pass them as dependencies. The data will re-fetch whenever the dependencies change:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">const</span><span style="color:#E5C07B"> params</span><span style="color:#56B6C2"> =</span><span style="color:#61AFEF"> useParams</span><span style="color:#ABB2BF">&#x3C;{ </span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF"> }>();</span></span>
<span class="line"><span style="color:#C678DD">const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">data</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#61AFEF"> useLoader</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">User</span><span style="color:#ABB2BF">>([</span><span style="color:#E5C07B">params</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">]);</span></span></code></pre><h2 id="loader-module-level-shared-data">Loader — Module-level shared data</h2><p>Use <code>Loader</code> (capital L, outside of components) when you need data that&#39;s shared across multiple pages. This is typically used in <strong>layouts</strong> to load data that child pages need.</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// app/admin/Layout.tsx</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">Loader</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/hooks"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// This runs once when the module is imported — not inside a component</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">data</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">userData</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#61AFEF"> Loader</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">UserData</span><span style="color:#ABB2BF">>();</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> loader</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF"> }: </span><span style="color:#E5C07B">LoaderArgs</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#E5C07B"> user</span><span style="color:#56B6C2"> =</span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">get</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"user"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">name</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">user</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">name</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">role</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">user</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">role</span><span style="color:#ABB2BF"> };</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> Component</span><span style="color:#56B6C2"> =</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">children</span><span style="color:#ABB2BF"> }) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> (</span></span>
<span class="line"><span style="color:#ABB2BF">    &#x3C;</span><span style="color:#E5C07B">div</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">        &#x3C;</span><span style="color:#E5C07B">header</span><span style="color:#ABB2BF">></span><span style="color:#E06C75;font-style:italic">Hello</span><span style="color:#ABB2BF">, {</span><span style="color:#E06C75;font-style:italic">userData</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75;font-style:italic">value</span><span style="color:#ABB2BF">?.</span><span style="color:#E06C75;font-style:italic">name</span><span style="color:#ABB2BF">}</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">header</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#ABB2BF">        {</span><span style="color:#E06C75;font-style:italic">children</span><span style="color:#ABB2BF">}</span></span>
<span class="line"><span style="color:#56B6C2">    &#x3C;/</span><span style="color:#E06C75">div</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#ABB2BF">);</span></span></code></pre><p>Child pages can import the shared data directly:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// app/admin/Dashboard.tsx</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">userData</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "./Layout.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> Component</span><span style="color:#56B6C2"> =</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> (</span></span>
<span class="line"><span style="color:#ABB2BF">    &#x3C;</span><span style="color:#E5C07B">div</span><span style="color:#ABB2BF">></span><span style="color:#E06C75;font-style:italic">Role</span><span style="color:#ABB2BF">: {</span><span style="color:#E5C07B">userData</span><span style="color:#ABB2BF">.</span><span style="color:#E5C07B">value</span><span style="color:#ABB2BF">?.</span><span style="color:#E06C75">role</span><span style="color:#ABB2BF">}&#x3C;/</span><span style="color:#E5C07B">div</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">);</span></span></code></pre><p><strong>Important difference from useLoader:</strong> <code>Loader</code> only hydrates from SSR data. It does <strong>not</strong> re-fetch on client-side navigation. It&#39;s designed for data that stays constant across an entire section of your app (like the current user in a layout).</p>
<h2 id="when-to-use-which">When to use which</h2><table>
<thead>
<tr>
<th>Scenario</th>
<th>Use</th>
</tr>
</thead>
<tbody><tr>
<td>Page-specific data (list of users, post details)</td>
<td><code>useLoader</code></td>
</tr>
<tr>
<td>Data that changes when URL params change</td>
<td><code>useLoader</code> with deps</td>
</tr>
<tr>
<td>Shared data in a layout (current user, permissions)</td>
<td><code>Loader</code></td>
</tr>
<tr>
<td>Data needed by multiple sibling pages</td>
<td><code>Loader</code> in their parent layout</td>
</tr>
</tbody></table>
<h2 id="how-data-flows">How data flows</h2><p>Understanding the data flow helps you debug issues:</p>
<p><strong>First page load (SSR):</strong></p>
<ol>
<li>All loaders in the route hierarchy run in parallel on the server</li>
<li>The server injects the data into the HTML as <code>window.__PAGE_DATA__</code></li>
<li><code>useLoader()</code> and <code>Loader()</code> hydrate from <code>__PAGE_DATA__</code> — no extra fetch needed</li>
</ol>
<p><strong>Client-side navigation (SPA):</strong></p>
<ol>
<li>User clicks a link</li>
<li><code>useLoader()</code> fetches <code>currentPath?_data=1</code> from the server</li>
<li>The server runs all loaders and returns JSON</li>
<li><code>useLoader()</code> updates its signal with the new data</li>
<li><code>Loader()</code> does nothing — it keeps the data from the initial SSR</li>
</ol>
`,rawMd:`# Loaders

Loaders are how you fetch data on the server and make it available to your components. VeloJS provides two patterns, each designed for a different use case.

## useLoader — Component-level data

Use \`useLoader\` inside a \`Component\` when you need data that's specific to that page. It supports both SSR (server-side rendering) and SPA navigation (client-side fetch).

\`\`\`typescript
export const Component = () => {
    const { data, loading, refetch } = useLoader<MyType>();

    // data: Signal<T | null>     — the loader data (reactive)
    // loading: Signal<boolean>   — true while fetching
    // refetch: () => void        — manually re-fetch the data
};
\`\`\`

**How it works:**
- On the first page load (SSR), the data is rendered on the server and injected into the HTML
- When the user navigates to this page via a link (SPA), \`useLoader\` fetches the data from the server automatically
- The data is a Preact signal — your UI updates automatically when it changes

### Re-fetching on route changes

If your page depends on URL parameters (like a user ID), pass them as dependencies. The data will re-fetch whenever the dependencies change:

\`\`\`typescript
const params = useParams<{ id: string }>();
const { data } = useLoader<User>([params.id]);
\`\`\`

## Loader — Module-level shared data

Use \`Loader\` (capital L, outside of components) when you need data that's shared across multiple pages. This is typically used in **layouts** to load data that child pages need.

\`\`\`typescript
// app/admin/Layout.tsx
import { Loader } from "@mauroandre/velojs/hooks";

// This runs once when the module is imported — not inside a component
export const { data: userData } = Loader<UserData>();

export const loader = async ({ c }: LoaderArgs) => {
    const user = c.get("user");
    return { name: user.name, role: user.role };
};

export const Component = ({ children }) => (
    <div>
        <header>Hello, {userData.value?.name}</header>
        {children}
    </div>
);
\`\`\`

Child pages can import the shared data directly:

\`\`\`typescript
// app/admin/Dashboard.tsx
import { userData } from "./Layout.js";

export const Component = () => (
    <div>Role: {userData.value?.role}</div>
);
\`\`\`

**Important difference from useLoader:** \`Loader\` only hydrates from SSR data. It does **not** re-fetch on client-side navigation. It's designed for data that stays constant across an entire section of your app (like the current user in a layout).

## When to use which

| Scenario | Use |
|----------|-----|
| Page-specific data (list of users, post details) | \`useLoader\` |
| Data that changes when URL params change | \`useLoader\` with deps |
| Shared data in a layout (current user, permissions) | \`Loader\` |
| Data needed by multiple sibling pages | \`Loader\` in their parent layout |

## How data flows

Understanding the data flow helps you debug issues:

**First page load (SSR):**
1. All loaders in the route hierarchy run in parallel on the server
2. The server injects the data into the HTML as \`window.__PAGE_DATA__\`
3. \`useLoader()\` and \`Loader()\` hydrate from \`__PAGE_DATA__\` — no extra fetch needed

**Client-side navigation (SPA):**
1. User clicks a link
2. \`useLoader()\` fetches \`currentPath?_data=1\` from the server
3. The server runs all loaders and returns JSON
4. \`useLoader()\` updates its signal with the new data
5. \`Loader()\` does nothing — it keeps the data from the initial SSR
`},actions:{html:`<h1 id="actions">Actions</h1><p>Actions are server-side functions that you can call from the client as if they were regular functions. VeloJS transforms them into HTTP calls automatically — you write server code, the framework handles the rest.</p>
<h2 id="how-actions-work">How actions work</h2><p>Any exported function starting with <code>action_</code> is treated as a server action:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> action_login</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> ({</span></span>
<span class="line"><span style="color:#E06C75">    body</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">    c</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#ABB2BF">}: </span><span style="color:#E5C07B">ActionArgs</span><span style="color:#ABB2BF">&#x3C;{ </span><span style="color:#E06C75">email</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">; </span><span style="color:#E06C75">password</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF"> }>) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">authenticate</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> import</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"./auth.service.js"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#E5C07B"> token</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> authenticate</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">body</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">email</span><span style="color:#ABB2BF">, </span><span style="color:#E5C07B">body</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">password</span><span style="color:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">setCookie</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> import</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"@mauroandre/velojs/cookie"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#61AFEF">    setCookie</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">c</span><span style="color:#56B6C2">!</span><span style="color:#ABB2BF">, </span><span style="color:#98C379">"session"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">token</span><span style="color:#ABB2BF">, { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/"</span><span style="color:#ABB2BF"> });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">ok</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF"> };</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><p>On the <strong>server</strong>, this function runs normally — it has access to the Hono context (<code>c</code>), can read cookies, access the database, and do anything a server function can do.</p>
<p>On the <strong>client</strong>, the Vite plugin replaces the function body with a <code>fetch()</code> call. The client version looks like this:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// What the client actually executes (generated automatically):</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> action_login</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">body</span><span style="color:#ABB2BF"> }: { </span><span style="color:#E06C75">body</span><span style="color:#ABB2BF">: { </span><span style="color:#E06C75">email</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">; </span><span style="color:#E06C75">password</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF"> } }) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#61AFEF"> fetch</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/_action/auth/Login/login"</span><span style="color:#ABB2BF">, {</span></span>
<span class="line"><span style="color:#E06C75">        method</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"POST"</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        headers</span><span style="color:#ABB2BF">: { </span><span style="color:#98C379">"Content-Type"</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"application/json"</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#E06C75">        body</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">JSON</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">stringify</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">body</span><span style="color:#ABB2BF">),</span></span>
<span class="line"><span style="color:#ABB2BF">    }).</span><span style="color:#61AFEF">then</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75;font-style:italic">r</span><span style="color:#C678DD"> =></span><span style="color:#E5C07B"> r</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">json</span><span style="color:#ABB2BF">());</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><p>You don&#39;t write this — the Vite plugin generates it at build time by analyzing the AST of your code.</p>
<h2 id="the-actionargs-type">The ActionArgs type</h2><p>Every action receives an object with these properties:</p>
<table>
<thead>
<tr>
<th>Property</th>
<th>Type</th>
<th>Available on</th>
<th>Description</th>
</tr>
</thead>
<tbody><tr>
<td><code>body</code></td>
<td><code>TBody</code></td>
<td>Server + Client</td>
<td>The data sent from the client</td>
</tr>
<tr>
<td><code>c</code></td>
<td><code>Context</code></td>
<td>Server only</td>
<td>Hono request context (cookies, headers, etc)</td>
</tr>
<tr>
<td><code>params</code></td>
<td><code>Record&lt;string, string&gt;</code></td>
<td>Server only</td>
<td>URL parameters</td>
</tr>
<tr>
<td><code>query</code></td>
<td><code>Record&lt;string, string&gt;</code></td>
<td>Server only</td>
<td>Query string parameters</td>
</tr>
</tbody></table>
<p>On the client, only <code>body</code> is available (the rest are stripped by the Vite plugin).</p>
<h2 id="error-handling">Error handling</h2><p>Actions <strong>do not throw</strong> on server errors. Instead, they resolve with <code>{ error: &quot;message&quot; }</code>. Always check for errors explicitly:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">const</span><span style="color:#E5C07B"> result</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> action_login</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">body</span><span style="color:#ABB2BF">: { </span><span style="color:#E06C75">email</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">password</span><span style="color:#ABB2BF"> } });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">if</span><span style="color:#ABB2BF"> (</span><span style="color:#E5C07B">result</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">error</span><span style="color:#ABB2BF">) {</span></span>
<span class="line"><span style="color:#61AFEF">    showToast</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">result</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">error</span><span style="color:#ABB2BF">, </span><span style="color:#98C379">"danger"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#ABB2BF">}</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Success</span></span>
<span class="line"><span style="color:#E5C07B">window</span><span style="color:#ABB2BF">.</span><span style="color:#E5C07B">location</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">href</span><span style="color:#56B6C2"> =</span><span style="color:#98C379"> "/admin"</span><span style="color:#ABB2BF">;</span></span></code></pre><h2 id="remember-use-dynamic-imports">Remember: use dynamic imports</h2><p>Just like loaders, actions should use <code>await import()</code> for server-only code:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> action_delete</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">body</span><span style="color:#ABB2BF"> }: </span><span style="color:#E5C07B">ActionArgs</span><span style="color:#ABB2BF">&#x3C;{ </span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF"> }>) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // GOOD — dynamic import</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">deleteUser</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> import</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"./user.service.js"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    await</span><span style="color:#61AFEF"> deleteUser</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">body</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">ok</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF"> };</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre>`,rawMd:`# Actions

Actions are server-side functions that you can call from the client as if they were regular functions. VeloJS transforms them into HTTP calls automatically — you write server code, the framework handles the rest.

## How actions work

Any exported function starting with \`action_\` is treated as a server action:

\`\`\`typescript
export const action_login = async ({
    body,
    c,
}: ActionArgs<{ email: string; password: string }>) => {
    const { authenticate } = await import("./auth.service.js");
    const token = await authenticate(body.email, body.password);

    const { setCookie } = await import("@mauroandre/velojs/cookie");
    setCookie(c!, "session", token, { path: "/" });

    return { ok: true };
};
\`\`\`

On the **server**, this function runs normally — it has access to the Hono context (\`c\`), can read cookies, access the database, and do anything a server function can do.

On the **client**, the Vite plugin replaces the function body with a \`fetch()\` call. The client version looks like this:

\`\`\`typescript
// What the client actually executes (generated automatically):
export const action_login = async ({ body }: { body: { email: string; password: string } }) => {
    return fetch("/_action/auth/Login/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
    }).then(r => r.json());
};
\`\`\`

You don't write this — the Vite plugin generates it at build time by analyzing the AST of your code.

## The ActionArgs type

Every action receives an object with these properties:

| Property | Type | Available on | Description |
|----------|------|-------------|-------------|
| \`body\` | \`TBody\` | Server + Client | The data sent from the client |
| \`c\` | \`Context\` | Server only | Hono request context (cookies, headers, etc) |
| \`params\` | \`Record<string, string>\` | Server only | URL parameters |
| \`query\` | \`Record<string, string>\` | Server only | Query string parameters |

On the client, only \`body\` is available (the rest are stripped by the Vite plugin).

## Error handling

Actions **do not throw** on server errors. Instead, they resolve with \`{ error: "message" }\`. Always check for errors explicitly:

\`\`\`typescript
const result = await action_login({ body: { email, password } });

if (result.error) {
    showToast(result.error, "danger");
    return;
}

// Success
window.location.href = "/admin";
\`\`\`

## Remember: use dynamic imports

Just like loaders, actions should use \`await import()\` for server-only code:

\`\`\`typescript
export const action_delete = async ({ body }: ActionArgs<{ id: string }>) => {
    // GOOD — dynamic import
    const { deleteUser } = await import("./user.service.js");
    await deleteUser(body.id);
    return { ok: true };
};
\`\`\`
`},hooks:{html:`<h1 id="hooks">Hooks</h1><p>VeloJS provides a set of hooks that work identically on both server (SSR) and client. On the server, they read from <code>AsyncLocalStorage</code> (isolated per request). On the client, they use the DOM and wouter-preact.</p>
<h2 id="available-hooks">Available hooks</h2><table>
<thead>
<tr>
<th>Hook</th>
<th>Returns</th>
<th>Description</th>
</tr>
</thead>
<tbody><tr>
<td><code>useLoader&lt;T&gt;(deps?)</code></td>
<td><code>{ data, loading, refetch }</code></td>
<td>Page data with SSR + SPA support</td>
</tr>
<tr>
<td><code>Loader&lt;T&gt;()</code></td>
<td><code>{ data, loading }</code></td>
<td>Module-level SSR-only data</td>
</tr>
<tr>
<td><code>useParams&lt;T&gt;()</code></td>
<td><code>T</code></td>
<td>URL parameters (<code>:id</code>, etc)</td>
</tr>
<tr>
<td><code>useQuery&lt;T&gt;()</code></td>
<td><code>T</code></td>
<td>Query string parameters</td>
</tr>
<tr>
<td><code>useNavigate()</code></td>
<td><code>navigate(path)</code></td>
<td>Programmatic navigation</td>
</tr>
<tr>
<td><code>usePathname()</code></td>
<td><code>string</code></td>
<td>Absolute URL pathname</td>
</tr>
<tr>
<td><code>touch(signal)</code></td>
<td><code>void</code></td>
<td>Force signal notification after mutation</td>
</tr>
</tbody></table>
<h2 id="useparams">useParams</h2><p>Reads URL parameters from the current route. For example, if your route path is <code>/users/:id</code>:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">const</span><span style="color:#E5C07B"> params</span><span style="color:#56B6C2"> =</span><span style="color:#61AFEF"> useParams</span><span style="color:#ABB2BF">&#x3C;{ </span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF"> }>();</span></span>
<span class="line"><span style="color:#E5C07B">console</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">log</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">params</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">); </span><span style="color:#7F848E;font-style:italic">// "123" when visiting /users/123</span></span></code></pre><h2 id="usequery">useQuery</h2><p>Reads query string parameters from the URL. For example, visiting <code>/search?q=hello&amp;page=2</code>:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">const</span><span style="color:#E5C07B"> query</span><span style="color:#56B6C2"> =</span><span style="color:#61AFEF"> useQuery</span><span style="color:#ABB2BF">&#x3C;{ </span><span style="color:#E06C75">q</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">; </span><span style="color:#E06C75">page</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF"> }>();</span></span>
<span class="line"><span style="color:#E5C07B">console</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">log</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">query</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">q</span><span style="color:#ABB2BF">);    </span><span style="color:#7F848E;font-style:italic">// "hello"</span></span>
<span class="line"><span style="color:#E5C07B">console</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">log</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">query</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">page</span><span style="color:#ABB2BF">); </span><span style="color:#7F848E;font-style:italic">// "2"</span></span></code></pre><h2 id="usenavigate">useNavigate</h2><p>Returns a function for programmatic navigation (when you need to navigate from code, not from a link):</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">const</span><span style="color:#E5C07B"> navigate</span><span style="color:#56B6C2"> =</span><span style="color:#61AFEF"> useNavigate</span><span style="color:#ABB2BF">();</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">const</span><span style="color:#61AFEF"> handleLogin</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#E5C07B"> result</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> action_login</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">body</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">credentials</span><span style="color:#ABB2BF"> });</span></span>
<span class="line"><span style="color:#C678DD">    if</span><span style="color:#ABB2BF"> (</span><span style="color:#56B6C2">!</span><span style="color:#E5C07B">result</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">error</span><span style="color:#ABB2BF">) {</span></span>
<span class="line"><span style="color:#61AFEF">        navigate</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/admin"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#ABB2BF">    }</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><h2 id="usepathname">usePathname</h2><p>Returns the <strong>absolute</strong> pathname of the current URL. This is different from wouter&#39;s <code>useLocation</code>, which returns a path relative to the current layout context.</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">const</span><span style="color:#E5C07B"> pathname</span><span style="color:#56B6C2"> =</span><span style="color:#61AFEF"> usePathname</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Always returns the full path, e.g., "/admin/users/123"</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Even when inside a nested layout like /admin</span></span></code></pre><p>This is useful when you need to know the exact URL, regardless of layout nesting.</p>
<h2 id="touch">touch</h2><p>Preact signals are great for reactivity, but they have a limitation: mutating a nested property (like changing <code>items[0].checked</code>) doesn&#39;t trigger a signal update. The <code>touch</code> function forces the signal to notify its subscribers after a mutation:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">useSignal</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@preact/signals"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">touch</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/hooks"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">const</span><span style="color:#E5C07B"> items</span><span style="color:#56B6C2"> =</span><span style="color:#61AFEF"> useSignal</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">Item</span><span style="color:#ABB2BF">[]>([]);</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Mutating a nested property — signal doesn't know about this</span></span>
<span class="line"><span style="color:#E5C07B">items</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">value</span><span style="color:#ABB2BF">[</span><span style="color:#D19A66">0</span><span style="color:#ABB2BF">].</span><span style="color:#E06C75">checked</span><span style="color:#56B6C2"> =</span><span style="color:#D19A66"> true</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// touch() creates a shallow copy, which triggers the update</span></span>
<span class="line"><span style="color:#61AFEF">touch</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">items</span><span style="color:#ABB2BF">);</span></span></code></pre><p>Use <code>touch</code> whenever you mutate nested properties on a signal value instead of replacing the entire value.</p>
`,rawMd:`# Hooks

VeloJS provides a set of hooks that work identically on both server (SSR) and client. On the server, they read from \`AsyncLocalStorage\` (isolated per request). On the client, they use the DOM and wouter-preact.

## Available hooks

| Hook | Returns | Description |
|------|---------|-------------|
| \`useLoader<T>(deps?)\` | \`{ data, loading, refetch }\` | Page data with SSR + SPA support |
| \`Loader<T>()\` | \`{ data, loading }\` | Module-level SSR-only data |
| \`useParams<T>()\` | \`T\` | URL parameters (\`:id\`, etc) |
| \`useQuery<T>()\` | \`T\` | Query string parameters |
| \`useNavigate()\` | \`navigate(path)\` | Programmatic navigation |
| \`usePathname()\` | \`string\` | Absolute URL pathname |
| \`touch(signal)\` | \`void\` | Force signal notification after mutation |

## useParams

Reads URL parameters from the current route. For example, if your route path is \`/users/:id\`:

\`\`\`typescript
const params = useParams<{ id: string }>();
console.log(params.id); // "123" when visiting /users/123
\`\`\`

## useQuery

Reads query string parameters from the URL. For example, visiting \`/search?q=hello&page=2\`:

\`\`\`typescript
const query = useQuery<{ q: string; page: string }>();
console.log(query.q);    // "hello"
console.log(query.page); // "2"
\`\`\`

## useNavigate

Returns a function for programmatic navigation (when you need to navigate from code, not from a link):

\`\`\`typescript
const navigate = useNavigate();

const handleLogin = async () => {
    const result = await action_login({ body: credentials });
    if (!result.error) {
        navigate("/admin");
    }
};
\`\`\`

## usePathname

Returns the **absolute** pathname of the current URL. This is different from wouter's \`useLocation\`, which returns a path relative to the current layout context.

\`\`\`typescript
const pathname = usePathname();
// Always returns the full path, e.g., "/admin/users/123"
// Even when inside a nested layout like /admin
\`\`\`

This is useful when you need to know the exact URL, regardless of layout nesting.

## touch

Preact signals are great for reactivity, but they have a limitation: mutating a nested property (like changing \`items[0].checked\`) doesn't trigger a signal update. The \`touch\` function forces the signal to notify its subscribers after a mutation:

\`\`\`typescript
import { useSignal } from "@preact/signals";
import { touch } from "@mauroandre/velojs/hooks";

const items = useSignal<Item[]>([]);

// Mutating a nested property — signal doesn't know about this
items.value[0].checked = true;

// touch() creates a shallow copy, which triggers the update
touch(items);
\`\`\`

Use \`touch\` whenever you mutate nested properties on a signal value instead of replacing the entire value.
`},"link-component":{html:`<h1 id="link-component">Link Component</h1><p>The <code>Link</code> component handles navigation in VeloJS. It supports both simple string paths and type-safe module references.</p>
<h2 id="basic-usage">Basic usage</h2><pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">Link</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Simple string path</span></span>
<span class="line"><span style="color:#56B6C2">&#x3C;</span><span style="color:#E06C75">Link</span><span style="color:#E06C75"> to</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"/users"</span><span style="color:#56B6C2">></span><span style="color:#E06C75">Users</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">Link</span><span style="color:#56B6C2">></span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// With URL parameters</span></span>
<span class="line"><span style="color:#56B6C2">&#x3C;</span><span style="color:#E06C75">Link</span><span style="color:#E06C75"> to</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"/users/123"</span><span style="color:#56B6C2">></span><span style="color:#E06C75">View</span><span style="color:#E06C75"> User</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">Link</span><span style="color:#56B6C2">></span></span></code></pre><h2 id="module-references">Module references</h2><p>Instead of hardcoding paths, you can pass a route module directly. This way, if the path changes in <code>routes.tsx</code>, your links update automatically:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">Link</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> UserPage</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./users/UserDetail.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#D19A66"> *</span><span style="color:#C678DD"> as</span><span style="color:#E06C75"> LoginPage</span><span style="color:#C678DD"> from</span><span style="color:#98C379"> "./auth/Login.js"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Relative path (uses metadata.path — works within the current layout)</span></span>
<span class="line"><span style="color:#56B6C2">&#x3C;</span><span style="color:#E06C75">Link</span><span style="color:#E06C75"> to</span><span style="color:#56B6C2">=</span><span style="color:#ABB2BF">{</span><span style="color:#E06C75">UserPage</span><span style="color:#ABB2BF">} </span><span style="color:#E06C75">params</span><span style="color:#56B6C2">=</span><span style="color:#ABB2BF">{{ </span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"123"</span><span style="color:#ABB2BF"> }}</span><span style="color:#56B6C2">></span><span style="color:#E06C75">View</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">Link</span><span style="color:#56B6C2">></span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Absolute path (uses metadata.fullPath — navigates from the root)</span></span>
<span class="line"><span style="color:#56B6C2">&#x3C;</span><span style="color:#E06C75">Link</span><span style="color:#E06C75"> to</span><span style="color:#56B6C2">=</span><span style="color:#ABB2BF">{</span><span style="color:#E06C75">LoginPage</span><span style="color:#ABB2BF">} </span><span style="color:#E06C75">absolute</span><span style="color:#56B6C2">></span><span style="color:#E06C75">Login</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">Link</span><span style="color:#56B6C2">></span></span></code></pre><h2 id="parameters-and-query-strings">Parameters and query strings</h2><p>Use <code>params</code> to substitute <code>:param</code> placeholders in the path, and <code>search</code> to add query string parameters:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#56B6C2">&#x3C;</span><span style="color:#E06C75">Link</span><span style="color:#E06C75"> to</span><span style="color:#56B6C2">=</span><span style="color:#ABB2BF">{</span><span style="color:#E06C75">UserPage</span><span style="color:#ABB2BF">} </span><span style="color:#E06C75">params</span><span style="color:#56B6C2">=</span><span style="color:#ABB2BF">{{ </span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"123"</span><span style="color:#ABB2BF"> }} </span><span style="color:#E06C75">search</span><span style="color:#56B6C2">=</span><span style="color:#ABB2BF">{{ </span><span style="color:#E06C75">tab</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"settings"</span><span style="color:#ABB2BF"> }}</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#E06C75">    User</span><span style="color:#E06C75"> Settings</span></span>
<span class="line"><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">Link</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Renders: /users/123?tab=settings</span></span></code></pre><h2 id="the-prefix">The \`~/\` prefix</h2><p>VeloJS uses wouter-preact for client-side routing. When routes are nested (layouts wrapping children), wouter creates a <strong>nest context</strong> — relative paths resolve within the current layout&#39;s scope.</p>
<p>This is usually what you want. But sometimes you need to navigate to a completely different section of your app. That&#39;s where <code>~/</code> comes in:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// Inside a layout at /admin/users, these behave differently:</span></span>
<span class="line"></span>
<span class="line"><span style="color:#56B6C2">&#x3C;</span><span style="color:#E06C75">Link</span><span style="color:#E06C75"> to</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"/details"</span><span style="color:#56B6C2">></span><span style="color:#7F848E;font-style:italic">     // → /admin/users/details (relative to current layout)</span></span>
<span class="line"><span style="color:#56B6C2">&#x3C;</span><span style="color:#E06C75">Link</span><span style="color:#E06C75"> to</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"~/settings"</span><span style="color:#56B6C2">></span><span style="color:#7F848E;font-style:italic">   // → /settings (absolute, from the root)</span></span></code></pre><p><strong>When to use <code>~/</code></strong>: anytime you navigate to a route outside the current layout. In practice, most cross-section links (e.g., from admin to settings, from dashboard to billing) use <code>~/</code>.</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// Common pattern: cross-section navigation</span></span>
<span class="line"><span style="color:#56B6C2">&#x3C;</span><span style="color:#E06C75">Link</span><span style="color:#E06C75"> to</span><span style="color:#56B6C2">=</span><span style="color:#98C379">"~/stacks"</span><span style="color:#56B6C2">></span><span style="color:#E06C75">Stacks</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">Link</span><span style="color:#56B6C2">></span></span>
<span class="line"><span style="color:#56B6C2">&#x3C;</span><span style="color:#E06C75">Link</span><span style="color:#E06C75"> to</span><span style="color:#56B6C2">=</span><span style="color:#ABB2BF">{</span><span style="color:#98C379">\`~/stacks/apps/</span><span style="color:#C678DD">\${</span><span style="color:#E06C75">appId</span><span style="color:#C678DD">}</span><span style="color:#98C379">/edit\`</span><span style="color:#ABB2BF">}</span><span style="color:#56B6C2">></span><span style="color:#E06C75">Edit</span><span style="color:#E06C75"> App</span><span style="color:#56B6C2">&#x3C;/</span><span style="color:#E06C75">Link</span><span style="color:#56B6C2">></span></span></code></pre><h2 id="props-reference">Props reference</h2><table>
<thead>
<tr>
<th>Prop</th>
<th>Type</th>
<th>Description</th>
</tr>
</thead>
<tbody><tr>
<td><code>to</code></td>
<td><code>string | RouteModule</code></td>
<td>Destination path or module. Strings support <code>~/</code> prefix.</td>
</tr>
<tr>
<td><code>params</code></td>
<td><code>Record&lt;string, string&gt;</code></td>
<td>Substitutes <code>:param</code> placeholders in the path.</td>
</tr>
<tr>
<td><code>search</code></td>
<td><code>Record&lt;string, string&gt;</code></td>
<td>Appends query string parameters to the URL.</td>
</tr>
<tr>
<td><code>absolute</code></td>
<td><code>boolean</code></td>
<td>When using a module reference: use <code>fullPath</code> instead of <code>path</code>. Default: <code>false</code>.</td>
</tr>
</tbody></table>
`,rawMd:'# Link Component\n\nThe `Link` component handles navigation in VeloJS. It supports both simple string paths and type-safe module references.\n\n## Basic usage\n\n```typescript\nimport { Link } from "@mauroandre/velojs";\n\n// Simple string path\n<Link to="/users">Users</Link>\n\n// With URL parameters\n<Link to="/users/123">View User</Link>\n```\n\n## Module references\n\nInstead of hardcoding paths, you can pass a route module directly. This way, if the path changes in `routes.tsx`, your links update automatically:\n\n```typescript\nimport { Link } from "@mauroandre/velojs";\nimport * as UserPage from "./users/UserDetail.js";\nimport * as LoginPage from "./auth/Login.js";\n\n// Relative path (uses metadata.path — works within the current layout)\n<Link to={UserPage} params={{ id: "123" }}>View</Link>\n\n// Absolute path (uses metadata.fullPath — navigates from the root)\n<Link to={LoginPage} absolute>Login</Link>\n```\n\n## Parameters and query strings\n\nUse `params` to substitute `:param` placeholders in the path, and `search` to add query string parameters:\n\n```typescript\n<Link to={UserPage} params={{ id: "123" }} search={{ tab: "settings" }}>\n    User Settings\n</Link>\n// Renders: /users/123?tab=settings\n```\n\n## The `~/` prefix\n\nVeloJS uses wouter-preact for client-side routing. When routes are nested (layouts wrapping children), wouter creates a **nest context** — relative paths resolve within the current layout\'s scope.\n\nThis is usually what you want. But sometimes you need to navigate to a completely different section of your app. That\'s where `~/` comes in:\n\n```typescript\n// Inside a layout at /admin/users, these behave differently:\n\n<Link to="/details">     // → /admin/users/details (relative to current layout)\n<Link to="~/settings">   // → /settings (absolute, from the root)\n```\n\n**When to use `~/`**: anytime you navigate to a route outside the current layout. In practice, most cross-section links (e.g., from admin to settings, from dashboard to billing) use `~/`.\n\n```typescript\n// Common pattern: cross-section navigation\n<Link to="~/stacks">Stacks</Link>\n<Link to={`~/stacks/apps/${appId}/edit`}>Edit App</Link>\n```\n\n## Props reference\n\n| Prop | Type | Description |\n|------|------|-------------|\n| `to` | `string \\| RouteModule` | Destination path or module. Strings support `~/` prefix. |\n| `params` | `Record<string, string>` | Substitutes `:param` placeholders in the path. |\n| `search` | `Record<string, string>` | Appends query string parameters to the URL. |\n| `absolute` | `boolean` | When using a module reference: use `fullPath` instead of `path`. Default: `false`. |\n'},"scripts-component":{html:`<h1 id="scripts-component">Scripts Component</h1><p>The <code>Scripts</code> component injects the CSS and JavaScript files that your app needs. It must be placed inside <code>&lt;head&gt;</code> in your <code>client-root.tsx</code>.</p>
<h2 id="usage">Usage</h2><pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">Scripts</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> Component</span><span style="color:#56B6C2"> =</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">children</span><span style="color:#ABB2BF"> }) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> (</span></span>
<span class="line"><span style="color:#ABB2BF">    &#x3C;</span><span style="color:#E06C75">html</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">        &#x3C;</span><span style="color:#E06C75">head</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">            &#x3C;</span><span style="color:#E5C07B">Scripts</span><span style="color:#ABB2BF"> /></span></span>
<span class="line"><span style="color:#ABB2BF">        &#x3C;/</span><span style="color:#E06C75">head</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">        &#x3C;</span><span style="color:#E06C75">body</span><span style="color:#ABB2BF">></span><span style="color:#C678DD">{</span><span style="color:#E06C75">children</span><span style="color:#C678DD">}</span><span style="color:#ABB2BF">&#x3C;/</span><span style="color:#E06C75">body</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">    &#x3C;/</span><span style="color:#E06C75">html</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">);</span></span></code></pre><h2 id="what-it-outputs">What it outputs</h2><p><code>Scripts</code> automatically detects whether you&#39;re in development or production mode and outputs the appropriate tags.</p>
<p><strong>In development:</strong></p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E06C75">link</span><span style="color:#D19A66"> rel</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"icon"</span><span style="color:#D19A66"> href</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"/favicon.ico"</span><span style="color:#D19A66"> type</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"image/x-icon"</span><span style="color:#ABB2BF"> /></span></span>
<span class="line"><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E06C75">script</span><span style="color:#D19A66"> type</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"module"</span><span style="color:#D19A66"> src</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"/@vite/client"</span><span style="color:#ABB2BF">>&#x3C;/</span><span style="color:#E06C75">script</span><span style="color:#ABB2BF">></span></span>
<span class="line"><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E06C75">script</span><span style="color:#D19A66"> type</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"module"</span><span style="color:#D19A66"> src</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"/__velo_client.js"</span><span style="color:#ABB2BF">>&#x3C;/</span><span style="color:#E06C75">script</span><span style="color:#ABB2BF">></span></span></code></pre><p><strong>In production:</strong></p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E06C75">link</span><span style="color:#D19A66"> rel</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"icon"</span><span style="color:#D19A66"> href</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"/favicon.ico"</span><span style="color:#D19A66"> type</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"image/x-icon"</span><span style="color:#ABB2BF"> /></span></span>
<span class="line"><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E06C75">link</span><span style="color:#D19A66"> rel</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"stylesheet"</span><span style="color:#D19A66"> href</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"/client.css"</span><span style="color:#ABB2BF"> /></span></span>
<span class="line"><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E06C75">script</span><span style="color:#D19A66"> type</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"module"</span><span style="color:#D19A66"> src</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"/client.js"</span><span style="color:#ABB2BF">>&#x3C;/</span><span style="color:#E06C75">script</span><span style="color:#ABB2BF">></span></span></code></pre><h2 id="props">Props</h2><table>
<thead>
<tr>
<th>Prop</th>
<th>Type</th>
<th>Default</th>
<th>Description</th>
</tr>
</thead>
<tbody><tr>
<td><code>basePath</code></td>
<td><code>string</code></td>
<td><code>&quot;&quot;</code></td>
<td>Base path prefix for all asset URLs. Uses <code>STATIC_BASE_URL</code> env var if set.</td>
</tr>
<tr>
<td><code>favicon</code></td>
<td><code>string | false</code></td>
<td><code>&quot;/favicon.ico&quot;</code></td>
<td>Path to the favicon. Set to <code>false</code> to disable.</td>
</tr>
</tbody></table>
<h2 id="using-with-a-cdn">Using with a CDN</h2><p>If you serve static assets from a CDN or S3 bucket, set the <code>STATIC_BASE_URL</code> environment variable. The <code>Scripts</code> component will automatically prefix all asset URLs:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#E06C75">STATIC_BASE_URL</span><span style="color:#56B6C2">=</span><span style="color:#98C379">https://cdn.example.com/assets</span><span style="color:#61AFEF"> velojs</span><span style="color:#98C379"> start</span></span></code></pre><p>This makes the output become:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E06C75">link</span><span style="color:#D19A66"> rel</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"stylesheet"</span><span style="color:#D19A66"> href</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"https://cdn.example.com/assets/client.css"</span><span style="color:#ABB2BF"> /></span></span>
<span class="line"><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E06C75">script</span><span style="color:#D19A66"> type</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"module"</span><span style="color:#D19A66"> src</span><span style="color:#ABB2BF">=</span><span style="color:#98C379">"https://cdn.example.com/assets/client.js"</span><span style="color:#ABB2BF">>&#x3C;/</span><span style="color:#E06C75">script</span><span style="color:#ABB2BF">></span></span></code></pre>`,rawMd:'# Scripts Component\n\nThe `Scripts` component injects the CSS and JavaScript files that your app needs. It must be placed inside `<head>` in your `client-root.tsx`.\n\n## Usage\n\n```tsx\nimport { Scripts } from "@mauroandre/velojs";\n\nexport const Component = ({ children }) => (\n    <html>\n        <head>\n            <Scripts />\n        </head>\n        <body>{children}</body>\n    </html>\n);\n```\n\n## What it outputs\n\n`Scripts` automatically detects whether you\'re in development or production mode and outputs the appropriate tags.\n\n**In development:**\n```html\n<link rel="icon" href="/favicon.ico" type="image/x-icon" />\n<script type="module" src="/@vite/client"><\/script>\n<script type="module" src="/__velo_client.js"><\/script>\n```\n\n**In production:**\n```html\n<link rel="icon" href="/favicon.ico" type="image/x-icon" />\n<link rel="stylesheet" href="/client.css" />\n<script type="module" src="/client.js"><\/script>\n```\n\n## Props\n\n| Prop | Type | Default | Description |\n|------|------|---------|-------------|\n| `basePath` | `string` | `""` | Base path prefix for all asset URLs. Uses `STATIC_BASE_URL` env var if set. |\n| `favicon` | `string \\| false` | `"/favicon.ico"` | Path to the favicon. Set to `false` to disable. |\n\n## Using with a CDN\n\nIf you serve static assets from a CDN or S3 bucket, set the `STATIC_BASE_URL` environment variable. The `Scripts` component will automatically prefix all asset URLs:\n\n```bash\nSTATIC_BASE_URL=https://cdn.example.com/assets velojs start\n```\n\nThis makes the output become:\n```html\n<link rel="stylesheet" href="https://cdn.example.com/assets/client.css" />\n<script type="module" src="https://cdn.example.com/assets/client.js"><\/script>\n```\n'},middlewares:{html:`<h1 id="middlewares">Middlewares</h1><p>Middlewares are server-side functions that run before your loaders and actions. They&#39;re perfect for authentication, authorization, logging, and other cross-cutting concerns. The Vite plugin automatically removes them from the client bundle.</p>
<h2 id="creating-a-middleware">Creating a middleware</h2><p>Use <code>createMiddleware</code> from <code>@mauroandre/velojs/factory</code>. It wraps Hono&#39;s middleware API:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// app/modules/auth/auth.middleware.ts</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">createMiddleware</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/factory"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">getCookie</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/cookie"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#E5C07B"> authMiddleware</span><span style="color:#56B6C2"> =</span><span style="color:#61AFEF"> createMiddleware</span><span style="color:#ABB2BF">(</span><span style="color:#C678DD">async</span><span style="color:#ABB2BF"> (</span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75;font-style:italic">next</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#E5C07B"> token</span><span style="color:#56B6C2"> =</span><span style="color:#61AFEF"> getCookie</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">c</span><span style="color:#ABB2BF">, </span><span style="color:#98C379">"session"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">    if</span><span style="color:#ABB2BF"> (</span><span style="color:#56B6C2">!</span><span style="color:#E06C75">token</span><span style="color:#ABB2BF">) {</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">        // No token: redirect GET requests, return 401 for API calls</span></span>
<span class="line"><span style="color:#C678DD">        if</span><span style="color:#ABB2BF"> (</span><span style="color:#E5C07B">c</span><span style="color:#ABB2BF">.</span><span style="color:#E5C07B">req</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">method</span><span style="color:#56B6C2"> ===</span><span style="color:#98C379"> "GET"</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">return</span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">redirect</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/login"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">        return</span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">json</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">error</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"unauthorized"</span><span style="color:#ABB2BF"> }, </span><span style="color:#D19A66">401</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#ABB2BF">    }</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // Verify the token and attach user data to the context</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#E5C07B"> user</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> verifyToken</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">token</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#E5C07B">    c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">set</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"user"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">user</span><span style="color:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // Continue to the next middleware or handler</span></span>
<span class="line"><span style="color:#C678DD">    await</span><span style="color:#61AFEF"> next</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#ABB2BF">});</span></span></code></pre><h2 id="using-in-routes">Using in routes</h2><p>Add the <code>middlewares</code> property to any route node. All children of that node will inherit the middleware:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> default</span><span style="color:#ABB2BF"> [</span></span>
<span class="line"><span style="color:#ABB2BF">    {</span></span>
<span class="line"><span style="color:#E06C75">        module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Root</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        isRoot</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">        children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Public routes — no middleware</span></span>
<span class="line"><span style="color:#ABB2BF">            {</span></span>
<span class="line"><span style="color:#E06C75">                module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">AuthLayout</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/login"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Login</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                ],</span></span>
<span class="line"><span style="color:#ABB2BF">            },</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Protected routes — authMiddleware applies to everything below</span></span>
<span class="line"><span style="color:#ABB2BF">            {</span></span>
<span class="line"><span style="color:#E06C75">                module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">AdminLayout</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                middlewares</span><span style="color:#ABB2BF">: [</span><span style="color:#E06C75">authMiddleware</span><span style="color:#ABB2BF">],</span></span>
<span class="line"><span style="color:#E06C75">                children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Dashboard</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                    { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/stacks"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Stacks</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">                    // Admin-only routes — both middlewares apply</span></span>
<span class="line"><span style="color:#ABB2BF">                    {</span></span>
<span class="line"><span style="color:#E06C75">                        path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/master"</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                        module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">MasterLayout</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                        middlewares</span><span style="color:#ABB2BF">: [</span><span style="color:#E06C75">masterMiddleware</span><span style="color:#ABB2BF">],</span></span>
<span class="line"><span style="color:#E06C75">                        children</span><span style="color:#ABB2BF">: [</span></span>
<span class="line"><span style="color:#ABB2BF">                            { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/workers"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Workers</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                            { </span><span style="color:#E06C75">path</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"/settings"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">module</span><span style="color:#ABB2BF">: </span><span style="color:#E06C75">Settings</span><span style="color:#ABB2BF"> },</span></span>
<span class="line"><span style="color:#ABB2BF">                        ],</span></span>
<span class="line"><span style="color:#ABB2BF">                    },</span></span>
<span class="line"><span style="color:#ABB2BF">                ],</span></span>
<span class="line"><span style="color:#ABB2BF">            },</span></span>
<span class="line"><span style="color:#ABB2BF">        ],</span></span>
<span class="line"><span style="color:#ABB2BF">    },</span></span>
<span class="line"><span style="color:#ABB2BF">] </span><span style="color:#C678DD">satisfies</span><span style="color:#E5C07B"> AppRoutes</span><span style="color:#ABB2BF">;</span></span></code></pre><h2 id="inheritance">Inheritance</h2><p>Middlewares <strong>accumulate</strong> from parent to child. In the example above:</p>
<ul>
<li><code>/</code> and <code>/stacks</code> → only <code>authMiddleware</code> runs</li>
<li><code>/master/workers</code> and <code>/master/settings</code> → <code>authMiddleware</code> runs first, then <code>masterMiddleware</code></li>
</ul>
<p>This applies to both page loads (loaders) and action calls.</p>
<h2 id="sharing-data-between-middleware-and-handlers">Sharing data between middleware and handlers</h2><p>Use Hono&#39;s <code>c.set()</code> in the middleware and <code>c.get()</code> in your loaders and actions:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#7F848E;font-style:italic">// Middleware sets the user</span></span>
<span class="line"><span style="color:#E5C07B">c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">set</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"user"</span><span style="color:#ABB2BF">, { </span><span style="color:#E06C75">id</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"123"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">name</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"Mauro"</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">role</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"master"</span><span style="color:#ABB2BF"> });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Loader reads it</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> loader</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF"> }: </span><span style="color:#E5C07B">LoaderArgs</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#E5C07B"> user</span><span style="color:#56B6C2"> =</span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">get</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"user"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">greeting</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">\`Hello, </span><span style="color:#C678DD">\${</span><span style="color:#E5C07B">user</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">name</span><span style="color:#C678DD">}</span><span style="color:#98C379">\`</span><span style="color:#ABB2BF"> };</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">// Action reads it</span></span>
<span class="line"><span style="color:#C678DD">export</span><span style="color:#C678DD"> const</span><span style="color:#61AFEF"> action_save</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> async</span><span style="color:#ABB2BF"> ({ </span><span style="color:#E06C75;font-style:italic">body</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF"> }: </span><span style="color:#E5C07B">ActionArgs</span><span style="color:#ABB2BF">&#x3C;{ </span><span style="color:#E06C75">name</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF"> }>) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#E5C07B"> user</span><span style="color:#56B6C2"> =</span><span style="color:#E06C75"> c</span><span style="color:#56B6C2">!</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">get</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"user"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // user is available here</span></span>
<span class="line"><span style="color:#ABB2BF">};</span></span></code></pre><p>This is the recommended pattern for passing authentication data (current user, permissions, etc) from middleware to your page code.</p>
`,rawMd:`# Middlewares

Middlewares are server-side functions that run before your loaders and actions. They're perfect for authentication, authorization, logging, and other cross-cutting concerns. The Vite plugin automatically removes them from the client bundle.

## Creating a middleware

Use \`createMiddleware\` from \`@mauroandre/velojs/factory\`. It wraps Hono's middleware API:

\`\`\`typescript
// app/modules/auth/auth.middleware.ts
import { createMiddleware } from "@mauroandre/velojs/factory";
import { getCookie } from "@mauroandre/velojs/cookie";

export const authMiddleware = createMiddleware(async (c, next) => {
    const token = getCookie(c, "session");

    if (!token) {
        // No token: redirect GET requests, return 401 for API calls
        if (c.req.method === "GET") return c.redirect("/login");
        return c.json({ error: "unauthorized" }, 401);
    }

    // Verify the token and attach user data to the context
    const user = await verifyToken(token);
    c.set("user", user);

    // Continue to the next middleware or handler
    await next();
});
\`\`\`

## Using in routes

Add the \`middlewares\` property to any route node. All children of that node will inherit the middleware:

\`\`\`typescript
export default [
    {
        module: Root,
        isRoot: true,
        children: [
            // Public routes — no middleware
            {
                module: AuthLayout,
                children: [
                    { path: "/login", module: Login },
                ],
            },
            // Protected routes — authMiddleware applies to everything below
            {
                module: AdminLayout,
                middlewares: [authMiddleware],
                children: [
                    { path: "/", module: Dashboard },
                    { path: "/stacks", module: Stacks },

                    // Admin-only routes — both middlewares apply
                    {
                        path: "/master",
                        module: MasterLayout,
                        middlewares: [masterMiddleware],
                        children: [
                            { path: "/workers", module: Workers },
                            { path: "/settings", module: Settings },
                        ],
                    },
                ],
            },
        ],
    },
] satisfies AppRoutes;
\`\`\`

## Inheritance

Middlewares **accumulate** from parent to child. In the example above:

- \`/\` and \`/stacks\` → only \`authMiddleware\` runs
- \`/master/workers\` and \`/master/settings\` → \`authMiddleware\` runs first, then \`masterMiddleware\`

This applies to both page loads (loaders) and action calls.

## Sharing data between middleware and handlers

Use Hono's \`c.set()\` in the middleware and \`c.get()\` in your loaders and actions:

\`\`\`typescript
// Middleware sets the user
c.set("user", { id: "123", name: "Mauro", role: "master" });

// Loader reads it
export const loader = async ({ c }: LoaderArgs) => {
    const user = c.get("user");
    return { greeting: \`Hello, \${user.name}\` };
};

// Action reads it
export const action_save = async ({ body, c }: ActionArgs<{ name: string }>) => {
    const user = c!.get("user");
    // user is available here
};
\`\`\`

This is the recommended pattern for passing authentication data (current user, permissions, etc) from middleware to your page code.
`},"server-api":{html:`<h1 id="server-api">Server API</h1><p>VeloJS gives you direct access to the underlying Hono server. This lets you add custom API endpoints, SSE streams, WebSocket handlers, and anything else that goes beyond page routes.</p>
<h2 id="addroutes">addRoutes</h2><p>Register custom Hono routes in <code>app/server.tsx</code>. These routes are added <strong>before</strong> page and action routes, so they take priority:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">addRoutes</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/server"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">import</span><span style="color:#C678DD"> type</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">Hono</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "hono"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#61AFEF">addRoutes</span><span style="color:#ABB2BF">((</span><span style="color:#E06C75;font-style:italic">app</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">Hono</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // Simple API endpoint</span></span>
<span class="line"><span style="color:#E5C07B">    app</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">get</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/api/health"</span><span style="color:#ABB2BF">, (</span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">json</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">ok</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF"> }));</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // File upload</span></span>
<span class="line"><span style="color:#E5C07B">    app</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">post</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/api/upload"</span><span style="color:#ABB2BF">, </span><span style="color:#C678DD">async</span><span style="color:#ABB2BF"> (</span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">        const</span><span style="color:#E5C07B"> body</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> await</span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#E5C07B">req</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">parseBody</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#C678DD">        const</span><span style="color:#E5C07B"> file</span><span style="color:#56B6C2"> =</span><span style="color:#E5C07B"> body</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">file</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#C678DD">        return</span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">json</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">ok</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF"> });</span></span>
<span class="line"><span style="color:#ABB2BF">    });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">    // Middleware for a group of API routes</span></span>
<span class="line"><span style="color:#E5C07B">    app</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">use</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/api/admin/*"</span><span style="color:#ABB2BF">, </span><span style="color:#C678DD">async</span><span style="color:#ABB2BF"> (</span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75;font-style:italic">next</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">        const</span><span style="color:#E5C07B"> token</span><span style="color:#56B6C2"> =</span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#E5C07B">req</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">header</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"Authorization"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">        if</span><span style="color:#ABB2BF"> (</span><span style="color:#56B6C2">!</span><span style="color:#E06C75">token</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">return</span><span style="color:#E5C07B"> c</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">json</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">error</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"Unauthorized"</span><span style="color:#ABB2BF"> }, </span><span style="color:#D19A66">401</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">        await</span><span style="color:#61AFEF"> next</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#ABB2BF">    });</span></span>
<span class="line"><span style="color:#ABB2BF">});</span></span></code></pre><h2 id="server-sent-events-sse">Server-Sent Events (SSE)</h2><p>SSE is a simple way to push real-time updates from server to client. Use Hono&#39;s <code>streamSSE</code>:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">addRoutes</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/server"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#61AFEF">addRoutes</span><span style="color:#ABB2BF">((</span><span style="color:#E06C75;font-style:italic">app</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E5C07B">    app</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">get</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/api/events"</span><span style="color:#ABB2BF">, </span><span style="color:#C678DD">async</span><span style="color:#ABB2BF"> (</span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">        const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">streamSSE</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> import</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"hono/streaming"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">        return</span><span style="color:#61AFEF"> streamSSE</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">c</span><span style="color:#ABB2BF">, </span><span style="color:#C678DD">async</span><span style="color:#ABB2BF"> (</span><span style="color:#E06C75;font-style:italic">stream</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Send initial data when client connects</span></span>
<span class="line"><span style="color:#C678DD">            await</span><span style="color:#E5C07B"> stream</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">writeSSE</span><span style="color:#ABB2BF">({</span></span>
<span class="line"><span style="color:#E06C75">                event</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"snapshot"</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                data</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">JSON</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">stringify</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">count</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">0</span><span style="color:#ABB2BF"> }),</span></span>
<span class="line"><span style="color:#ABB2BF">            });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Subscribe to updates</span></span>
<span class="line"><span style="color:#C678DD">            const</span><span style="color:#E5C07B"> unsubscribe</span><span style="color:#56B6C2"> =</span><span style="color:#61AFEF"> subscribe</span><span style="color:#ABB2BF">((</span><span style="color:#E06C75;font-style:italic">data</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E5C07B">                stream</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">writeSSE</span><span style="color:#ABB2BF">({</span></span>
<span class="line"><span style="color:#E06C75">                    event</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">"update"</span><span style="color:#ABB2BF">,</span></span>
<span class="line"><span style="color:#E06C75">                    data</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">JSON</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">stringify</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">data</span><span style="color:#ABB2BF">),</span></span>
<span class="line"><span style="color:#ABB2BF">                });</span></span>
<span class="line"><span style="color:#ABB2BF">            });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Clean up when client disconnects</span></span>
<span class="line"><span style="color:#E5C07B">            stream</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">onAbort</span><span style="color:#ABB2BF">(() </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> { </span><span style="color:#61AFEF">unsubscribe</span><span style="color:#ABB2BF">(); });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#7F848E;font-style:italic">            // Keep the stream open</span></span>
<span class="line"><span style="color:#C678DD">            await</span><span style="color:#C678DD"> new</span><span style="color:#E5C07B"> Promise</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">void</span><span style="color:#ABB2BF">>(() </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {});</span></span>
<span class="line"><span style="color:#ABB2BF">        });</span></span>
<span class="line"><span style="color:#ABB2BF">    });</span></span>
<span class="line"><span style="color:#ABB2BF">});</span></span></code></pre><p>On the client, use the standard <code>EventSource</code> API:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#61AFEF">useEffect</span><span style="color:#ABB2BF">(() </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#E5C07B"> es</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> new</span><span style="color:#61AFEF"> EventSource</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/api/events"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="color:#E5C07B">    es</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">addEventListener</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"snapshot"</span><span style="color:#ABB2BF">, (</span><span style="color:#E06C75;font-style:italic">e</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E5C07B">        state</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">value</span><span style="color:#56B6C2"> =</span><span style="color:#E5C07B"> JSON</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">parse</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">e</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">data</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#ABB2BF">    });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#E5C07B">    es</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">addEventListener</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"update"</span><span style="color:#ABB2BF">, (</span><span style="color:#E06C75;font-style:italic">e</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E5C07B">        state</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">value</span><span style="color:#56B6C2"> =</span><span style="color:#E5C07B"> JSON</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">parse</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">e</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">data</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#ABB2BF">    });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">    return</span><span style="color:#ABB2BF"> () </span><span style="color:#C678DD">=></span><span style="color:#E5C07B"> es</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">close</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#ABB2BF">}, []);</span></span></code></pre><h3 id="sse-with-polling">SSE with polling</h3><p>For live metrics or periodic updates, use a polling loop inside the stream:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#61AFEF">addRoutes</span><span style="color:#ABB2BF">((</span><span style="color:#E06C75;font-style:italic">app</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E5C07B">    app</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">get</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"/api/metrics/live"</span><span style="color:#ABB2BF">, </span><span style="color:#C678DD">async</span><span style="color:#ABB2BF"> (</span><span style="color:#E06C75;font-style:italic">c</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">        const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">streamSSE</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> import</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"hono/streaming"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">        return</span><span style="color:#61AFEF"> streamSSE</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">c</span><span style="color:#ABB2BF">, </span><span style="color:#C678DD">async</span><span style="color:#ABB2BF"> (</span><span style="color:#E06C75;font-style:italic">stream</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">            let</span><span style="color:#E06C75"> running</span><span style="color:#56B6C2"> =</span><span style="color:#D19A66"> true</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#E5C07B">            stream</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">onAbort</span><span style="color:#ABB2BF">(() </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">running</span><span style="color:#56B6C2"> =</span><span style="color:#D19A66"> false</span><span style="color:#ABB2BF">; });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">            while</span><span style="color:#ABB2BF"> (</span><span style="color:#E06C75">running</span><span style="color:#ABB2BF">) {</span></span>
<span class="line"><span style="color:#C678DD">                const</span><span style="color:#E5C07B"> metrics</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> collectMetrics</span><span style="color:#ABB2BF">();</span></span>
<span class="line"><span style="color:#C678DD">                await</span><span style="color:#E5C07B"> stream</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">writeSSE</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">data</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">JSON</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">stringify</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">metrics</span><span style="color:#ABB2BF">) });</span></span>
<span class="line"><span style="color:#C678DD">                await</span><span style="color:#C678DD"> new</span><span style="color:#E5C07B"> Promise</span><span style="color:#ABB2BF">((</span><span style="color:#E06C75;font-style:italic">r</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#61AFEF"> setTimeout</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">r</span><span style="color:#ABB2BF">, </span><span style="color:#D19A66">3000</span><span style="color:#ABB2BF">));</span></span>
<span class="line"><span style="color:#ABB2BF">            }</span></span>
<span class="line"><span style="color:#ABB2BF">        });</span></span>
<span class="line"><span style="color:#ABB2BF">    });</span></span>
<span class="line"><span style="color:#ABB2BF">});</span></span></code></pre><h2 id="onserver-websocket-support">onServer — WebSocket support</h2><p><code>onServer</code> gives you access to the underlying Node.js HTTP server. This is mainly used for WebSocket upgrade handlers:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">import</span><span style="color:#ABB2BF"> { </span><span style="color:#E06C75">onServer</span><span style="color:#ABB2BF"> } </span><span style="color:#C678DD">from</span><span style="color:#98C379"> "@mauroandre/velojs/server"</span><span style="color:#ABB2BF">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#61AFEF">onServer</span><span style="color:#ABB2BF">(</span><span style="color:#C678DD">async</span><span style="color:#ABB2BF"> (</span><span style="color:#E06C75;font-style:italic">httpServer</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#ABB2BF"> { </span><span style="color:#E5C07B">WebSocketServer</span><span style="color:#ABB2BF"> } </span><span style="color:#56B6C2">=</span><span style="color:#C678DD"> await</span><span style="color:#61AFEF"> import</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"ws"</span><span style="color:#ABB2BF">);</span></span>
<span class="line"><span style="color:#C678DD">    const</span><span style="color:#E5C07B"> wss</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> new</span><span style="color:#61AFEF"> WebSocketServer</span><span style="color:#ABB2BF">({ </span><span style="color:#E06C75">noServer</span><span style="color:#ABB2BF">: </span><span style="color:#D19A66">true</span><span style="color:#ABB2BF"> });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#E5C07B">    httpServer</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">on</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"upgrade"</span><span style="color:#ABB2BF">, (</span><span style="color:#E06C75;font-style:italic">req</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75;font-style:italic">socket</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75;font-style:italic">head</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">        const</span><span style="color:#E5C07B"> url</span><span style="color:#56B6C2"> =</span><span style="color:#C678DD"> new</span><span style="color:#61AFEF"> URL</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">req</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">url</span><span style="color:#56B6C2">!</span><span style="color:#ABB2BF">, </span><span style="color:#98C379">\`http://</span><span style="color:#C678DD">\${</span><span style="color:#E5C07B">req</span><span style="color:#ABB2BF">.</span><span style="color:#E5C07B">headers</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">host</span><span style="color:#C678DD">}</span><span style="color:#98C379">\`</span><span style="color:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="color:#C678DD">        if</span><span style="color:#ABB2BF"> (</span><span style="color:#E5C07B">url</span><span style="color:#ABB2BF">.</span><span style="color:#E06C75">pathname</span><span style="color:#56B6C2"> ===</span><span style="color:#98C379"> "/ws"</span><span style="color:#ABB2BF">) {</span></span>
<span class="line"><span style="color:#E5C07B">            wss</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">handleUpgrade</span><span style="color:#ABB2BF">(</span><span style="color:#E06C75">req</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">socket</span><span style="color:#ABB2BF">, </span><span style="color:#E06C75">head</span><span style="color:#ABB2BF">, (</span><span style="color:#E06C75;font-style:italic">ws</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E5C07B">                ws</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">on</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"message"</span><span style="color:#ABB2BF">, (</span><span style="color:#E06C75;font-style:italic">raw</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#C678DD">                    const</span><span style="color:#E5C07B"> msg</span><span style="color:#56B6C2"> =</span><span style="color:#E5C07B"> JSON</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">parse</span><span style="color:#ABB2BF">(</span><span style="color:#E5C07B">raw</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">toString</span><span style="color:#ABB2BF">());</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">                    // Handle message</span></span>
<span class="line"><span style="color:#ABB2BF">                });</span></span>
<span class="line"></span>
<span class="line"><span style="color:#E5C07B">                ws</span><span style="color:#ABB2BF">.</span><span style="color:#61AFEF">on</span><span style="color:#ABB2BF">(</span><span style="color:#98C379">"close"</span><span style="color:#ABB2BF">, () </span><span style="color:#C678DD">=></span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic">                    // Clean up</span></span>
<span class="line"><span style="color:#ABB2BF">                });</span></span>
<span class="line"><span style="color:#ABB2BF">            });</span></span>
<span class="line"><span style="color:#ABB2BF">        }</span></span>
<span class="line"><span style="color:#ABB2BF">    });</span></span>
<span class="line"><span style="color:#ABB2BF">});</span></span></code></pre><p>Callbacks registered with <code>onServer</code> queue until the server starts. If called after the server is already running, the callback executes immediately.</p>
<h2 id="environment-variables">Environment variables</h2><table>
<thead>
<tr>
<th>Variable</th>
<th>Default</th>
<th>Description</th>
</tr>
</thead>
<tbody><tr>
<td><code>SERVER_PORT</code></td>
<td><code>3000</code></td>
<td>The port the server listens on</td>
</tr>
<tr>
<td><code>NODE_ENV</code></td>
<td>—</td>
<td>Set automatically by <code>velojs start</code> to <code>production</code></td>
</tr>
<tr>
<td><code>STATIC_BASE_URL</code></td>
<td><code>&quot;&quot;</code></td>
<td>CDN/bucket prefix for static assets</td>
</tr>
</tbody></table>
`,rawMd:`# Server API

VeloJS gives you direct access to the underlying Hono server. This lets you add custom API endpoints, SSE streams, WebSocket handlers, and anything else that goes beyond page routes.

## addRoutes

Register custom Hono routes in \`app/server.tsx\`. These routes are added **before** page and action routes, so they take priority:

\`\`\`typescript
import { addRoutes } from "@mauroandre/velojs/server";
import type { Hono } from "hono";

addRoutes((app: Hono) => {
    // Simple API endpoint
    app.get("/api/health", (c) => c.json({ ok: true }));

    // File upload
    app.post("/api/upload", async (c) => {
        const body = await c.req.parseBody();
        const file = body.file;
        return c.json({ ok: true });
    });

    // Middleware for a group of API routes
    app.use("/api/admin/*", async (c, next) => {
        const token = c.req.header("Authorization");
        if (!token) return c.json({ error: "Unauthorized" }, 401);
        await next();
    });
});
\`\`\`

## Server-Sent Events (SSE)

SSE is a simple way to push real-time updates from server to client. Use Hono's \`streamSSE\`:

\`\`\`typescript
import { addRoutes } from "@mauroandre/velojs/server";

addRoutes((app) => {
    app.get("/api/events", async (c) => {
        const { streamSSE } = await import("hono/streaming");

        return streamSSE(c, async (stream) => {
            // Send initial data when client connects
            await stream.writeSSE({
                event: "snapshot",
                data: JSON.stringify({ count: 0 }),
            });

            // Subscribe to updates
            const unsubscribe = subscribe((data) => {
                stream.writeSSE({
                    event: "update",
                    data: JSON.stringify(data),
                });
            });

            // Clean up when client disconnects
            stream.onAbort(() => { unsubscribe(); });

            // Keep the stream open
            await new Promise<void>(() => {});
        });
    });
});
\`\`\`

On the client, use the standard \`EventSource\` API:

\`\`\`typescript
useEffect(() => {
    const es = new EventSource("/api/events");

    es.addEventListener("snapshot", (e) => {
        state.value = JSON.parse(e.data);
    });

    es.addEventListener("update", (e) => {
        state.value = JSON.parse(e.data);
    });

    return () => es.close();
}, []);
\`\`\`

### SSE with polling

For live metrics or periodic updates, use a polling loop inside the stream:

\`\`\`typescript
addRoutes((app) => {
    app.get("/api/metrics/live", async (c) => {
        const { streamSSE } = await import("hono/streaming");

        return streamSSE(c, async (stream) => {
            let running = true;
            stream.onAbort(() => { running = false; });

            while (running) {
                const metrics = await collectMetrics();
                await stream.writeSSE({ data: JSON.stringify(metrics) });
                await new Promise((r) => setTimeout(r, 3000));
            }
        });
    });
});
\`\`\`

## onServer — WebSocket support

\`onServer\` gives you access to the underlying Node.js HTTP server. This is mainly used for WebSocket upgrade handlers:

\`\`\`typescript
import { onServer } from "@mauroandre/velojs/server";

onServer(async (httpServer) => {
    const { WebSocketServer } = await import("ws");
    const wss = new WebSocketServer({ noServer: true });

    httpServer.on("upgrade", (req, socket, head) => {
        const url = new URL(req.url!, \`http://\${req.headers.host}\`);

        if (url.pathname === "/ws") {
            wss.handleUpgrade(req, socket, head, (ws) => {
                ws.on("message", (raw) => {
                    const msg = JSON.parse(raw.toString());
                    // Handle message
                });

                ws.on("close", () => {
                    // Clean up
                });
            });
        }
    });
});
\`\`\`

Callbacks registered with \`onServer\` queue until the server starts. If called after the server is already running, the callback executes immediately.

## Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| \`SERVER_PORT\` | \`3000\` | The port the server listens on |
| \`NODE_ENV\` | — | Set automatically by \`velojs start\` to \`production\` |
| \`STATIC_BASE_URL\` | \`""\` | CDN/bucket prefix for static assets |
`},"vite-plugin":{html:`<h1 id="vite-plugin">Vite Plugin</h1><p>The <code>veloPlugin()</code> is the core of VeloJS. It&#39;s a single function that returns 6 Vite plugins working together to handle routing, SSR, code transforms, and more.</p>
<h2 id="the-6-plugins">The 6 plugins</h2><table>
<thead>
<tr>
<th>Plugin</th>
<th>What it does</th>
</tr>
</thead>
<tbody><tr>
<td><code>velo:config</code></td>
<td>Sets up build config for client/server modes, Preact aliases, and environment defines</td>
</tr>
<tr>
<td><code>velo:transform</code></td>
<td>Performs AST transforms on your code (the most important plugin)</td>
</tr>
<tr>
<td><code>velo:static-url</code></td>
<td>Rewrites CSS <code>url(/path)</code> to use <code>STATIC_BASE_URL</code> in production builds</td>
</tr>
<tr>
<td><code>@preact/preset-vite</code></td>
<td>Adds Preact JSX support</td>
</tr>
<tr>
<td><code>@hono/vite-dev-server</code></td>
<td>Runs the SSR dev server</td>
</tr>
<tr>
<td><code>velo:ws-bridge</code></td>
<td>Exposes Vite&#39;s HTTP server for WebSocket handlers during development</td>
</tr>
</tbody></table>
<h2 id="ast-transformations">AST Transformations</h2><p>The <code>velo:transform</code> plugin uses Babel to modify your code at build time. It applies 5 transformations to files inside your <code>appDirectory</code>:</p>
<table>
<thead>
<tr>
<th>#</th>
<th>Transform</th>
<th>When</th>
<th>What it does</th>
</tr>
</thead>
<tbody><tr>
<td>1</td>
<td>Inject metadata</td>
<td>Server + Client</td>
<td>Adds <code>export const metadata = { moduleId, fullPath, path }</code> to each module</td>
</tr>
<tr>
<td>2</td>
<td>Transform loader functions</td>
<td>Server + Client</td>
<td>Injects moduleId into <code>useLoader()</code> and <code>Loader()</code> calls so they know which data to read</td>
</tr>
<tr>
<td>3</td>
<td>Transform actions for client</td>
<td>Client only</td>
<td>Replaces action function bodies with <code>fetch()</code> stubs (the RPC mechanism)</td>
</tr>
<tr>
<td>4</td>
<td>Remove loaders</td>
<td>Client only</td>
<td>Strips <code>export const loader</code> entirely from the client bundle</td>
</tr>
<tr>
<td>5</td>
<td>Remove middlewares</td>
<td>Client only</td>
<td>Strips <code>middlewares: [...]</code> and their imports from the client bundle</td>
</tr>
</tbody></table>
<p>These transforms are why VeloJS can provide such a seamless developer experience — you write one file, and the framework generates the right code for server and client automatically.</p>
<h2 id="build-process">Build process</h2><p>When you run <code>velojs build</code>, two Vite builds happen in sequence:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#61AFEF">velojs</span><span style="color:#98C379"> build</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic"># 1. vite build              → dist/client/ (client.js, client.css)</span></span>
<span class="line"><span style="color:#7F848E;font-style:italic"># 2. vite build --mode server → dist/server.js</span></span></code></pre><p>The first build creates the client bundle (JavaScript, CSS, and assets). The second build creates the server entry point that handles SSR and API routes.</p>
<h2 id="virtual-modules">Virtual modules</h2><p>VeloJS uses Vite virtual modules to generate the server and client entry points automatically:</p>
<table>
<thead>
<tr>
<th>Module</th>
<th>Purpose</th>
</tr>
</thead>
<tbody><tr>
<td><code>virtual:velo/server-entry</code></td>
<td>Imports your <code>server.tsx</code> + routes, calls <code>startServer()</code></td>
</tr>
<tr>
<td><code>virtual:velo/client-entry</code></td>
<td>Imports your <code>client.tsx</code> + routes, calls <code>startClient()</code></td>
</tr>
<tr>
<td><code>/__velo_client.js</code></td>
<td>Alias for the client entry (used in dev mode)</td>
</tr>
</tbody></table>
<p>You never import these directly — they&#39;re generated by the plugin.</p>
<h2 id="hot-reload">Hot reload</h2><p>When you edit <code>routes.tsx</code>, the plugin detects the change, rebuilds the path map, and triggers a full page reload. Other file changes use Vite&#39;s standard HMR (hot module replacement).</p>
<h2 id="request-isolation">Request isolation</h2><p>VeloJS uses Node&#39;s <code>AsyncLocalStorage</code> to isolate data per request. Each SSR render runs in its own storage context, so concurrent requests never leak data between each other.</p>
<p>This is why hooks like <code>useParams()</code>, <code>useQuery()</code>, and <code>Loader()</code> work correctly on the server — they read from the current request&#39;s storage, not from a global variable.</p>
`,rawMd:"# Vite Plugin\n\nThe `veloPlugin()` is the core of VeloJS. It's a single function that returns 6 Vite plugins working together to handle routing, SSR, code transforms, and more.\n\n## The 6 plugins\n\n| Plugin | What it does |\n|--------|-------------|\n| `velo:config` | Sets up build config for client/server modes, Preact aliases, and environment defines |\n| `velo:transform` | Performs AST transforms on your code (the most important plugin) |\n| `velo:static-url` | Rewrites CSS `url(/path)` to use `STATIC_BASE_URL` in production builds |\n| `@preact/preset-vite` | Adds Preact JSX support |\n| `@hono/vite-dev-server` | Runs the SSR dev server |\n| `velo:ws-bridge` | Exposes Vite's HTTP server for WebSocket handlers during development |\n\n## AST Transformations\n\nThe `velo:transform` plugin uses Babel to modify your code at build time. It applies 5 transformations to files inside your `appDirectory`:\n\n| # | Transform | When | What it does |\n|---|-----------|------|-------------|\n| 1 | Inject metadata | Server + Client | Adds `export const metadata = { moduleId, fullPath, path }` to each module |\n| 2 | Transform loader functions | Server + Client | Injects moduleId into `useLoader()` and `Loader()` calls so they know which data to read |\n| 3 | Transform actions for client | Client only | Replaces action function bodies with `fetch()` stubs (the RPC mechanism) |\n| 4 | Remove loaders | Client only | Strips `export const loader` entirely from the client bundle |\n| 5 | Remove middlewares | Client only | Strips `middlewares: [...]` and their imports from the client bundle |\n\nThese transforms are why VeloJS can provide such a seamless developer experience — you write one file, and the framework generates the right code for server and client automatically.\n\n## Build process\n\nWhen you run `velojs build`, two Vite builds happen in sequence:\n\n```bash\nvelojs build\n# 1. vite build              → dist/client/ (client.js, client.css)\n# 2. vite build --mode server → dist/server.js\n```\n\nThe first build creates the client bundle (JavaScript, CSS, and assets). The second build creates the server entry point that handles SSR and API routes.\n\n## Virtual modules\n\nVeloJS uses Vite virtual modules to generate the server and client entry points automatically:\n\n| Module | Purpose |\n|--------|---------|\n| `virtual:velo/server-entry` | Imports your `server.tsx` + routes, calls `startServer()` |\n| `virtual:velo/client-entry` | Imports your `client.tsx` + routes, calls `startClient()` |\n| `/__velo_client.js` | Alias for the client entry (used in dev mode) |\n\nYou never import these directly — they're generated by the plugin.\n\n## Hot reload\n\nWhen you edit `routes.tsx`, the plugin detects the change, rebuilds the path map, and triggers a full page reload. Other file changes use Vite's standard HMR (hot module replacement).\n\n## Request isolation\n\nVeloJS uses Node's `AsyncLocalStorage` to isolate data per request. Each SSR render runs in its own storage context, so concurrent requests never leak data between each other.\n\nThis is why hooks like `useParams()`, `useQuery()`, and `Loader()` work correctly on the server — they read from the current request's storage, not from a global variable.\n"},"type-reference":{html:`<h1 id="type-reference">Type Reference</h1><p>This page lists all the TypeScript types and interfaces exported by VeloJS, organized by import path.</p>
<h2 id="subpath-exports">Subpath exports</h2><table>
<thead>
<tr>
<th>Import</th>
<th>What you get</th>
</tr>
</thead>
<tbody><tr>
<td><code>@mauroandre/velojs</code></td>
<td>Types (<code>AppRoutes</code>, <code>ActionArgs</code>, <code>LoaderArgs</code>, <code>Metadata</code>), <code>Scripts</code>, <code>Link</code>, <code>defineConfig</code></td>
</tr>
<tr>
<td><code>@mauroandre/velojs/server</code></td>
<td><code>startServer</code>, <code>createApp</code>, <code>addRoutes</code>, <code>onServer</code>, <code>serverDataStorage</code></td>
</tr>
<tr>
<td><code>@mauroandre/velojs/client</code></td>
<td><code>startClient</code></td>
</tr>
<tr>
<td><code>@mauroandre/velojs/hooks</code></td>
<td><code>Loader</code>, <code>useLoader</code>, <code>useParams</code>, <code>useQuery</code>, <code>useNavigate</code>, <code>usePathname</code>, <code>touch</code></td>
</tr>
<tr>
<td><code>@mauroandre/velojs/cookie</code></td>
<td><code>getCookie</code>, <code>setCookie</code>, <code>deleteCookie</code>, <code>getSignedCookie</code>, <code>setSignedCookie</code></td>
</tr>
<tr>
<td><code>@mauroandre/velojs/factory</code></td>
<td><code>createMiddleware</code>, <code>createFactory</code></td>
</tr>
<tr>
<td><code>@mauroandre/velojs/vite</code></td>
<td><code>veloPlugin</code></td>
</tr>
<tr>
<td><code>@mauroandre/velojs/config</code></td>
<td><code>defineConfig</code>, <code>VeloConfig</code></td>
</tr>
</tbody></table>
<h2 id="interfaces">Interfaces</h2><h3 id="loaderargs">LoaderArgs</h3><p>Passed to every <code>loader</code> function. Contains the URL parameters, query string, and Hono context:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">interface</span><span style="color:#E5C07B"> LoaderArgs</span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E06C75">    params</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">Record</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">, </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">>;  </span><span style="color:#7F848E;font-style:italic">// URL params like :id</span></span>
<span class="line"><span style="color:#E06C75">    query</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">Record</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">, </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">>;   </span><span style="color:#7F848E;font-style:italic">// Query string like ?page=2</span></span>
<span class="line"><span style="color:#E06C75">    c</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">Context</span><span style="color:#ABB2BF">;                      </span><span style="color:#7F848E;font-style:italic">// Hono request context</span></span>
<span class="line"><span style="color:#ABB2BF">}</span></span></code></pre><h3 id="actionargs">ActionArgs</h3><p>Passed to every <code>action_*</code> function. The generic type <code>TBody</code> defines the shape of the data sent from the client:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">interface</span><span style="color:#E5C07B"> ActionArgs</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">TBody</span><span style="color:#56B6C2"> =</span><span style="color:#E5C07B"> unknown</span><span style="color:#ABB2BF">> {</span></span>
<span class="line"><span style="color:#E06C75">    body</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">TBody</span><span style="color:#ABB2BF">;                          </span><span style="color:#7F848E;font-style:italic">// Data from the client</span></span>
<span class="line"><span style="color:#E06C75">    params</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">Record</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">, </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">>;      </span><span style="color:#7F848E;font-style:italic">// URL params (server only)</span></span>
<span class="line"><span style="color:#E06C75">    query</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">Record</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">, </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">>;       </span><span style="color:#7F848E;font-style:italic">// Query string (server only)</span></span>
<span class="line"><span style="color:#E06C75">    c</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">Context</span><span style="color:#ABB2BF">;                          </span><span style="color:#7F848E;font-style:italic">// Hono context (server only)</span></span>
<span class="line"><span style="color:#ABB2BF">}</span></span></code></pre><h3 id="metadata">Metadata</h3><p>Automatically injected into each module by the Vite plugin. Contains the module identifier and resolved paths:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">interface</span><span style="color:#E5C07B"> Metadata</span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E06C75">    moduleId</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">;    </span><span style="color:#7F848E;font-style:italic">// e.g., "admin/Users"</span></span>
<span class="line"><span style="color:#E06C75">    fullPath</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">;   </span><span style="color:#7F848E;font-style:italic">// e.g., "/admin/users"</span></span>
<span class="line"><span style="color:#E06C75">    path</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">;       </span><span style="color:#7F848E;font-style:italic">// e.g., "/users"</span></span>
<span class="line"><span style="color:#ABB2BF">}</span></span></code></pre><h3 id="routemodule">RouteModule</h3><p>The shape of a route module (what <code>import * as Module</code> gives you):</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">interface</span><span style="color:#E5C07B"> RouteModule</span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E06C75">    Component</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">ComponentType</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">any</span><span style="color:#ABB2BF">>;</span></span>
<span class="line"><span style="color:#61AFEF">    loader</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: (</span><span style="color:#E06C75;font-style:italic">args</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">LoaderArgs</span><span style="color:#ABB2BF">) </span><span style="color:#C678DD">=></span><span style="color:#E5C07B"> Promise</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">any</span><span style="color:#ABB2BF">>;</span></span>
<span class="line"><span style="color:#E06C75">    metadata</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">Metadata</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#ABB2BF">    [</span><span style="color:#E06C75;font-style:italic">key</span><span style="color:#ABB2BF">: </span><span style="color:#98C379">\`action_</span><span style="color:#C678DD">\${</span><span style="color:#E5C07B">string</span><span style="color:#C678DD">}</span><span style="color:#98C379">\`</span><span style="color:#ABB2BF">]: (</span><span style="color:#E06C75;font-style:italic">args</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">ActionArgs</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">any</span><span style="color:#ABB2BF">>) </span><span style="color:#C678DD">=></span><span style="color:#E5C07B"> Promise</span><span style="color:#ABB2BF">&#x3C;</span><span style="color:#E5C07B">any</span><span style="color:#ABB2BF">>;</span></span>
<span class="line"><span style="color:#ABB2BF">}</span></span></code></pre><h3 id="routenode">RouteNode</h3><p>A single node in the route tree defined in <code>routes.tsx</code>:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">interface</span><span style="color:#E5C07B"> RouteNode</span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E06C75">    path</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#E06C75">    module</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">RouteModule</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#E06C75">    children</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">RouteNode</span><span style="color:#ABB2BF">[];</span></span>
<span class="line"><span style="color:#E06C75">    middlewares</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">MiddlewareHandler</span><span style="color:#ABB2BF">[];</span></span>
<span class="line"><span style="color:#E06C75">    isRoot</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">boolean</span><span style="color:#ABB2BF">;</span></span>
<span class="line"><span style="color:#ABB2BF">}</span></span></code></pre><h3 id="approutes">AppRoutes</h3><p>The type of the default export from <code>routes.tsx</code>:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">type</span><span style="color:#E5C07B"> AppRoutes</span><span style="color:#56B6C2"> =</span><span style="color:#E5C07B"> RouteNode</span><span style="color:#ABB2BF">[];</span></span></code></pre><h3 id="veloconfig">VeloConfig</h3><p>Configuration options for <code>veloPlugin()</code>:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#C678DD">interface</span><span style="color:#E5C07B"> VeloConfig</span><span style="color:#ABB2BF"> {</span></span>
<span class="line"><span style="color:#E06C75">    appDirectory</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">;   </span><span style="color:#7F848E;font-style:italic">// default: "./app"</span></span>
<span class="line"><span style="color:#E06C75">    routesFile</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">;     </span><span style="color:#7F848E;font-style:italic">// default: "routes.tsx"</span></span>
<span class="line"><span style="color:#E06C75">    serverInit</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">;     </span><span style="color:#7F848E;font-style:italic">// default: "server.tsx"</span></span>
<span class="line"><span style="color:#E06C75">    clientInit</span><span style="color:#C678DD">?</span><span style="color:#ABB2BF">: </span><span style="color:#E5C07B">string</span><span style="color:#ABB2BF">;     </span><span style="color:#7F848E;font-style:italic">// default: "client.tsx"</span></span>
<span class="line"><span style="color:#ABB2BF">}</span></span></code></pre>`,rawMd:'# Type Reference\n\nThis page lists all the TypeScript types and interfaces exported by VeloJS, organized by import path.\n\n## Subpath exports\n\n| Import | What you get |\n|--------|-------------|\n| `@mauroandre/velojs` | Types (`AppRoutes`, `ActionArgs`, `LoaderArgs`, `Metadata`), `Scripts`, `Link`, `defineConfig` |\n| `@mauroandre/velojs/server` | `startServer`, `createApp`, `addRoutes`, `onServer`, `serverDataStorage` |\n| `@mauroandre/velojs/client` | `startClient` |\n| `@mauroandre/velojs/hooks` | `Loader`, `useLoader`, `useParams`, `useQuery`, `useNavigate`, `usePathname`, `touch` |\n| `@mauroandre/velojs/cookie` | `getCookie`, `setCookie`, `deleteCookie`, `getSignedCookie`, `setSignedCookie` |\n| `@mauroandre/velojs/factory` | `createMiddleware`, `createFactory` |\n| `@mauroandre/velojs/vite` | `veloPlugin` |\n| `@mauroandre/velojs/config` | `defineConfig`, `VeloConfig` |\n\n## Interfaces\n\n### LoaderArgs\n\nPassed to every `loader` function. Contains the URL parameters, query string, and Hono context:\n\n```typescript\ninterface LoaderArgs {\n    params: Record<string, string>;  // URL params like :id\n    query: Record<string, string>;   // Query string like ?page=2\n    c: Context;                      // Hono request context\n}\n```\n\n### ActionArgs\n\nPassed to every `action_*` function. The generic type `TBody` defines the shape of the data sent from the client:\n\n```typescript\ninterface ActionArgs<TBody = unknown> {\n    body: TBody;                          // Data from the client\n    params?: Record<string, string>;      // URL params (server only)\n    query?: Record<string, string>;       // Query string (server only)\n    c?: Context;                          // Hono context (server only)\n}\n```\n\n### Metadata\n\nAutomatically injected into each module by the Vite plugin. Contains the module identifier and resolved paths:\n\n```typescript\ninterface Metadata {\n    moduleId: string;    // e.g., "admin/Users"\n    fullPath?: string;   // e.g., "/admin/users"\n    path?: string;       // e.g., "/users"\n}\n```\n\n### RouteModule\n\nThe shape of a route module (what `import * as Module` gives you):\n\n```typescript\ninterface RouteModule {\n    Component: ComponentType<any>;\n    loader?: (args: LoaderArgs) => Promise<any>;\n    metadata?: Metadata;\n    [key: `action_${string}`]: (args: ActionArgs<any>) => Promise<any>;\n}\n```\n\n### RouteNode\n\nA single node in the route tree defined in `routes.tsx`:\n\n```typescript\ninterface RouteNode {\n    path?: string;\n    module: RouteModule;\n    children?: RouteNode[];\n    middlewares?: MiddlewareHandler[];\n    isRoot?: boolean;\n}\n```\n\n### AppRoutes\n\nThe type of the default export from `routes.tsx`:\n\n```typescript\ntype AppRoutes = RouteNode[];\n```\n\n### VeloConfig\n\nConfiguration options for `veloPlugin()`:\n\n```typescript\ninterface VeloConfig {\n    appDirectory?: string;   // default: "./app"\n    routesFile?: string;     // default: "routes.tsx"\n    serverInit?: string;     // default: "server.tsx"\n    clientInit?: string;     // default: "client.tsx"\n}\n```\n'},"production-deploy":{html:`<h1 id="production-deploy">Production Deploy</h1><p>VeloJS apps compile to a simple structure: a <code>dist/</code> folder with a server entry and static assets. This makes deployment straightforward on any Node.js hosting.</p>
<h2 id="build-your-app">Build your app</h2><pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#61AFEF">npx</span><span style="color:#98C379"> velojs</span><span style="color:#98C379"> build</span></span></code></pre><p>This runs two Vite builds:</p>
<ol>
<li><strong>Client build</strong> → <code>dist/client/</code> (JavaScript, CSS, and other static assets)</li>
<li><strong>Server build</strong> → <code>dist/server.js</code> (the SSR server entry point)</li>
</ol>
<h2 id="start-in-production">Start in production</h2><pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#61AFEF">npx</span><span style="color:#98C379"> velojs</span><span style="color:#98C379"> start</span></span></code></pre><p>This automatically sets <code>NODE_ENV=production</code> and starts the server. In production mode, VeloJS serves static files from <code>dist/client/</code> and handles SSR for all page routes.</p>
<h2 id="dockerfile">Dockerfile</h2><p>Here&#39;s a production-ready Dockerfile with multi-stage build:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#61AFEF">FROM</span><span style="color:#ABB2BF"> node:22-alpine </span><span style="color:#61AFEF">AS</span><span style="color:#ABB2BF"> builder</span></span>
<span class="line"><span style="color:#61AFEF">WORKDIR</span><span style="color:#ABB2BF"> /app</span></span>
<span class="line"><span style="color:#61AFEF">COPY</span><span style="color:#ABB2BF"> package.json package-lock.json ./</span></span>
<span class="line"><span style="color:#61AFEF">RUN</span><span style="color:#ABB2BF"> npm ci</span></span>
<span class="line"><span style="color:#61AFEF">COPY</span><span style="color:#ABB2BF"> app ./app</span></span>
<span class="line"><span style="color:#61AFEF">COPY</span><span style="color:#ABB2BF"> tsconfig.json vite.config.ts ./</span></span>
<span class="line"><span style="color:#61AFEF">RUN</span><span style="color:#ABB2BF"> npm run build</span></span>
<span class="line"></span>
<span class="line"><span style="color:#61AFEF">FROM</span><span style="color:#ABB2BF"> node:22-alpine</span></span>
<span class="line"><span style="color:#61AFEF">WORKDIR</span><span style="color:#ABB2BF"> /app</span></span>
<span class="line"><span style="color:#61AFEF">COPY</span><span style="color:#ABB2BF"> package.json package-lock.json ./</span></span>
<span class="line"><span style="color:#61AFEF">RUN</span><span style="color:#ABB2BF"> npm ci --omit=dev</span></span>
<span class="line"><span style="color:#61AFEF">COPY</span><span style="color:#ABB2BF"> --from=builder /app/dist ./dist</span></span>
<span class="line"></span>
<span class="line"><span style="color:#61AFEF">ENV</span><span style="color:#ABB2BF"> SERVER_PORT=3000</span></span>
<span class="line"><span style="color:#61AFEF">EXPOSE</span><span style="color:#ABB2BF"> 3000</span></span>
<span class="line"><span style="color:#61AFEF">CMD</span><span style="color:#ABB2BF"> [</span><span style="color:#98C379">"npx"</span><span style="color:#ABB2BF">, </span><span style="color:#98C379">"velojs"</span><span style="color:#ABB2BF">, </span><span style="color:#98C379">"start"</span><span style="color:#ABB2BF">]</span></span></code></pre><p>The multi-stage build keeps the final image small — it only includes production dependencies and the compiled output, not your source code or dev dependencies.</p>
<h2 id="static-assets-on-cdn">Static assets on CDN</h2><p>If you want to serve static assets (JS, CSS, images) from a CDN or S3 bucket instead of the Node.js server, set the <code>STATIC_BASE_URL</code> environment variable:</p>
<pre class="shiki one-dark-pro" style="background-color:#282c34;color:#abb2bf" tabindex="0"><code><span class="line"><span style="color:#E06C75">STATIC_BASE_URL</span><span style="color:#56B6C2">=</span><span style="color:#98C379">https://cdn.example.com/assets</span><span style="color:#61AFEF"> npx</span><span style="color:#98C379"> velojs</span><span style="color:#98C379"> start</span></span></code></pre><p>The <code>&lt;Scripts /&gt;</code> component and CSS <code>url()</code> references will automatically use this prefix. The server will skip serving static files when <code>STATIC_BASE_URL</code> points to an external URL.</p>
<h2 id="included-dependencies">Included dependencies</h2><p>VeloJS is an opinionated framework — a single <code>npm install @mauroandre/velojs</code> brings everything you need:</p>
<ul>
<li><strong>Hono</strong> — HTTP server and routing</li>
<li><strong>Preact</strong> — UI rendering (SSR + client hydration)</li>
<li><strong>@preact/signals</strong> — Reactive state management</li>
<li><strong>wouter-preact</strong> — Client-side routing</li>
<li><strong>Vite</strong> — Build tool and dev server</li>
<li><strong>@preact/preset-vite</strong> — Preact JSX support</li>
<li><strong>@hono/vite-dev-server</strong> — SSR dev server</li>
</ul>
<p>You don&#39;t need to install or configure any of these separately. VeloJS controls the versions to ensure everything works together.</p>
`,rawMd:`# Production Deploy

VeloJS apps compile to a simple structure: a \`dist/\` folder with a server entry and static assets. This makes deployment straightforward on any Node.js hosting.

## Build your app

\`\`\`bash
npx velojs build
\`\`\`

This runs two Vite builds:
1. **Client build** → \`dist/client/\` (JavaScript, CSS, and other static assets)
2. **Server build** → \`dist/server.js\` (the SSR server entry point)

## Start in production

\`\`\`bash
npx velojs start
\`\`\`

This automatically sets \`NODE_ENV=production\` and starts the server. In production mode, VeloJS serves static files from \`dist/client/\` and handles SSR for all page routes.

## Dockerfile

Here's a production-ready Dockerfile with multi-stage build:

\`\`\`dockerfile
FROM node:22-alpine AS builder
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci
COPY app ./app
COPY tsconfig.json vite.config.ts ./
RUN npm run build

FROM node:22-alpine
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --omit=dev
COPY --from=builder /app/dist ./dist

ENV SERVER_PORT=3000
EXPOSE 3000
CMD ["npx", "velojs", "start"]
\`\`\`

The multi-stage build keeps the final image small — it only includes production dependencies and the compiled output, not your source code or dev dependencies.

## Static assets on CDN

If you want to serve static assets (JS, CSS, images) from a CDN or S3 bucket instead of the Node.js server, set the \`STATIC_BASE_URL\` environment variable:

\`\`\`bash
STATIC_BASE_URL=https://cdn.example.com/assets npx velojs start
\`\`\`

The \`<Scripts />\` component and CSS \`url()\` references will automatically use this prefix. The server will skip serving static files when \`STATIC_BASE_URL\` points to an external URL.

## Included dependencies

VeloJS is an opinionated framework — a single \`npm install @mauroandre/velojs\` brings everything you need:

- **Hono** — HTTP server and routing
- **Preact** — UI rendering (SSR + client hydration)
- **@preact/signals** — Reactive state management
- **wouter-preact** — Client-side routing
- **Vite** — Build tool and dev server
- **@preact/preset-vite** — Preact JSX support
- **@hono/vite-dev-server** — SSR dev server

You don't need to install or configure any of these separately. VeloJS controls the versions to ensure everything works together.
`}};var ie="_1fwlj080",de="_1fwlj081",ye="_1fwlj082",Be="_1fwlj083",ue="_1fwlj084",he="_1fwlj085",Ce="_1fwlj086",Ae="_1fwlj087",fe="_1fwlj088",Fe="_1fwlj089",me="_1fwlj08a",ge="_1fwlj08b",ve="_1fwlj08c",Ee="_1fwlj08d",be="_1fwlj08e",De="_1fwlj08f",Vs="_1fwlj08g",Ns="_1fwlj08h",Os="_1fwlj08i",_e="_1fwlj08j";function we(n){const s=n.match(/^#\/docs\/(.+)$/);return s?s[1]:S[0]?.slug??""}function ke(){const n=un(!1),s=we(ls.value);Dn(()=>{n.value=!1},[s]);const e=ce[s],a=S.find(r=>r.slug===s),t=S.findIndex(r=>r.slug===s),o=t>0?S[t-1]:null,p=t<S.length-1?S[t+1]:null;return!s||!e?(window.location.hash=`#/docs/${S[0]?.slug??""}`,null):i("div",{class:ie,children:[i("button",{class:me,onClick:()=>n.value=!n.value,children:n.value?"✕":"☰"}),i("aside",{class:`${de} ${n.value?ye:""}`,children:[i("div",{class:Be,children:i("a",{href:"#/",class:ue,children:"VeloJS"})}),i("nav",{class:he,children:S.map(r=>i("a",{href:`#/docs/${r.slug}`,class:`${Ce} ${r.slug===s?Ae:""}`,children:r.title},r.slug))}),i("div",{class:fe,children:i("a",{href:"docs/velojs-docs.zip",download:!0,class:Fe,children:"↓ Download all docs (.zip)"})})]}),i("main",{class:ge,children:[i("div",{class:ve,children:[i("h1",{class:Ee,children:a?.title}),a&&i("a",{href:`docs/${a.filename}`,download:!0,class:be,children:"↓ Download .md"})]}),i("div",{class:_e,dangerouslySetInnerHTML:{__html:e.html}}),i("div",{class:De,children:[i("div",{children:o&&i("a",{href:`#/docs/${o.slug}`,class:Vs,children:[i("span",{class:Ns,children:"← Previous"}),i("span",{class:Os,children:o.title})]})}),i("div",{children:p&&i("a",{href:`#/docs/${p.slug}`,class:Vs,style:{textAlign:"right"},children:[i("span",{class:Ns,children:"Next →"}),i("span",{class:Os,children:p.title})]})})]})]})]})}const ls=gs(window.location.hash||"#/");window.addEventListener("hashchange",()=>{ls.value=window.location.hash||"#/"});U(()=>{ls.value,window.scrollTo(0,0)});function Se(){return ls.value.startsWith("#/docs")?i(ke,{}):i(re,{})}En(i(Se,{}),document.getElementById("app"));
